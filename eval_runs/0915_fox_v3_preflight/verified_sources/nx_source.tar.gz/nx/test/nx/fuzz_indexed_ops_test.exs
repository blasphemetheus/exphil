defmodule Nx.FuzzIndexedOpsTest do
  @moduledoc """
  Fuzz tests for indexed / slice-family ops (`Nx.gather`,
  `Nx.indexed_add`, `Nx.indexed_put`, `Nx.slice`, `Nx.put_slice`,
  `Nx.take`, `Nx.scatter*`).

  These ops are exercised heavily by Axon but are thinly covered at
  the Nx layer — especially under `grad` and with mixed-backend
  inputs (one concrete tensor, one Expr tensor, as happens when a
  grad re-trace captures an outer-scope value).
  """
  use ExUnit.Case, async: true
  use ExUnitProperties

  @fuzz_scale String.to_integer(System.get_env("FUZZ_SCALE", "1"))

  import Nx.Defn
  import Nx.Testing

  # ── put_slice under grad ───────────────────────────────────────────

  describe "Nx.put_slice grad wrt update (put_slice_grad_mixed_backend)" do
    # See FUZZ_FINDINGS/put_slice_grad_mixed_backend_dispatch.md.
    # Nx.put_slice dispatches via impl!(tensor) alone. When target is
    # concrete BinaryBackend and update is an Expr (typical in grad
    # re-trace of a closure over an outer-scope tensor), BinaryBackend
    # is picked and crashes on to_binary(expr).

    defn put_slice_sum(t, patch) do
      Nx.sum(Nx.put_slice(t, [1], patch))
    end

    # FIXED-DISPATCH — fixed upstream (multi-tensor impl! dispatch).
    test "[FIXED-DISPATCH-put_slice-grad] grad wrt update with captured target works" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      patch = Nx.tensor([10.0, 20.0])

      grad = Nx.Defn.grad(patch, fn p -> put_slice_sum(t, p) end)
      assert_all_close(grad, Nx.tensor([1.0, 1.0]), atol: 1.0e-6)
    end

    test "grad wrt target with captured update works (control)" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      patch = Nx.tensor([10.0, 20.0])

      grad = Nx.Defn.grad(t, fn x -> put_slice_sum(x, patch) end)
      assert_all_close(grad, Nx.tensor([1.0, 0.0, 0.0, 1.0, 1.0]), atol: 1.0e-6)
    end

    test "grad wrt update with inner-constructed target works (control)" do
      defmodule Inner do
        import Nx.Defn

        defn put_slice_sum_inner(patch) do
          t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
          Nx.sum(Nx.put_slice(t, [1], patch))
        end
      end

      patch = Nx.tensor([10.0, 20.0])
      grad = Nx.Defn.grad(patch, &Inner.put_slice_sum_inner/1)
      assert_all_close(grad, Nx.tensor([1.0, 1.0]), atol: 1.0e-6)
    end
  end

  # ── Non-grad scope: same bug fires on plain jit ────────────────────

  describe "dispatch bug also fires outside grad (plain jit closures)" do
    # The bug is not grad-specific — any Nx.Defn.jit closure over a
    # concrete tensor hits the same impl!/1 dispatch path.

    test "[FIXED-DISPATCH-put_slice-jit] jit(fn p -> put_slice(captured_t, p) end) works" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      jitted = Nx.Defn.jit(fn p -> Nx.sum(Nx.put_slice(t, [1], p)) end)

      assert_all_close(jitted.(Nx.tensor([10.0, 20.0])), Nx.tensor(40.0), atol: 1.0e-6)
    end

    test "[FIXED-DISPATCH-clip-jit] jit(fn lo -> clip(captured_t, lo, hi) end) works" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      jitted = Nx.Defn.jit(fn lo -> Nx.clip(t, lo, 10.0) end)

      assert_all_close(jitted.(Nx.tensor(1.5)), Nx.tensor([1.5, 2.0, 3.0, 4.0, 5.0]),
        atol: 1.0e-6
      )
    end

    # BUG-EXPRBLOCK-take-jit — different class (Expr.expr_block, not impl!/1 dispatch).
    # Fix: Expr.expr_block should Enum.map(args, &to_expr/1) before calling parameter/2.
    # See FUZZ_FINDINGS/take_grad_with_captured_indices.md.
    test "[FIXED-EXPRBLOCK-take-jit] jit(fn idx -> take(captured_t, idx) end) works" do
      # Fixed upstream by the Nx.block rework (Expr block callback now
      # normalizes args via to_exprs). Flipped from an assert_raise pin.
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      jitted = Nx.Defn.jit(fn idx -> Nx.take(t, idx) end)

      result = jitted.(Nx.tensor([0, 2, 4], type: :s32))
      assert_all_close(result, Nx.tensor([1.0, 3.0, 5.0]), atol: 1.0e-6)
    end
  end

  # ── Same dispatch bug in Nx.clip and Nx.gather ─────────────────────

  describe "clip / gather dispatch mirrors put_slice bug" do
    # Same mechanism: impl!(tensor) ignores the second tensor arg.
    # Pins current (broken) behavior with assert_raise — flip when
    # all three dispatch sites are fixed.

    defn clip_sum(t, lo, hi), do: Nx.sum(Nx.clip(t, lo, hi))
    defn gather_sum(t, idx), do: Nx.sum(Nx.gather(t, idx))

    test "[FIXED-DISPATCH-clip-grad-min] clip: grad wrt min with captured target works" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      hi = Nx.tensor(4.5)

      grad = Nx.Defn.grad(Nx.tensor(1.5), fn lo -> clip_sum(t, lo, hi) end)
      assert_all_close(grad, Nx.tensor(1.0), atol: 1.0e-6)
    end

    test "[FIXED-DISPATCH-clip-grad-max] clip: grad wrt max with captured target works" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      lo = Nx.tensor(1.5)

      grad = Nx.Defn.grad(Nx.tensor(4.5), fn hi -> clip_sum(t, lo, hi) end)
      assert_all_close(grad, Nx.tensor(1.0), atol: 1.0e-6)
    end

    test "[FIXED-DISPATCH-gather] gather: concrete source + Expr indices routes correctly" do
      # Grad wrt integer indices is zero, but the dispatch must route
      # to Expr rather than crash in BinaryBackend.to_binary/1.
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      idx_f = Nx.tensor([[0.0], [2.0], [4.0]])

      grad = Nx.Defn.grad(idx_f, fn i -> gather_sum(t, Nx.as_type(i, :s32)) end)
      assert_all_close(grad, Nx.broadcast(0.0, {3, 1}), atol: 1.0e-6)
    end
  end

  # ── reduce / window_reduce: same dispatch bug class (acc is tensor) ──

  describe "reduce / window_reduce dispatch (mixed concrete + Expr acc)" do
    defn reduce_to_scalar(t, acc) do
      Nx.reduce(t, acc, fn a, b -> a + b end)
    end

    defn windowed_max(t, acc) do
      Nx.window_reduce(t, acc, {2}, fn a, b -> Nx.max(a, b) end)
    end

    test "[FIXED-DISPATCH-reduce] reduce: correct dispatch surfaces the documented no-grad error" do
      # The dispatch crash previously masked the intended error.
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])

      assert_raise ArgumentError, ~r/cannot compute gradient for Nx.reduce\/4/, fn ->
        Nx.Defn.grad(Nx.tensor(0.0), fn a -> reduce_to_scalar(t, a) end)
      end
    end

    test "[FIXED-DISPATCH-window_reduce] window_reduce: correct dispatch surfaces the documented no-grad error" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])

      assert_raise ArgumentError, ~r/cannot compute gradient for Nx.window_reduce\/5/, fn ->
        Nx.Defn.grad(Nx.tensor(0.0), fn a -> Nx.sum(windowed_max(t, a)) end)
      end
    end
  end

  # ── Nx.take: Expr.expr_block doesn't normalize args ────────────────

  describe "Nx.take grad with concrete indices (take_grad_with_captured_indices)" do
    # See FUZZ_FINDINGS/take_grad_with_captured_indices.md.
    # Distinct from the dispatch-bug class: top-level Nx.block routes
    # correctly to Expr via list_impl!, but Expr.expr_block/3 then
    # calls parameter/2 on raw concrete tensors without normalizing,
    # and parameter/2's pattern match fails.

    defn take_sum(t, idx), do: Nx.sum(Nx.take(t, idx))

    test "[FIXED-EXPRBLOCK-take-grad] grad wrt t with captured concrete indices works" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      idx = Nx.tensor([0, 2, 4], type: :s32)

      grad = Nx.Defn.grad(t, fn x -> take_sum(x, idx) end)
      assert_all_close(grad, Nx.tensor([1.0, 0.0, 1.0, 0.0, 1.0]), atol: 1.0e-6)
    end

    test "grad wrt t with inline indices works (control)" do
      defmodule TakeInline do
        import Nx.Defn
        defn take_sum_inline(t), do: Nx.sum(Nx.take(t, Nx.tensor([0, 2, 4])))
      end

      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      grad = Nx.Defn.grad(t, &TakeInline.take_sum_inline/1)
      assert_all_close(grad, Nx.tensor([1.0, 0.0, 1.0, 0.0, 1.0]), atol: 1.0e-6)
    end

    # Nx.take_along_axis uses the same Nx.block/4 path — same bug.
    defn take_along_axis_sum(t, idx) do
      Nx.sum(Nx.take_along_axis(t, idx, axis: 0))
    end

    test "[FIXED-EXPRBLOCK-take_along_axis] take_along_axis: grad wrt t with captured indices works" do
      t = Nx.tensor([1.0, 2.0, 3.0, 4.0, 5.0])
      idx = Nx.tensor([0, 2, 4], type: :s32)

      grad = Nx.Defn.grad(t, fn x -> take_along_axis_sum(x, idx) end)
      assert_all_close(grad, Nx.tensor([1.0, 0.0, 1.0, 0.0, 1.0]), atol: 1.0e-6)
    end

    # Nx.all_close uses the same Nx.block/4 path. Since all_close
    # returns a bool, embed it in a differentiable expression.
    defn allclose_path(a, b) do
      close = Nx.as_type(Nx.all_close(a, b), :f32)
      Nx.multiply(close, Nx.sum(a))
    end

    test "[FIXED-EXPRBLOCK-all_close] all_close: grad with captured b works" do
      a = Nx.tensor([1.0, 2.0, 3.0])
      b = Nx.tensor([1.0, 2.0, 3.0])

      # all_close is non-differentiable (comparison); grad flows only
      # through the Nx.sum(a) factor, with close == 1.0 here
      grad = Nx.Defn.grad(a, fn x -> allclose_path(x, b) end)
      assert_all_close(grad, Nx.tensor([1.0, 1.0, 1.0]), atol: 1.0e-6)
    end
  end

  # ── put_slice / gather / indexed_add shape + forward fuzzing ──────

  describe "indexed ops don't crash on valid inputs" do
    property "gather with unique indices matches hand-computed lookup" do
      check all(
              n <- integer(3..8),
              k <- integer(1..5),
              max_runs: 10 * @fuzz_scale
            ) do
        k = min(k, n)
        t = Nx.iota({n}, type: :f32)
        idx = Nx.tensor(Enum.take(Enum.shuffle(0..(n - 1)), k)) |> Nx.reshape({k, 1})
        result = Nx.gather(t, idx)
        assert Nx.shape(result) == {k}
      end
    end

    property "indexed_add with overlapping indices sums contributions" do
      check all(
              n <- integer(3..6),
              max_runs: 6 * @fuzz_scale
            ) do
        t = Nx.broadcast(Nx.tensor(0.0, type: :f32), {n})
        idx = Nx.tensor([[0], [0], [1]])
        updates = Nx.tensor([1.0, 2.0, 3.0], type: :f32)
        result = Nx.indexed_add(t, idx, updates)
        # Position 0 should be 3.0 (1.0 + 2.0); position 1 should be 3.0.
        assert_all_close(result[0], Nx.tensor(3.0, type: :f32), atol: 1.0e-6)
        assert_all_close(result[1], Nx.tensor(3.0, type: :f32), atol: 1.0e-6)
      end
    end

    property "slice + sum + grad is shape-consistent" do
      check all(
              n <- integer(3..6),
              start <- integer(0..2),
              len <- integer(1..3),
              max_runs: 8 * @fuzz_scale
            ) do
        n = max(n, start + len)
        t = Nx.iota({n}, type: :f32)

        grad = Nx.Defn.grad(t, fn x -> Nx.sum(Nx.slice(x, [start], [len])) end)
        assert Nx.shape(grad) == {n}
      end
    end
  end
end
