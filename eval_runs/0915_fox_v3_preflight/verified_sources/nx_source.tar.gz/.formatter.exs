[subdirectories: ["nx", "exla", "torchx"]]
