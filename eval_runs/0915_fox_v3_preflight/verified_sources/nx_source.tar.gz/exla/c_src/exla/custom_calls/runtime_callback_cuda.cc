#include "runtime_callback_bridge.h"

#include <cstring>
#include <vector>

#include "xla/ffi/api/ffi.h"
#include "xla/ffi/ffi_api.h"

namespace ffi = xla::ffi;

#ifdef CUDA_ENABLED

#include <cuda.h>
#include <cuda_runtime.h>

namespace {

exla::callback_bridge::Arg arg_from_host_buffer(const ffi::AnyBuffer &buf,
                                                std::vector<uint8_t> &host_buf) {
  exla::callback_bridge::Arg tensor;
  tensor.dtype = buf.element_type();
  auto dims = buf.dimensions();
  tensor.dims.assign(dims.begin(), dims.end());
  tensor.data = host_buf.data();
  tensor.size_bytes = host_buf.size();
  return tensor;
}

ffi::Error exla_runtime_callback_cuda_impl(
    CUstream stream, ffi::RemainingArgs args,
    ffi::Span<const int64_t> callback_id_words, uint64_t callback_id_size,
    uint64_t num_aliased_data_outputs,
    ffi::RemainingRets rets) {
  // args[0] = callback_server_pid, args[1..] = leaf operands
  if (args.size() < 1) {
    return ffi::Error(ffi::ErrorCode::kInternal,
                      "host callback missing callback server pid operand");
  }

  std::vector<std::vector<uint8_t>> host_input_buffers;
  host_input_buffers.reserve(args.size());

  std::vector<exla::callback_bridge::Arg> inputs;
  inputs.reserve(args.size() - 1);
  exla::callback_bridge::Arg callback_server_pid_arg;

  for (size_t i = 0; i < args.size(); ++i) {
    auto maybe_buf_or = args.get<ffi::AnyBuffer>(i);
    if (!maybe_buf_or) {
      return maybe_buf_or.error();
    }

    ffi::AnyBuffer buf = *maybe_buf_or;

    size_t size_bytes = buf.size_bytes();

    host_input_buffers.emplace_back(size_bytes);
    std::vector<uint8_t> &host_buf = host_input_buffers.back();

    cudaError_t err = cudaMemcpyAsync(host_buf.data(), buf.untyped_data(),
                                      size_bytes, cudaMemcpyDeviceToHost,
                                      stream);
    if (err != cudaSuccess) {
      return ffi::Error(ffi::ErrorCode::kInternal,
                        std::string("cudaMemcpyAsync D->H failed: ") +
                            cudaGetErrorString(err));
    }

    err = cudaStreamSynchronize(stream);
    if (err != cudaSuccess) {
      return ffi::Error(ffi::ErrorCode::kInternal,
                        std::string("cudaStreamSynchronize failed: ") +
                            cudaGetErrorString(err));
    }

    exla::callback_bridge::Arg tensor = arg_from_host_buffer(buf, host_buf);

    if (i == 0) {
      callback_server_pid_arg = std::move(tensor);
    } else {
      inputs.push_back(std::move(tensor));
    }
  }

  // rets[0 .. num_aliased_data_outputs-1] are aliased to input operands;
  // non-aliased outputs start at num_aliased_data_outputs.
  size_t first_real_ret = static_cast<size_t>(num_aliased_data_outputs);

  std::vector<std::vector<uint8_t>> host_output_buffers;
  host_output_buffers.reserve(rets.size() > first_real_ret ? rets.size() - first_real_ret : 0);

  std::vector<exla::callback_bridge::OutputBuffer> outputs;
  outputs.reserve(rets.size() > first_real_ret ? rets.size() - first_real_ret : 0);

  std::vector<void *> device_output_ptrs;
  device_output_ptrs.reserve(rets.size() > first_real_ret ? rets.size() - first_real_ret : 0);

  for (size_t i = first_real_ret; i < rets.size(); ++i) {
    auto maybe_ret_or = rets.get<ffi::AnyBuffer>(i);
    if (!maybe_ret_or) {
      return maybe_ret_or.error();
    }

    ffi::Result<ffi::AnyBuffer> ret = *maybe_ret_or;
    ffi::AnyBuffer out = *ret;

    exla::callback_bridge::OutputBuffer obuf(out);
    host_output_buffers.emplace_back(obuf.size);
    // The callback writes into host memory; the H->D copy happens after.
    obuf.data = host_output_buffers.back().data();
    outputs.push_back(obuf);

    device_output_ptrs.push_back(out.untyped_data());
  }

  exla::callback_bridge::Result result =
      exla::callback_bridge::InvokeRuntimeCallback(
          callback_id_words, callback_id_size, callback_server_pid_arg, inputs,
          outputs);

  if (!result.ok) {
    return ffi::Error(ffi::ErrorCode::kInternal, result.error);
  }

  for (size_t i = 0; i < device_output_ptrs.size(); ++i) {
    size_t size = outputs[i].size;
    cudaError_t err =
        cudaMemcpyAsync(device_output_ptrs[i], host_output_buffers[i].data(),
                        size, cudaMemcpyHostToDevice, stream);
    if (err != cudaSuccess) {
      return ffi::Error(ffi::ErrorCode::kInternal,
                        std::string("cudaMemcpyAsync H->D failed: ") +
                            cudaGetErrorString(err));
    }
  }

  return ffi::Error::Success();
}

}  // namespace

XLA_FFI_DEFINE_HANDLER_SYMBOL(
    exla_runtime_callback_cuda, exla_runtime_callback_cuda_impl,
    ffi::Ffi::Bind()
        .Ctx<ffi::PlatformStream<CUstream>>()
        .RemainingArgs()
        .Attr<ffi::Span<const int64_t>>("callback_id")
        .Attr<uint64_t>("callback_id_size")
        .Attr<uint64_t>("num_aliased_data_outputs")
        .RemainingRets());

XLA_FFI_REGISTER_HANDLER(ffi::GetXlaFfiApi(), "exla_runtime_callback", "CUDA",
                         exla_runtime_callback_cuda);

#else  // CUDA_ENABLED

namespace {

ffi::Error exla_runtime_callback_cuda_stub(
    ffi::RemainingArgs, ffi::Span<const int64_t>, uint64_t, uint64_t,
    ffi::RemainingRets) {
  return ffi::Error(ffi::ErrorCode::kUnimplemented,
                    "EXLA was not compiled with CUDA support. This error means your EXLA compilation is out of sync with your libexla.so NIF.");
}

}  // namespace

XLA_FFI_DEFINE_HANDLER_SYMBOL(
    exla_runtime_callback_cuda, exla_runtime_callback_cuda_stub,
    ffi::Ffi::Bind()
        .RemainingArgs()
        .Attr<ffi::Span<const int64_t>>("callback_id")
        .Attr<uint64_t>("callback_id_size")
        .Attr<uint64_t>("num_aliased_data_outputs")
        .RemainingRets());

XLA_FFI_REGISTER_HANDLER(ffi::GetXlaFfiApi(), "exla_runtime_callback", "CUDA",
                         exla_runtime_callback_cuda);

#endif  // CUDA_ENABLED
