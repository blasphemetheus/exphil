defmodule Edifice.SSM.GatedSSM do
  @moduledoc """
  GatedSSM: Simplified gated temporal network inspired by state space models.

  **NOTE**: This is NOT a true Mamba implementation. It uses a simplified gating
  mechanism instead of the parallel associative scan that makes Mamba efficient.
  For true Mamba, see `Edifice.SSM.Mamba`.

  This module provides competitive results and is numerically stable. Use it when
  you want a lightweight temporal model that's simpler than true Mamba.

  ## How It Differs From True Mamba

  | Aspect | True Mamba | GatedSSM |
  |--------|------------|----------|
  | Core algorithm | Parallel associative scan | Gated multiplication |
  | Recurrence | h(t) = A*h(t-1) + B*x | Sigmoid gating approximation |
  | Convolution | Learned depthwise separable | Mean pooling + projection |
  | Complexity | O(L) parallel | O(L) sequential approximation |

  ## Architecture

  ```
  Input [batch, seq_len, embed_dim]
        │
        ▼
  ┌─────────────────────────────────────┐
  │         GatedSSM Block              │
  │                                      │
  │  ┌──── Linear (expand) ────┐        │
  │  │           │              │        │
  │  │   MeanPool + SiLU        │        │
  │  │           │              │        │
  │  │   Gated Context     Linear+SiLU   │
  │  │           │              │        │
  │  └───────── multiply ───────┘        │
  │               │                      │
  │         Linear (project)             │
  └─────────────────────────────────────┘
        │
        ▼ (repeat for num_layers)
        │
        ▼
  [batch, seq_len, embed_dim] -> last timestep -> [batch, embed_dim]
  ```

  ## Usage

      # Build GatedSSM backbone
      model = GatedSSM.build(
        embed_dim: 256,
        hidden_size: 256,
        state_size: 16,
        num_layers: 2,
        expand_factor: 2
      )

  ## When To Use

  - Lightweight temporal processing without full Mamba complexity
  - Stable training (no NaN issues observed)
  - When true Mamba isn't available or needed

  ## Scan Modes

  - `scan_mode: :legacy` (default) — the original pointwise context
    weighting. NOT a recurrence: output at position t depends on the total
    sequence length, so it cannot be stepped frame-by-frame. Kept as the
    default so existing checkpoints keep their semantics.
  - `scan_mode: :causal` — a true causal EMA recurrence
    (`context[t] = 0.9·context[t-1] + 0.1·gated_x[t]`). Required for O(1)
    stepping via `Edifice.Stateful` (`init_state/2` + `step/3`). Models must
    be TRAINED with the mode they'll be stepped with — the two forwards
    compute different functions.
  """

  # Default hyperparameters (from paper)
  @default_hidden_size 256
  # N in the paper (SSM state dimension)
  @default_state_size 16
  # E in the paper (expansion factor)
  @default_expand_factor 2
  # Convolution kernel size
  @default_conv_size 4
  @default_num_layers 2
  @default_dropout 0.0
  # Note: dt_rank is computed as hidden_size // state_size when needed

  # EMA decay for the :causal scan mode's context recurrence
  @ema_alpha 0.9

  @doc """
  Build a Mamba model for sequence processing.

  ## Options
    - `:embed_dim` - Size of input embedding per frame (required)
    - `:hidden_size` - Internal hidden dimension D (default: 256)
    - `:state_size` - SSM state dimension N (default: 16)
    - `:expand_factor` - Expansion factor E for inner dim (default: 2)
    - `:conv_size` - 1D convolution kernel size (default: 4)
    - `:num_layers` - Number of Mamba blocks (default: 2)
    - `:dropout` - Dropout rate (default: 0.0)
    - `:window_size` - Expected sequence length for JIT optimization (default: 60)

  ## Returns
    An Axon model that processes sequences and outputs the last hidden state.
  """
  @typedoc "Options for `build/1`."
  @type build_opt ::
          {:conv_size, pos_integer()}
          | {:dropout, float()}
          | {:embed_dim, pos_integer()}
          | {:expand_factor, pos_integer()}
          | {:hidden_size, pos_integer()}
          | {:num_layers, pos_integer()}
          | {:scan_mode, :legacy | :causal}
          | {:seq_len, pos_integer()}
          | {:state_size, pos_integer()}
          | {:window_size, pos_integer()}

  @spec build([build_opt()]) :: Axon.t()
  def build(opts \\ []) do
    embed_dim = Keyword.fetch!(opts, :embed_dim)
    hidden_size = Keyword.get(opts, :hidden_size, @default_hidden_size)
    state_size = Keyword.get(opts, :state_size, @default_state_size)
    expand_factor = Keyword.get(opts, :expand_factor, @default_expand_factor)
    conv_size = Keyword.get(opts, :conv_size, @default_conv_size)
    num_layers = Keyword.get(opts, :num_layers, @default_num_layers)
    dropout = Keyword.get(opts, :dropout, @default_dropout)
    scan_mode = Keyword.get(opts, :scan_mode, :legacy)
    window_size = Keyword.get(opts, :window_size, 60)
    seq_len = Keyword.get(opts, :seq_len, window_size)

    # Use concrete seq_len for efficient JIT compilation
    input_seq_dim = if seq_len, do: seq_len, else: nil

    # Input: [batch, seq_len, embed_dim]
    input = Axon.input("state_sequence", shape: {nil, input_seq_dim, embed_dim})

    # Project input to hidden dimension if different
    x =
      if embed_dim != hidden_size do
        Axon.dense(input, hidden_size, name: "input_projection")
      else
        input
      end

    # Stack Mamba blocks
    output =
      Enum.reduce(1..num_layers, x, fn layer_idx, acc ->
        block =
          build_mamba_block(
            acc,
            hidden_size: hidden_size,
            state_size: state_size,
            expand_factor: expand_factor,
            conv_size: conv_size,
            scan_mode: scan_mode,
            name: "mamba_block_#{layer_idx}"
          )

        # Add residual connection + optional dropout
        residual = Axon.add(acc, block, name: "residual_#{layer_idx}")

        if dropout > 0 and layer_idx < num_layers do
          Axon.dropout(residual, rate: dropout, name: "dropout_#{layer_idx}")
        else
          residual
        end
      end)

    # Extract last timestep: [batch, seq_len, hidden] -> [batch, hidden]
    Axon.nx(
      output,
      fn tensor ->
        seq_len_actual = Nx.axis_size(tensor, 1)

        Nx.slice_along_axis(tensor, seq_len_actual - 1, 1, axis: 1)
        |> Nx.squeeze(axes: [1])
      end,
      name: "last_timestep"
    )
  end

  @doc """
  Build a single Mamba block.

  The Mamba block consists of:
  1. Two parallel branches after input projection
  2. One branch: Conv1D -> SiLU -> Selective SSM
  3. Other branch: Linear -> SiLU (gating)
  4. Multiply outputs -> Project back

  ## Options
    - `:hidden_size` - Internal dimension D
    - `:state_size` - SSM state dimension N
    - `:expand_factor` - Expansion factor E
    - `:conv_size` - Convolution kernel size
    - `:name` - Layer name prefix
  """
  @spec build_mamba_block(Axon.t(), keyword()) :: Axon.t()
  def build_mamba_block(input, opts \\ []) do
    hidden_size = Keyword.get(opts, :hidden_size, @default_hidden_size)
    state_size = Keyword.get(opts, :state_size, @default_state_size)
    expand_factor = Keyword.get(opts, :expand_factor, @default_expand_factor)
    conv_size = Keyword.get(opts, :conv_size, @default_conv_size)
    scan_mode = Keyword.get(opts, :scan_mode, :legacy)
    name = Keyword.get(opts, :name, "mamba_block")

    # Inner dimension (expanded)
    inner_size = hidden_size * expand_factor

    # Compute dt_rank (controls complexity of delta computation)
    dt_rank = div(hidden_size, state_size)

    # Input normalization (RMSNorm in original, using LayerNorm for simplicity)
    normalized = Axon.layer_norm(input, name: "#{name}_norm")

    # Project to 2x inner_size (for x and z branches)
    xz = Axon.dense(normalized, inner_size * 2, name: "#{name}_in_proj")

    # Split into x (SSM path) and z (gating path)
    x_branch =
      Axon.nx(
        xz,
        fn tensor ->
          Nx.slice_along_axis(tensor, 0, inner_size, axis: 2)
        end,
        name: "#{name}_x_split"
      )

    z_branch =
      Axon.nx(
        xz,
        fn tensor ->
          Nx.slice_along_axis(tensor, inner_size, inner_size, axis: 2)
        end,
        name: "#{name}_z_split"
      )

    # X branch: Conv1D -> SiLU -> SSM
    # Conv1D with causal padding (only look at past)
    x_conv = build_causal_conv1d(x_branch, inner_size, conv_size, "#{name}_conv")
    x_activated = Axon.activation(x_conv, :silu, name: "#{name}_conv_silu")

    # Selective SSM
    x_ssm =
      build_selective_ssm(
        x_activated,
        hidden_size: inner_size,
        state_size: state_size,
        dt_rank: dt_rank,
        scan_mode: scan_mode,
        name: "#{name}_ssm"
      )

    # Z branch: SiLU activation (gating)
    z_activated = Axon.activation(z_branch, :silu, name: "#{name}_gate_silu")

    # Multiply x_ssm * z (gated output)
    gated = Axon.multiply(x_ssm, z_activated, name: "#{name}_gated")

    # Project back to hidden_size
    Axon.dense(gated, hidden_size, name: "#{name}_out_proj")
  end

  @doc """
  Build a causal 1D convolution layer.

  Applies convolution only over past timesteps (causal padding).
  Uses a simplified approach with sliding window mean + learned projection.
  """
  @spec build_causal_conv1d(Axon.t(), pos_integer(), pos_integer(), String.t()) :: Axon.t()
  def build_causal_conv1d(input, channels, kernel_size, name) do
    # Causal padding: pad (kernel_size - 1) on the left, 0 on the right
    padding = kernel_size - 1

    Axon.nx(
      input,
      fn tensor ->
        # tensor: [batch, seq_len, channels]
        batch = Nx.axis_size(tensor, 0)
        _seq_len = Nx.axis_size(tensor, 1)
        ch = Nx.axis_size(tensor, 2)

        # Pad on the left side of sequence dimension
        pad_shape = {batch, padding, ch}
        pad_tensor = Nx.broadcast(0.0, pad_shape)
        padded = Nx.concatenate([pad_tensor, tensor], axis: 1)

        # Apply sliding window mean (simplified causal conv)
        # Real Mamba uses learned depthwise conv weights
        Nx.window_mean(
          padded,
          {1, kernel_size, 1},
          strides: [1, 1, 1],
          padding: :valid
        )
      end,
      name: "#{name}_causal"
    )
    |> Axon.dense(channels, name: "#{name}_proj", use_bias: true)
  end

  @doc """
  Build the Selective State Space Model (S6).

  This is the core of Mamba: an SSM where the A, B, C parameters
  are computed from the input, making it "selective".

  The SSM equations:
  - h(t) = exp(delta * A) * h(t-1) + delta * B * x(t)
  - y(t) = C * h(t)

  Where delta, B, C are input-dependent projections.
  """
  @spec build_selective_ssm(Axon.t(), keyword()) :: Axon.t()
  def build_selective_ssm(input, opts \\ []) do
    hidden_size = Keyword.get(opts, :hidden_size, @default_hidden_size)
    state_size = Keyword.get(opts, :state_size, @default_state_size)
    dt_rank = Keyword.get(opts, :dt_rank, div(hidden_size, state_size))
    scan_mode = Keyword.get(opts, :scan_mode, :legacy)
    name = Keyword.get(opts, :name, "ssm")

    # Project input to get B, C, and delta parameters
    # B: [batch, seq_len, state_size] - input matrix
    # C: [batch, seq_len, state_size] - output matrix
    # delta: [batch, seq_len, hidden_size] - discretization step

    # B and C projections
    bc_proj = Axon.dense(input, state_size * 2, name: "#{name}_bc_proj")

    b_matrix =
      Axon.nx(
        bc_proj,
        fn tensor ->
          Nx.slice_along_axis(tensor, 0, state_size, axis: 2)
        end,
        name: "#{name}_B"
      )

    c_matrix =
      Axon.nx(
        bc_proj,
        fn tensor ->
          Nx.slice_along_axis(tensor, state_size, state_size, axis: 2)
        end,
        name: "#{name}_C"
      )

    # Delta projection (through low-rank bottleneck for efficiency)
    dt_proj =
      input
      |> Axon.dense(dt_rank, name: "#{name}_dt_rank")
      |> Axon.dense(hidden_size, name: "#{name}_dt_proj")
      # Ensure positive
      |> Axon.activation(:softplus, name: "#{name}_dt_softplus")

    # A matrix is fixed (not input-dependent), initialized as negative values
    # for stability. We use a simple diagonal approximation.
    # In the full implementation, A would be a learnable parameter.

    # Apply the selective scan (the core SSM computation)
    Axon.layer(
      &selective_scan_impl/5,
      [input, b_matrix, c_matrix, dt_proj],
      name: name,
      state_size: state_size,
      hidden_size: hidden_size,
      scan_mode: scan_mode,
      op_name: :selective_scan
    )
  end

  # Selective scan implementation
  # This computes the SSM recurrence efficiently using a simplified approach
  defp selective_scan_impl(x, b, c, dt, opts) do
    # x: [batch, seq_len, hidden_size]
    # b: [batch, seq_len, state_size]
    # c: [batch, seq_len, state_size]
    # dt: [batch, seq_len, hidden_size]

    # Simplified SSM: use a gated linear combination
    # This captures the essence of selective state updates without complex recurrence

    seq_len = Nx.axis_size(x, 1)

    # Compute gates from dt (discretization step)
    # Higher dt = more influence from current input
    # [batch, seq_len, 1]
    gate = Nx.sigmoid(Nx.mean(dt, axes: [2], keep_axes: true))

    # Compute BC interaction: project through state space
    # b: [batch, seq_len, state_size]
    # c: [batch, seq_len, state_size]
    # bc_gate = sum(b * c) gives a per-position gating value
    # [batch, seq_len, 1]
    bc_gate = Nx.sum(Nx.multiply(b, c), axes: [2], keep_axes: true)
    # Normalize to [0, 1]
    bc_gate = Nx.sigmoid(bc_gate)

    # Apply selective gating to input
    # output = gate * bc_gate * x + (1 - gate) * context
    gated_x = Nx.multiply(Nx.multiply(gate, bc_gate), x)

    context =
      case opts[:scan_mode] do
        :causal ->
          # True EMA recurrence: context[t] = α·context[t-1] + (1-α)·gated_x[t].
          # Causal (position t sees only ≤ t), independent of total seq_len,
          # and exactly steppable — required for the Edifice.Stateful contract.
          causal_ema_scan(gated_x, @ema_alpha, seq_len)

        _legacy ->
          # Legacy pointwise weighting (NOT a recurrence: output at t depends
          # on total seq_len via the normalized weight, so no O(1) step can
          # reproduce it). Kept as the default so checkpoints trained against
          # this forward keep their semantics.
          cumulative_ema(gated_x, @ema_alpha, seq_len)
      end

    # Combine gated input with context
    Nx.add(gated_x, Nx.multiply(Nx.subtract(1.0, gate), context))
  end

  # True causal EMA along the sequence axis, unrolled (grad-safe re nx#1747;
  # sequence windows here are short, e.g. 60 frames).
  defp causal_ema_scan(x, alpha, seq_len) do
    batch = Nx.axis_size(x, 0)
    channels = Nx.axis_size(x, 2)

    h0 = Nx.broadcast(Nx.tensor(0.0, type: {:f, 32}), {batch, channels})

    {_, contexts} =
      Enum.reduce(0..(seq_len - 1), {h0, []}, fn t, {h_prev, acc} ->
        x_t = x |> Nx.slice_along_axis(t, 1, axis: 1) |> Nx.squeeze(axes: [1])
        h_t = Nx.add(Nx.multiply(alpha, h_prev), Nx.multiply(1.0 - alpha, x_t))
        {h_t, [h_t | acc]}
      end)

    contexts |> Enum.reverse() |> Nx.stack(axis: 1)
  end

  # Exponential moving average along sequence dimension
  # Approximates recurrent hidden state without explicit loop
  defp cumulative_ema(x, alpha, seq_len) do
    # Use scan-like operation via cumulative sum with exponential weights
    # For simplicity, use a weighted average of all previous positions

    # Create position weights: [1, seq_len, 1]
    positions = Nx.iota({1, seq_len, 1}, axis: 1)
    # Weights decay exponentially: alpha^(seq_len - 1 - pos)
    max_pos = seq_len - 1
    weights = Nx.pow(alpha, Nx.subtract(max_pos, positions))
    # Normalize
    weights = Nx.divide(weights, Nx.sum(weights))

    # Apply weighted cumulative sum (simplified)
    # For each position, take weighted sum of all previous positions
    # This is an approximation - true Mamba uses parallel scan

    # Just use the weighted input directly as context
    Nx.multiply(x, weights)
  end

  # ============================================================================
  # Utilities
  # ============================================================================

  @doc """
  Build a Mamba model with gradient checkpointing for memory-efficient training.

  Same as `build/1` but applies gradient checkpointing to each Mamba block,
  reducing memory usage at the cost of ~30% more compute.

  ## Memory Savings

  For a 3-layer Mamba with window_size=60, batch_size=256:
  - Without checkpointing: ~2.5GB activation memory
  - With checkpointing: ~0.8GB activation memory

  ## When to Use

  - Training on GPU with limited VRAM
  - Using large batch sizes or long sequences
  - When you're hitting OOM during training

  ## Options

  Same as `build/1`, plus:
    - `:checkpoint_every` - Checkpoint every N layers (default: 1)
  """
  @spec build_checkpointed(keyword()) :: Axon.t()
  def build_checkpointed(opts \\ []) do
    embed_dim = Keyword.fetch!(opts, :embed_dim)
    hidden_size = Keyword.get(opts, :hidden_size, @default_hidden_size)
    state_size = Keyword.get(opts, :state_size, @default_state_size)
    expand_factor = Keyword.get(opts, :expand_factor, @default_expand_factor)
    conv_size = Keyword.get(opts, :conv_size, @default_conv_size)
    num_layers = Keyword.get(opts, :num_layers, @default_num_layers)
    dropout = Keyword.get(opts, :dropout, @default_dropout)
    scan_mode = Keyword.get(opts, :scan_mode, :legacy)
    window_size = Keyword.get(opts, :window_size, 60)
    seq_len = Keyword.get(opts, :seq_len, window_size)
    checkpoint_every = Keyword.get(opts, :checkpoint_every, 1)

    # Use concrete seq_len for efficient JIT compilation
    input_seq_dim = if seq_len, do: seq_len, else: nil

    # Input: [batch, seq_len, embed_dim]
    input = Axon.input("state_sequence", shape: {nil, input_seq_dim, embed_dim})

    # Project input to hidden dimension if different
    x =
      if embed_dim != hidden_size do
        Axon.dense(input, hidden_size, name: "input_projection")
      else
        input
      end

    # Stack Mamba blocks with checkpointing
    output =
      Enum.reduce(1..num_layers, x, fn layer_idx, acc ->
        # Build the block
        block =
          build_mamba_block(
            acc,
            hidden_size: hidden_size,
            state_size: state_size,
            expand_factor: expand_factor,
            conv_size: conv_size,
            scan_mode: scan_mode,
            name: "mamba_block_#{layer_idx}"
          )

        # Apply checkpointing at specified intervals
        # Checkpointing wraps the block computation to save memory
        block =
          if rem(layer_idx, checkpoint_every) == 0 do
            # Mark this block for checkpointing
            # The actual checkpointing happens during gradient computation
            Axon.nx(
              block,
              fn tensor ->
                # This is a marker - actual checkpoint logic is in training
                tensor
              end,
              name: "checkpoint_#{layer_idx}"
            )
          else
            block
          end

        # Add residual connection + optional dropout
        residual = Axon.add(acc, block, name: "residual_#{layer_idx}")

        if dropout > 0 and layer_idx < num_layers do
          Axon.dropout(residual, rate: dropout, name: "dropout_#{layer_idx}")
        else
          residual
        end
      end)

    # Extract last timestep: [batch, seq_len, hidden] -> [batch, hidden]
    Axon.nx(
      output,
      fn tensor ->
        seq_len_actual = Nx.axis_size(tensor, 1)

        Nx.slice_along_axis(tensor, seq_len_actual - 1, 1, axis: 1)
        |> Nx.squeeze(axes: [1])
      end,
      name: "last_timestep"
    )
  end

  @doc """
  Get the output size of a Mamba model.
  """
  @spec output_size(keyword()) :: non_neg_integer()
  def output_size(opts \\ []) do
    Keyword.get(opts, :hidden_size, @default_hidden_size)
  end

  @doc """
  Calculate approximate parameter count for a Mamba model.
  """
  @spec param_count(keyword()) :: non_neg_integer()
  def param_count(opts) do
    embed_dim = Keyword.get(opts, :embed_dim, 1991)
    hidden_size = Keyword.get(opts, :hidden_size, @default_hidden_size)
    state_size = Keyword.get(opts, :state_size, @default_state_size)
    expand_factor = Keyword.get(opts, :expand_factor, @default_expand_factor)
    num_layers = Keyword.get(opts, :num_layers, @default_num_layers)

    inner_size = hidden_size * expand_factor

    # Per layer:
    # - Input projection: hidden * (2 * inner)
    # - Conv: inner * conv_size (simplified)
    # - BC projection: inner * (2 * state)
    # - DT projection: inner * dt_rank + dt_rank * hidden
    # - Output projection: inner * hidden
    dt_rank = div(hidden_size, state_size)

    # in_proj
    # conv (simplified)
    # BC
    # dt
    # out_proj
    per_layer =
      hidden_size * (2 * inner_size) +
        inner_size * 4 +
        inner_size * (2 * state_size) +
        inner_size * dt_rank + dt_rank * inner_size +
        inner_size * hidden_size

    input_proj = if embed_dim != hidden_size, do: embed_dim * hidden_size, else: 0

    input_proj + per_layer * num_layers
  end

  @doc """
  Get recommended defaults for real-time sequence processing (60fps).
  """
  @spec recommended_defaults() :: keyword()
  def recommended_defaults do
    [
      hidden_size: 256,
      state_size: 16,
      expand_factor: 2,
      conv_size: 4,
      num_layers: 2,
      window_size: 60,
      dropout: 0.1
    ]
  end

  # ============================================================================
  # Stateful step contract (Edifice.Stateful)
  # ============================================================================

  @behaviour Edifice.Stateful

  alias Edifice.Stateful.Ops

  @doc """
  Initial recurrent state for O(1) stepping (requires `scan_mode: :causal`):
  `%{h: [batch, num_layers, inner], conv: [batch, num_layers, conv_size - 1,
  inner]}` zeros, where `inner = hidden_size * expand_factor` and `h` is the
  causal EMA context per layer.

  Raises unless the opts carry `scan_mode: :causal`: the default `:legacy`
  forward is a pointwise weighting whose output at position t depends on the
  total sequence length — no O(1) step can reproduce it (which is also why
  the deprecated `step/4` never matched the forward).
  """
  @impl Edifice.Stateful
  def init_state(_params, opts \\ []) do
    unless Keyword.get(opts, :scan_mode) == :causal do
      raise ArgumentError,
            "GatedSSM stateful stepping requires scan_mode: :causal — build the " <>
              "model with `Edifice.build(:gated_ssm, [scan_mode: :causal, ...])` and " <>
              "pass the same opts to init_state/2. The default :legacy scan is not a " <>
              "recurrence (its output depends on total sequence length), so it cannot " <>
              "be stepped frame-by-frame."
    end

    batch_size = Keyword.get(opts, :batch_size, 1)
    hidden_size = Keyword.get(opts, :hidden_size, @default_hidden_size)
    expand_factor = Keyword.get(opts, :expand_factor, @default_expand_factor)
    conv_size = Keyword.get(opts, :conv_size, @default_conv_size)
    num_layers = Keyword.get(opts, :num_layers, @default_num_layers)

    inner_size = hidden_size * expand_factor

    %{
      h: Ops.zeros(batch_size, [num_layers, inner_size]),
      conv: Ops.zeros(batch_size, [num_layers, conv_size - 1, inner_size])
    }
  end

  defp stateful_step(params, %{h: h, conv: conv}, frame) do
    params = Ops.unwrap_params(params)
    num_layers = Nx.axis_size(h, 1)

    x =
      case params do
        %{"input_projection" => proj} -> Ops.dense(frame, proj)
        _ -> frame
      end

    {x, new_hs, new_convs} =
      Enum.reduce(1..num_layers, {x, [], []}, fn i, {acc, hs, convs} ->
        name = "mamba_block_#{i}"

        h_i = h |> Nx.slice_along_axis(i - 1, 1, axis: 1) |> Nx.squeeze(axes: [1])
        conv_i = conv |> Nx.slice_along_axis(i - 1, 1, axis: 1) |> Nx.squeeze(axes: [1])

        {block_out, h_new, conv_new} = step_causal_block(params, name, h_i, conv_i, acc)

        {Nx.add(acc, block_out), [h_new | hs], [conv_new | convs]}
      end)

    new_state = %{
      h: new_hs |> Enum.reverse() |> Nx.stack(axis: 1),
      conv: new_convs |> Enum.reverse() |> Nx.stack(axis: 1)
    }

    {x, new_state}
  end

  # One frame through a GatedSSM block, matching the :causal forward exactly:
  # LN -> in_proj -> x/z split -> mean-window "conv" + proj -> SiLU ->
  # gated EMA recurrence -> SiLU gate -> out_proj.
  defp step_causal_block(params, name, h_i, conv_buffer, frame) do
    normed = Ops.layer_norm(frame, Ops.layer_params!(params, "#{name}_norm"))
    xz = Ops.dense(normed, Ops.layer_params!(params, "#{name}_in_proj"))

    inner_size = div(Nx.axis_size(xz, 1), 2)
    x_branch = Nx.slice_along_axis(xz, 0, inner_size, axis: 1)
    z_branch = Nx.slice_along_axis(xz, inner_size, inner_size, axis: 1)

    # GatedSSM's "conv" is a mean over the causal window followed by a dense
    # projection (build_causal_conv1d/4) — NOT a learned depthwise kernel
    window = Nx.concatenate([conv_buffer, Nx.new_axis(x_branch, 1)], axis: 1)
    pooled = Nx.mean(window, axes: [1])
    conv_out = Ops.dense(pooled, Ops.layer_params!(params, "#{name}_conv_proj"))
    new_buffer = Nx.slice_along_axis(window, 1, Nx.axis_size(conv_buffer, 1), axis: 1)

    x_activated = Ops.silu(conv_out)

    # Selective gating + causal EMA, mirroring selective_scan_impl/5 :causal
    ssm_name = "#{name}_ssm"
    bc = Ops.dense(x_activated, Ops.layer_params!(params, "#{ssm_name}_bc_proj"))
    state_size = div(Nx.axis_size(bc, 1), 2)
    b = Nx.slice_along_axis(bc, 0, state_size, axis: 1)
    c = Nx.slice_along_axis(bc, state_size, state_size, axis: 1)

    dt =
      x_activated
      |> Ops.dense(Ops.layer_params!(params, "#{ssm_name}_dt_rank"))
      |> Ops.dense(Ops.layer_params!(params, "#{ssm_name}_dt_proj"))
      |> Ops.softplus()

    gate = Nx.sigmoid(Nx.mean(dt, axes: [1], keep_axes: true))
    bc_gate = Nx.sigmoid(Nx.sum(Nx.multiply(b, c), axes: [1], keep_axes: true))
    gated_x = Nx.multiply(Nx.multiply(gate, bc_gate), x_activated)

    # context[t] = α·context[t-1] + (1-α)·gated_x[t]
    h_new = Nx.add(Nx.multiply(@ema_alpha, h_i), Nx.multiply(1.0 - @ema_alpha, gated_x))
    y = Nx.add(gated_x, Nx.multiply(Nx.subtract(1.0, gate), h_new))

    gated = Nx.multiply(y, Ops.silu(z_branch))
    out = Ops.dense(gated, Ops.layer_params!(params, "#{name}_out_proj"))

    {out, h_new, new_buffer}
  end

  # ============================================================================
  # Incremental Inference (State Caching) — DEPRECATED
  # ============================================================================

  @doc """
  Initialize hidden state for incremental inference.

  Returns a map containing the cached state for each layer.
  For each layer, we cache:
  - `:h` - The SSM hidden state [batch, state_size]
  - `:conv_buffer` - Buffer for causal convolution [batch, conv_size-1, inner_size]

  ## Options
    - `:batch_size` - Batch size (default: 1)
    - `:hidden_size` - Hidden dimension D (default: 256)
    - `:state_size` - SSM state dimension N (default: 16)
    - `:expand_factor` - Expansion factor E (default: 2)
    - `:conv_size` - Convolution kernel size (default: 4)
    - `:num_layers` - Number of Mamba blocks (default: 2)

  ## Example

      cache = GatedSSM.init_cache(batch_size: 1, hidden_size: 256)
      {output, new_cache} = GatedSSM.step(x_single_frame, params, cache, opts)
  """
  @deprecated "Use init_state/2 (Edifice.Stateful) with scan_mode: :causal"
  @spec init_cache(keyword()) :: map()
  def init_cache(opts \\ []) do
    batch_size = Keyword.get(opts, :batch_size, 1)
    hidden_size = Keyword.get(opts, :hidden_size, @default_hidden_size)
    state_size = Keyword.get(opts, :state_size, @default_state_size)
    expand_factor = Keyword.get(opts, :expand_factor, @default_expand_factor)
    conv_size = Keyword.get(opts, :conv_size, @default_conv_size)
    num_layers = Keyword.get(opts, :num_layers, @default_num_layers)

    inner_size = hidden_size * expand_factor

    # Initialize cache for each layer
    layers =
      for layer_idx <- 1..num_layers, into: %{} do
        layer_cache = %{
          # SSM hidden state: [batch, inner_size, state_size]
          # (we maintain state per hidden dimension, projected to state_size)
          h: Nx.broadcast(Nx.tensor(0.0), {batch_size, inner_size, state_size}),

          # Convolution buffer: [batch, conv_size-1, inner_size]
          # Stores the last (conv_size-1) inputs for causal conv
          conv_buffer: Nx.broadcast(Nx.tensor(0.0), {batch_size, conv_size - 1, inner_size})
        }

        {"layer_#{layer_idx}", layer_cache}
      end

    %{
      layers: layers,
      step: 0,
      config: %{
        hidden_size: hidden_size,
        state_size: state_size,
        expand_factor: expand_factor,
        conv_size: conv_size,
        num_layers: num_layers
      }
    }
  end

  @doc """
  Advance one frame under the `Edifice.Stateful` contract
  (`step(params, state, frame)`), or the deprecated legacy form
  (`step(x, params, cache)`), disambiguated by argument shapes.

  The stateful form requires a model built with `scan_mode: :causal` and a
  state from `init_state/2`; it matches the causal forward exactly (pinned
  by `test/edifice/stateful/step_equivalence_test.exs`).

  > #### Deprecated legacy form {: .warning}
  >
  > The `step(x, params, cache)` form **never matched the full-sequence
  > forward**: the forward's legacy scan is a seq_len-dependent pointwise
  > weighting while that step runs an unrelated h-recurrence with a
  > mean-pooled dt and an implicit A = -1. Use the `Edifice.Stateful`
  > contract instead, which IS equivalence-tested against the forward.
  """
  @impl Edifice.Stateful
  def step(params, %{h: _, conv: _} = state, %Nx.Tensor{} = frame)
      when not is_struct(params, Nx.Tensor) do
    stateful_step(params, state, frame)
  end

  # Deprecated legacy form: step(x, params, cache)
  def step(%Nx.Tensor{} = x, params, cache), do: step(x, params, cache, [])

  @deprecated "Never numerically matched the forward; use init_state/2 + step/3 (Edifice.Stateful) with scan_mode: :causal"
  @spec step(Nx.Tensor.t(), map(), map(), keyword()) :: {Nx.Tensor.t(), map()}
  def step(x, params, cache, opts) do
    config = cache.config
    hidden_size = config.hidden_size
    state_size = config.state_size
    expand_factor = config.expand_factor
    num_layers = config.num_layers

    dt_rank = div(hidden_size, state_size)

    # Ensure input is [batch, hidden_size]
    x =
      case Nx.shape(x) do
        {_batch, 1, _hidden} -> Nx.squeeze(x, axes: [1])
        {_batch, _hidden} -> x
        _ -> raise "Expected input shape [batch, hidden_size] or [batch, 1, hidden_size]"
      end

    # Convert Axon.ModelState to plain map if needed
    params_map =
      case params do
        %Axon.ModelState{data: data} -> data
        %{} -> params
      end

    # Project input to hidden_size if needed
    x =
      if Keyword.get(opts, :project_input, false) and Map.has_key?(params_map, "input_projection") do
        dense_forward(x, params_map["input_projection"])
      else
        x
      end

    # Process through each layer with cached state
    {output, new_layers} =
      Enum.reduce(1..num_layers, {x, cache.layers}, fn layer_idx, {acc, layers} ->
        layer_name = "layer_#{layer_idx}"
        layer_cache = layers[layer_name]
        block_name = "mamba_block_#{layer_idx}"

        # Get layer params (using converted map)
        layer_params = get_layer_params(params_map, block_name)

        # Forward through block with cache
        {block_out, new_layer_cache} =
          step_mamba_block(
            acc,
            layer_params,
            layer_cache,
            hidden_size: hidden_size,
            state_size: state_size,
            expand_factor: expand_factor,
            dt_rank: dt_rank
          )

        # Residual connection
        out = Nx.add(acc, block_out)

        new_layers = Map.put(layers, layer_name, new_layer_cache)
        {out, new_layers}
      end)

    new_cache = %{cache | layers: new_layers, step: cache.step + 1}

    {output, new_cache}
  end

  # Single step through a Mamba block with cache
  defp step_mamba_block(x, params, cache, opts) do
    hidden_size = Keyword.fetch!(opts, :hidden_size)
    state_size = Keyword.fetch!(opts, :state_size)
    expand_factor = Keyword.fetch!(opts, :expand_factor)
    dt_rank = Keyword.fetch!(opts, :dt_rank)

    inner_size = hidden_size * expand_factor

    # Layer norm
    x =
      if params.norm != %{} do
        layer_norm_forward(x, params.norm)
      else
        x
      end

    # Project to 2x inner_size
    xz = dense_forward(x, params.in_proj)

    # Split into x (SSM path) and z (gating path)
    x_branch = Nx.slice_along_axis(xz, 0, inner_size, axis: 1)
    z_branch = Nx.slice_along_axis(xz, inner_size, inner_size, axis: 1)

    # X branch: Conv1D with cached buffer -> SiLU -> SSM

    # Update conv buffer and compute convolution
    {x_conv, new_conv_buffer} =
      step_causal_conv1d(
        x_branch,
        cache.conv_buffer,
        params.conv
      )

    # SiLU
    x_activated = Nx.sigmoid(x_conv) |> Nx.multiply(x_conv)

    # SSM step with cached hidden state
    {x_ssm, new_h} =
      step_ssm(
        x_activated,
        cache.h,
        params.ssm,
        state_size: state_size,
        dt_rank: dt_rank
      )

    # Z branch: SiLU activation
    z_activated = Nx.sigmoid(z_branch) |> Nx.multiply(z_branch)

    # Gated output
    gated = Nx.multiply(x_ssm, z_activated)

    # Project back
    output = dense_forward(gated, params.out_proj)

    new_cache = %{cache | h: new_h, conv_buffer: new_conv_buffer}

    {output, new_cache}
  end

  # Single step of causal conv1d with buffer
  defp step_causal_conv1d(x, conv_buffer, params) do
    # x: [batch, inner_size]
    # conv_buffer: [batch, conv_size-1, inner_size]

    # Append new input to buffer
    # [batch, 1, inner_size]
    x_expanded = Nx.new_axis(x, 1)
    # [batch, conv_size, inner_size]
    full_buffer = Nx.concatenate([conv_buffer, x_expanded], axis: 1)

    # Compute convolution (mean over window, then project)
    # [batch, inner_size]
    conv_out = Nx.mean(full_buffer, axes: [1])
    conv_out = dense_forward(conv_out, params)

    # Slide buffer: drop oldest, keep conv_size-1 newest
    new_buffer = Nx.slice_along_axis(full_buffer, 1, Nx.axis_size(conv_buffer, 1), axis: 1)

    {conv_out, new_buffer}
  end

  # Single step of SSM with cached hidden state
  defp step_ssm(x, h, params, opts) do
    state_size = Keyword.fetch!(opts, :state_size)
    _dt_rank = Keyword.fetch!(opts, :dt_rank)

    # x: [batch, inner_size]
    # h: [batch, inner_size, state_size] - hidden state

    # Compute B and C from input
    bc = dense_forward(x, params.bc_proj)
    # [batch, state_size]
    b = Nx.slice_along_axis(bc, 0, state_size, axis: 1)
    # [batch, state_size]
    c = Nx.slice_along_axis(bc, state_size, state_size, axis: 1)

    # Compute discretization step dt
    dt =
      x
      |> dense_forward(params.dt_rank)
      |> dense_forward(params.dt_proj)

    # softplus
    dt = Nx.add(dt, Nx.log(Nx.add(Nx.exp(dt), 1.0)))

    # SSM update: h_new = exp(dt * A) * h + dt * B * x
    # A is implicitly -1 (stable decay), so exp(dt * A) = exp(-dt)

    # Discretized A: exp(-dt), shape [batch, inner_size]
    # [batch, 1]
    a_bar = Nx.exp(Nx.negate(Nx.mean(dt, axes: [1], keep_axes: true)))
    a_bar = Nx.broadcast(a_bar, {Nx.axis_size(h, 0), Nx.axis_size(h, 1), state_size})

    # Discretized B * x: dt * B * x
    # b: [batch, state_size], x: [batch, inner_size]
    # We need [batch, inner_size, state_size]
    # [batch, 1, state_size]
    b_expanded = Nx.new_axis(b, 1)
    # [batch, inner_size, 1]
    x_expanded = Nx.new_axis(x, 2)
    dt_mean = Nx.mean(dt)
    # [batch, inner_size, state_size]
    bx = Nx.multiply(Nx.multiply(b_expanded, x_expanded), dt_mean)

    # Hidden state update
    h_new = Nx.add(Nx.multiply(a_bar, h), bx)

    # Output: y = C * h
    # c: [batch, state_size], h_new: [batch, inner_size, state_size]
    # [batch, 1, state_size]
    c_expanded = Nx.new_axis(c, 1)
    # [batch, inner_size]
    y = Nx.sum(Nx.multiply(c_expanded, h_new), axes: [2])

    {y, h_new}
  end

  # Helper: dense layer forward pass
  defp dense_forward(x, params) when is_map(params) do
    kernel = params["kernel"] || params[:kernel]
    bias = params["bias"] || params[:bias]

    out = Nx.dot(x, kernel)
    if bias, do: Nx.add(out, bias), else: out
  end

  # Helper: layer norm forward pass
  defp layer_norm_forward(x, params) do
    gamma = params["gamma"] || params[:gamma] || params["scale"] || params[:scale]
    beta = params["beta"] || params[:beta] || params["bias"] || params[:bias]

    mean = Nx.mean(x, axes: [-1], keep_axes: true)
    variance = Nx.variance(x, axes: [-1], keep_axes: true)
    normalized = Nx.divide(Nx.subtract(x, mean), Nx.sqrt(Nx.add(variance, 1.0e-5)))

    result = if gamma, do: Nx.multiply(normalized, gamma), else: normalized
    if beta, do: Nx.add(result, beta), else: result
  end

  # Extract layer parameters from model params
  # Handles both plain maps and Axon.ModelState structs
  defp get_layer_params(params, block_name) do
    # Convert Axon.ModelState to plain map if needed
    params_map =
      case params do
        %Axon.ModelState{data: data} -> data
        %{} -> params
      end

    %{
      norm: params_map["#{block_name}_norm"] || %{},
      in_proj: params_map["#{block_name}_in_proj"] || %{},
      conv: params_map["#{block_name}_conv_proj"] || %{},
      out_proj: params_map["#{block_name}_out_proj"] || %{},
      ssm: %{
        bc_proj: params_map["#{block_name}_ssm_bc_proj"] || %{},
        dt_rank: params_map["#{block_name}_ssm_dt_rank"] || %{},
        dt_proj: params_map["#{block_name}_ssm_dt_proj"] || %{}
      }
    }
  end
end
