defmodule Edifice do
  @moduledoc """
  Edifice - A comprehensive ML architecture library for Elixir.

  Provides implementations of all major neural network architecture families,
  built on Nx and Axon. From simple MLPs to state space models, attention
  mechanisms, generative models, and graph neural networks.

  ## Quick Start

      # Build any architecture by name
      model = Edifice.build(:mamba, embed_dim: 256, hidden_size: 512)

      # Or use the module directly
      model = Edifice.SSM.Mamba.build(embed_dim: 256, hidden_size: 512)

      # List all available architectures
      Edifice.list_architectures()

  ## Architecture Families

  | Family | Architectures |
  |--------|--------------|
  | Transformer | Decoder-Only (GPT-style), Multi-Token Prediction, Byte Latent Transformer, Nemotron-H, FreeTransformer |
  | Feedforward | MLP, KAN, KAT, TabNet, BitNet |
  | Convolutional | Conv1D/2D, ResNet, DenseNet, TCN, MobileNet, EfficientNet |
  | Recurrent | LSTM, GRU, xLSTM, xLSTM v2, mLSTM, sLSTM, MinGRU, MinLSTM, DeltaNet, Gated DeltaNet, DeltaProduct, TTT, TTT-E2E, Titans, MIRAS, Reservoir (ESN), Native Recurrence, TransformerLike, DeepResLSTM |
  | State Space | Mamba, Mamba-2 (SSD), Mamba-3, S4, S4D, S5, H3, Hyena, Hyena v2, BiMamba, GatedSSM, GSS, StripedHyena, Hymba, State Space Transformer, Longhorn |
  | Attention | Multi-Head, GQA, MLA, KDA (Kimi Delta Attention), DiffTransformer, Sigmoid Attention, FoX (Forgetting Transformer), Log-Linear, NHA (Native Hybrid Attention), LASER, MoBA, MTA (Multi-Token Attention), GSA (Gated Slot Attention), RLA/RDN (Residual Linear Attention), TNN (Toeplitz), Perceiver, FNet, Linear Transformer, Nystromformer, Performer, RetNet, RetNet v2, RWKV, GLA, GLA v2, HGRN, HGRN v2, Griffin, Hawk, Based, InfiniAttention, Conformer, Mega, MEGALODON, RingAttention, Lightning Attention, Flash Linear Attention, YaRN, NSA, SPLA, InfLLM-V2, Dual Chunk Attention |
  | Vision | ViT, DeiT, Swin, U-Net, ConvNeXt, MLP-Mixer, FocalNet, PoolFormer, NeRF, MambaVision, DINOv3, Janus, Vision KAN |
  | Generative | VAE, VQ-VAE, GAN, Diffusion, DDIM, DiT, DiT v2, MMDiT, Latent Diffusion, Consistency, Score SDE, Flow Matching, Rectified Flow, SoFlow, Normalizing Flow, TarFlow, STARFlow, Transfusion, CogVideoX, TRELLIS, MDLM, LLaDA, CaDDi, DeepFlow, Meissonic, MAGVIT-v2, Show-o, JanusFlow |
  | Graph | GCN, GAT, GraphSAGE, GIN, GINv2, PNA, GraphTransformer, SchNet, DimeNet, SE(3)-Transformer, GPS, KA-GNN, Message Passing |
  | Sets | DeepSets, PointNet, PointNet++ |
  | Energy | EBM, Hopfield, Neural ODE |
  | Probabilistic | Bayesian, MC Dropout, Evidential |
  | Memory | NTM, Memory Networks, Memory Layers |
  | Meta | MoE, MoE v2, Switch MoE, Soft MoE, ReMoE, MoR, MoED, LoRA, DoRA, VeRA, Kron-LoRA, PiSSA, Adapter, Hypernetworks, Capsules, MixtureOfDepths, MixtureOfAgents, RLHFHead, Speculative Decoding, Test-Time Compute, Mixture of Tokenizers, Speculative Head, EAGLE-3, Manifold HC, Distillation Head, QAT, Coconut, Hybrid Builder, MoT |
  | Liquid | Liquid Neural Networks |
  | Contrastive | SimCLR, BYOL, Barlow Twins, MAE, VICReg, JEPA, Temporal JEPA, V-JEPA 2 |
  | Interpretability | Sparse Autoencoder, Transcoder, Gated SAE, JumpReLU SAE, BatchTopK SAE, Linear Probe, Crosscoder, Concept Bottleneck, DAS Probe, LEACE, Matryoshka SAE, Cross-Layer Transcoder |
  | World Model | World Model |
  | Multimodal | MLP Projection Fusion, Cross-Attention Fusion, Perceiver Resampler |
  | RL | PolicyValue, Decision Transformer |
  | Neuromorphic | SNN, ANN2SNN |
  | Inference | Medusa |
  | Robotics | ACT, Diffusion Policy, OpenVLA |
  | Audio | SoundStorm, EnCodec, F5-TTS, VALL-E, Whisper, Wav2Vec 2.0 |
  | Detection | DETR, RT-DETR, SAM 2 |
  | Scientific | FNO, DeepONet, TNO |
  """

  # The ONE source of truth for what Edifice can build and which family
  # each architecture belongs to. `@architecture_registry`, `list_architectures/0`
  # and `list_families/0` are all DERIVED from this list — never maintain a
  # second copy (see exphil docs/planning/INVARIANTS.md item 3).
  @registry_by_family [
    transformer: [
      decoder_only: Edifice.Transformer.DecoderOnly,
      multi_token_prediction: Edifice.Transformer.MultiTokenPrediction,
      byte_latent_transformer: Edifice.Transformer.ByteLatentTransformer,
      nemotron_h: Edifice.Transformer.NemotronH,
      free_transformer: Edifice.Transformer.FreeTransformer
    ],
    feedforward: [
      mlp: Edifice.Feedforward.MLP,
      kan: Edifice.Feedforward.KAN,
      kat: Edifice.Feedforward.KAT,
      tabnet: Edifice.Feedforward.TabNet,
      bitnet: Edifice.Feedforward.BitNet
    ],
    convolutional: [
      conv1d: Edifice.Convolutional.Conv,
      resnet: Edifice.Convolutional.ResNet,
      densenet: Edifice.Convolutional.DenseNet,
      tcn: Edifice.Convolutional.TCN,
      mobilenet: Edifice.Convolutional.MobileNet,
      efficientnet: Edifice.Convolutional.EfficientNet
    ],
    recurrent: [
      lstm: {Edifice.Recurrent, [cell_type: :lstm]},
      gru: {Edifice.Recurrent, [cell_type: :gru]},
      xlstm: Edifice.Recurrent.XLSTM,
      mlstm: {Edifice.Recurrent.XLSTM, [variant: :mlstm]},
      min_gru: Edifice.Recurrent.MinGRU,
      min_lstm: Edifice.Recurrent.MinLSTM,
      delta_net: Edifice.Recurrent.DeltaNet,
      gated_delta_net: Edifice.Recurrent.GatedDeltaNet,
      ttt: Edifice.Recurrent.TTT,
      ttt_e2e: Edifice.Recurrent.TTTE2E,
      titans: Edifice.Recurrent.Titans,
      miras: Edifice.Recurrent.MIRAS,
      reservoir: Edifice.Recurrent.Reservoir,
      slstm: Edifice.Recurrent.SLSTM,
      xlstm_v2: Edifice.Recurrent.XLSTMv2,
      native_recurrence: Edifice.Recurrent.NativeRecurrence,
      transformer_like: Edifice.Recurrent.TransformerLike,
      deep_res_lstm: Edifice.Recurrent.DeepResLSTM,
      huginn: Edifice.Recurrent.Huginn,
      multi_timescale_recurrence: Edifice.Recurrent.MultiTimescaleRecurrence,
      delta_product: Edifice.Recurrent.DeltaProduct
    ],
    ssm: [
      mamba: Edifice.SSM.Mamba,
      mamba_ssd: Edifice.SSM.MambaSSD,
      mamba_cumsum: Edifice.SSM.MambaCumsum,
      mamba_hillis_steele: Edifice.SSM.MambaHillisSteele,
      s4: Edifice.SSM.S4,
      s4d: Edifice.SSM.S4D,
      s5: Edifice.SSM.S5,
      h3: Edifice.SSM.H3,
      hyena: Edifice.SSM.Hyena,
      bimamba: Edifice.SSM.BiMamba,
      gated_ssm: Edifice.SSM.GatedSSM,
      jamba: Edifice.SSM.Hybrid,
      zamba: Edifice.SSM.Zamba,
      striped_hyena: Edifice.SSM.StripedHyena,
      mamba3: Edifice.SSM.Mamba3,
      gss: Edifice.SSM.GSS,
      hyena_v2: Edifice.SSM.HyenaV2,
      hymba: Edifice.SSM.Hymba,
      ss_transformer: Edifice.SSM.SSTransformer,
      longhorn: Edifice.SSM.Longhorn,
      samba: Edifice.SSM.Samba,
      mixture_of_mamba: Edifice.SSM.MixtureOfMamba
    ],
    meta: [
      hybrid_builder: Edifice.Meta.HybridBuilder,
      moe: Edifice.Meta.MoE,
      switch_moe: Edifice.Meta.SwitchMoE,
      soft_moe: Edifice.Meta.SoftMoE,
      lora: Edifice.Meta.LoRA,
      adapter: Edifice.Meta.Adapter,
      hypernetwork: Edifice.Meta.Hypernetwork,
      capsule: Edifice.Meta.Capsule,
      mixture_of_depths: Edifice.Meta.MixtureOfDepths,
      mixture_of_agents: Edifice.Meta.MixtureOfAgents,
      agent_swarm: Edifice.Meta.AgentSwarm,
      router_network: Edifice.Meta.RouterNetwork,
      stateful_agent: Edifice.Meta.StatefulAgent,
      message_passing_agents: Edifice.Meta.MessagePassingAgents,
      rlhf_head: Edifice.Meta.RLHFHead,
      dpo: Edifice.Meta.DPO,
      kto: Edifice.Meta.KTO,
      grpo: Edifice.Meta.GRPO,
      moe_v2: Edifice.Meta.MoEv2,
      dora: Edifice.Meta.DoRA,
      speculative_decoding: Edifice.Meta.SpeculativeDecoding,
      test_time_compute: Edifice.Meta.TestTimeCompute,
      mixture_of_tokenizers: Edifice.Meta.MixtureOfTokenizers,
      speculative_head: Edifice.Meta.SpeculativeHead,
      eagle3: Edifice.Meta.Eagle3,
      manifold_hc: Edifice.Meta.ManifoldHC,
      distillation_head: Edifice.Meta.DistillationHead,
      qat: Edifice.Meta.QAT,
      remoe: Edifice.Meta.ReMoE,
      mixture_of_recursions: Edifice.Meta.MixtureOfRecursions,
      mixture_of_expert_depths: Edifice.Meta.MixtureOfExpertDepths,
      coconut: Edifice.Meta.Coconut,
      vera: Edifice.Meta.VeRA,
      kron_lora: Edifice.Meta.KronLoRA,
      pissa: Edifice.Meta.PiSSA,
      mixture_of_transformers: Edifice.Meta.MixtureOfTransformers
    ],
    attention: [
      attention: Edifice.Attention.MultiHead,
      retnet: Edifice.Attention.RetNet,
      rwkv: Edifice.Attention.RWKV,
      gla: Edifice.Attention.GLA,
      hgrn: Edifice.Attention.HGRN,
      griffin: Edifice.Attention.Griffin,
      gqa: Edifice.Attention.GQA,
      perceiver: Edifice.Attention.Perceiver,
      fnet: Edifice.Attention.FNet,
      linear_transformer: Edifice.Attention.LinearTransformer,
      nystromformer: Edifice.Attention.Nystromformer,
      performer: Edifice.Attention.Performer,
      mega: Edifice.Attention.Mega,
      based: Edifice.Attention.Based,
      infini_attention: Edifice.Attention.InfiniAttention,
      conformer: Edifice.Attention.Conformer,
      ring_attention: Edifice.Attention.RingAttention,
      mla: Edifice.Attention.MLA,
      diff_transformer: Edifice.Attention.DiffTransformer,
      hawk: Edifice.Attention.Hawk,
      retnet_v2: Edifice.Attention.RetNetV2,
      megalodon: Edifice.Attention.Megalodon,
      gla_v2: Edifice.Attention.GLAv2,
      hgrn_v2: Edifice.Attention.HGRNv2,
      flash_linear_attention: Edifice.Attention.FlashLinearAttention,
      kda: Edifice.Attention.KDA,
      gated_attention: Edifice.Attention.GatedAttention,
      sigmoid_attention: Edifice.Attention.SigmoidAttention,
      ssmax: Edifice.Blocks.SSMax,
      softpick: Edifice.Blocks.Softpick,
      rnope_swa: Edifice.Attention.RNoPESWA,
      yarn: Edifice.Attention.YARN,
      nsa: Edifice.Attention.NSA,
      spla: Edifice.Attention.SPLA,
      infllm_v2: Edifice.Attention.InfLLMV2,
      tmrope: Edifice.Attention.TMRoPE,
      fox: Edifice.Attention.FoX,
      log_linear: Edifice.Attention.LogLinear,
      nha: Edifice.Attention.NHA,
      laser: Edifice.Attention.LASER,
      moba: Edifice.Attention.MoBA,
      mta: Edifice.Attention.MTA,
      gsa: Edifice.Attention.GSA,
      rla: Edifice.Attention.RLA,
      rdn: {Edifice.Attention.RLA, [variant: :rdn]},
      tnn: Edifice.Attention.TNN,
      lightning_attention: Edifice.Attention.LightningAttention,
      dual_chunk_attention: Edifice.Attention.DualChunk
    ],
    vision: [
      vit: Edifice.Vision.ViT,
      deit: Edifice.Vision.DeiT,
      swin: Edifice.Vision.SwinTransformer,
      unet: Edifice.Vision.UNet,
      convnext: Edifice.Vision.ConvNeXt,
      mlp_mixer: Edifice.Vision.MLPMixer,
      focalnet: Edifice.Vision.FocalNet,
      poolformer: Edifice.Vision.PoolFormer,
      nerf: Edifice.Vision.NeRF,
      gaussian_splat: Edifice.Vision.GaussianSplat,
      mamba_vision: Edifice.Vision.MambaVision,
      dino_v2: Edifice.Vision.DINOv2,
      dino_v3: Edifice.Vision.DINOv3,
      metaformer: Edifice.Vision.MetaFormer,
      caformer: {Edifice.Vision.MetaFormer, [variant: :caformer]},
      efficient_vit: Edifice.Vision.EfficientViT,
      janus: Edifice.Vision.Janus,
      vision_kan: Edifice.Vision.VisionKAN
    ],
    detection: [
      detr: Edifice.Detection.DETR,
      rt_detr: Edifice.Detection.RTDETR,
      sam2: Edifice.Detection.SAM2
    ],
    multimodal: [
      multimodal_mlp_fusion: Edifice.Multimodal.Fusion
    ],
    generative: [
      diffusion: Edifice.Generative.Diffusion,
      ddim: Edifice.Generative.DDIM,
      dit: Edifice.Generative.DiT,
      dit_v2: Edifice.Generative.DiTv2,
      latent_diffusion: Edifice.Generative.LatentDiffusion,
      consistency_model: Edifice.Generative.ConsistencyModel,
      score_sde: Edifice.Generative.ScoreSDE,
      flow_matching: Edifice.Generative.FlowMatching,
      vae: Edifice.Generative.VAE,
      vq_vae: Edifice.Generative.VQVAE,
      gan: Edifice.Generative.GAN,
      normalizing_flow: Edifice.Generative.NormalizingFlow,
      mmdit: Edifice.Generative.MMDiT,
      soflow: Edifice.Generative.SoFlow,
      var: Edifice.Generative.VAR,
      linear_dit: Edifice.Generative.LinearDiT,
      sana: Edifice.Generative.LinearDiT,
      sit: Edifice.Generative.SiT,
      transfusion: Edifice.Generative.Transfusion,
      mar: Edifice.Generative.MAR,
      cogvideox: Edifice.Generative.CogVideoX,
      trellis: Edifice.Generative.TRELLIS,
      mdlm: Edifice.Generative.MDLM,
      rectified_flow: Edifice.Generative.RectifiedFlow,
      magvit2: Edifice.Generative.MAGVIT2,
      show_o: Edifice.Generative.ShowO,
      janus_flow: Edifice.Generative.JanusFlow,
      tar_flow: Edifice.Generative.TarFlow,
      star_flow: Edifice.Generative.STARFlow,
      llada: Edifice.Generative.LLaDA,
      deep_flow: Edifice.Generative.DeepFlow,
      caddi: Edifice.Generative.CaDDi,
      meissonic: Edifice.Generative.Meissonic
    ],
    graph: [
      gcn: Edifice.Graph.GCN,
      gat: Edifice.Graph.GAT,
      graph_sage: Edifice.Graph.GraphSAGE,
      gin: Edifice.Graph.GIN,
      pna: Edifice.Graph.PNA,
      graph_transformer: Edifice.Graph.GraphTransformer,
      schnet: Edifice.Graph.SchNet,
      gin_v2: Edifice.Graph.GINv2,
      egnn: Edifice.Graph.EGNN,
      dimenet: Edifice.Graph.DimeNet,
      se3_transformer: Edifice.Graph.SE3Transformer,
      gps: Edifice.Graph.GPS,
      ka_gnn: Edifice.Graph.KAGNN
    ],
    sets: [
      deep_sets: Edifice.Sets.DeepSets,
      pointnet: Edifice.Sets.PointNet,
      pointnet_pp: Edifice.Sets.PointNetPP,
      entity_encoder: Edifice.Sets.EntityEncoder
    ],
    energy: [
      ebm: Edifice.Energy.EBM,
      hopfield: Edifice.Energy.Hopfield,
      neural_ode: Edifice.Energy.NeuralODE
    ],
    probabilistic: [
      bayesian: Edifice.Probabilistic.Bayesian,
      mc_dropout: Edifice.Probabilistic.MCDropout,
      evidential: Edifice.Probabilistic.EvidentialNN
    ],
    memory: [
      ntm: Edifice.Memory.NTM,
      memory_network: Edifice.Memory.MemoryNetwork,
      engram: Edifice.Memory.Engram,
      memory_layer: Edifice.Memory.MemoryLayer
    ],
    contrastive: [
      simclr: Edifice.Contrastive.SimCLR,
      byol: Edifice.Contrastive.BYOL,
      barlow_twins: Edifice.Contrastive.BarlowTwins,
      mae: Edifice.Contrastive.MAE,
      vicreg: Edifice.Contrastive.VICReg,
      jepa: Edifice.Contrastive.JEPA,
      temporal_jepa: Edifice.Contrastive.TemporalJEPA,
      vjepa2: Edifice.Contrastive.VJEPA2,
      siglip: Edifice.Contrastive.SigLIP
    ],
    interpretability: [
      sparse_autoencoder: Edifice.Interpretability.SparseAutoencoder,
      transcoder: Edifice.Interpretability.Transcoder,
      gated_sae: Edifice.Interpretability.GatedSAE,
      linear_probe: Edifice.Interpretability.LinearProbe,
      jump_relu_sae: Edifice.Interpretability.JumpReluSAE,
      batch_top_k_sae: Edifice.Interpretability.BatchTopKSAE,
      crosscoder: Edifice.Interpretability.Crosscoder,
      concept_bottleneck: Edifice.Interpretability.ConceptBottleneck,
      das_probe: Edifice.Interpretability.DASProbe,
      leace: Edifice.Interpretability.LEACE,
      matryoshka_sae: Edifice.Interpretability.MatryoshkaSAE,
      cross_layer_transcoder: Edifice.Interpretability.CrossLayerTranscoder
    ],
    world_model: [
      world_model: Edifice.WorldModel.WorldModel
    ],
    rl: [
      policy_value: Edifice.RL.PolicyValue,
      decision_transformer: Edifice.RL.DecisionTransformer,
      autoregressive_head: Edifice.RL.AutoregressiveHead,
      pointer_network: Edifice.RL.PointerNetwork
    ],
    liquid: [
      liquid: Edifice.Liquid
    ],
    scientific: [
      fno: Edifice.Scientific.FNO,
      deep_onet: Edifice.Scientific.DeepONet,
      tno: Edifice.Scientific.TNO
    ],
    neuromorphic: [
      snn: Edifice.Neuromorphic.SNN,
      ann2snn: Edifice.Neuromorphic.ANN2SNN
    ],
    inference: [
      medusa: Edifice.Inference.Medusa
    ],
    robotics: [
      act: Edifice.Robotics.ACT,
      diffusion_policy: Edifice.Robotics.DiffusionPolicy,
      openvla: Edifice.Robotics.OpenVLA
    ],
    audio: [
      soundstorm: Edifice.Audio.SoundStorm,
      encodec: Edifice.Audio.EnCodec,
      f5_tts: Edifice.Audio.F5TTS,
      valle: Edifice.Audio.VALLE,
      whisper: Edifice.Audio.Whisper,
      wav2vec2: Edifice.Audio.Wav2Vec2
    ]
  ]

  @architecture_registry for {_fam, entries} <- @registry_by_family,
                             {name, spec} <- entries,
                             into: %{},
                             do: {name, spec}

  if map_size(@architecture_registry) !=
       Enum.sum(for {_, e} <- @registry_by_family, do: length(e)) do
    raise "duplicate architecture name in @registry_by_family"
  end

  @families for {fam, entries} <- @registry_by_family, into: %{}, do: {fam, Keyword.keys(entries)}

  @doc """
  List all available architecture names.

  ## Examples

      iex> :mamba in Edifice.list_architectures()
      true
  """
  @spec list_architectures() :: [atom()]
  def list_architectures do
    @architecture_registry |> Map.keys() |> Enum.sort()
  end

  @doc """
  List architectures grouped by family.

  ## Examples

      iex> families = Edifice.list_families()
      iex> is_map(families)
      true

      iex> families = Edifice.list_families()
      iex> :mamba in families.ssm
      true
  """
  @spec list_families() :: %{atom() => [atom()]}
  def list_families do
    @families
  end

  @doc """
  Build an architecture by name.

  ## Parameters
    - `name` - Architecture name (see `list_architectures/0`)
    - `opts` - Architecture-specific options. The primary input dimension option
      varies by family:
      - `:embed_dim` — sequence models (SSM, attention, recurrent)
      - `:input_size` — flat-vector models (MLP, probabilistic, energy)
      - `:input_dim` — graph/spatial models (GCN, DeepSets, vision)
      - `:obs_size` — diffusion models (Diffusion, DDIM, FlowMatching)

      You can pass any of the first three interchangeably — `build/2` will
      normalize to the name each module expects. `:obs_size` is also
      normalized from the above. Image models requiring `:input_shape`
      (a tuple like `{nil, 32, 32, 3}`) must be passed explicitly.

  ## Examples

      iex> model = Edifice.build(:mlp, input_size: 16, hidden_sizes: [32])
      iex> %Axon{} = model
      iex> true
      true

  ## Returns

  An `Axon.t()` model for most architectures. These architectures return tuples:

    - `:vae` — `{encoder, decoder}`
    - `:vq_vae` — `{encoder, decoder}`
    - `:gan` — `{generator, discriminator}`
    - `:normalizing_flow` — `{flow_model, log_det_fn}`
    - `:simclr` — `{backbone, projection_head}`
    - `:byol` — `{online_network, target_network}`
    - `:barlow_twins` — `{backbone, projection_head}`
    - `:vicreg` — `{backbone, projection_head}`
    - `:jepa` — `{context_encoder, predictor}`
    - `:temporal_jepa` — `{context_encoder, predictor}`
    - `:vjepa2` — `{context_encoder, predictor}`
    - `:mae` — `{encoder, decoder}`
    - `:world_model` — `{encoder, dynamics, reward_head}` (or 4-tuple with decoder)
    - `:byte_latent_transformer` — `{encoder, latent_transformer, decoder}`
    - `:speculative_decoding` — `{draft_model, verifier_model}`
    - `:multi_token_prediction` — `Axon.container(%{pred_1: ..., pred_N: ...})`
    - `:test_time_compute` — `Axon.container(%{backbone: ..., scores: ...})`
    - `:speculative_head` — `Axon.container(%{pred_1: ..., pred_N: ...})`
    - `:magvit2` — `{encoder, decoder}`
    - `:tar_flow` — `{encoder, decoder}`
    - `:star_flow` — `{encoder, decoder}`
    - `:act` — `{encoder, decoder}`
    - `:medusa` — `Axon.container(%{head_1: ..., head_K: ...})`
    - `:detr` — `Axon.container(%{class_logits: ..., bbox_pred: ...})`
    - `:rt_detr` — `Axon.container(%{class_logits: ..., bbox_pred: ...})`
    - `:sam2` — `Axon.container(%{masks: ..., iou_scores: ...})`
  """
  @spec build(atom(), keyword()) :: Axon.t() | tuple()
  def build(name, opts \\ []) do
    {module, merged_opts} = resolve!(name, opts)
    module.build(merged_opts)
  end

  @doc """
  Build a model and capture its `Edifice.Spec` manifest in one call.

  Returns `{model, spec}` where `spec` records the architecture and the
  fully-merged build options (registry defaults applied, input-dimension
  aliases normalized), so `Edifice.build(spec.arch, spec.build_opts)`
  reproduces the same model graph. Pass the spec to
  `Edifice.Checkpoint.save/3` via the `:spec` option to make checkpoints
  self-describing.

  ## Options

  `spec_opts` are forwarded to `Edifice.Spec.new/3` (`:created_at`,
  `:edifice_version`, `:nx_version`).

  ## Example

      {model, spec} = Edifice.build_with_spec(:mamba, embed_dim: 287, state_size: 32)
      Edifice.Checkpoint.save(params, "mamba.nx", spec: spec)
  """
  @spec build_with_spec(atom(), keyword(), keyword()) ::
          {Axon.t() | tuple(), Edifice.Spec.t()}
  def build_with_spec(name, opts \\ [], spec_opts \\ []) do
    {module, merged_opts} = resolve!(name, opts)
    {module.build(merged_opts), Edifice.Spec.new(name, merged_opts, spec_opts)}
  end

  defp resolve!(name, opts) do
    opts = normalize_input_dim(opts)

    case Map.fetch(@architecture_registry, name) do
      {:ok, {module, default_opts}} ->
        {module, Keyword.merge(default_opts, opts)}

      {:ok, module} ->
        {module, opts}

      :error ->
        available = list_architectures() |> Enum.join(", ")
        raise ArgumentError, "Unknown architecture #{inspect(name)}. Available: #{available}"
    end
  end

  @doc """
  Whether an architecture implements the `Edifice.Stateful` O(1) step
  contract. See `Edifice.Stateful`.
  """
  @spec stateful?(atom()) :: boolean()
  def stateful?(name), do: Edifice.Stateful.stateful?(name)

  @doc """
  Build the initial recurrent state for a stateful architecture.

  `opts` are the architecture's build options plus `:batch_size` (default 1).
  Registry default opts (e.g. `:gru`'s `cell_type: :gru`) are merged in, so
  passing the same opts used with `Edifice.build/2` does the right thing.

  ## JIT warmup

  Pass `compiler: EXLA` (or any `Nx.Defn` compiler) to compile the step
  path once at init time instead of on the first frame — a mid-game
  compilation hitch is exactly what a 60 FPS loop can't absorb. The
  warmup runs one throwaway step on a zero frame (requires `:embed_dim`
  in opts; skipped otherwise with a warning). Pass the same `compiler:`
  to `Edifice.step/5` afterwards. The returned state is still a plain
  Nx container — nothing compiled is stored in it.

  See `Edifice.Stateful`.
  """
  @spec init_state(atom(), Edifice.Stateful.params(), keyword()) :: Edifice.Stateful.state()
  def init_state(name, params, opts \\ []) do
    {module, merged_opts} = resolve_stateful!(name, opts)
    state = module.init_state(params, Keyword.delete(merged_opts, :compiler))

    case Keyword.get(merged_opts, :compiler) do
      nil ->
        state

      compiler ->
        warm_jit(module, params, state, merged_opts, compiler)
        state
    end
  end

  @doc """
  Advance a stateful architecture by one frame:
  `{output, new_state} = Edifice.step(:min_gru, params, state, frame)`.

  ## Options

    * `:compiler` - `Nx.Defn` compiler for a JIT-compiled step (e.g.
      `EXLA`). Default `nil` = eager op-by-op execution. The compiled fun
      is cached per `{module, compiler}` (see `Edifice.Stateful.jit_step/2`);
      warm it at init time via `Edifice.init_state/3`'s `:compiler` option.

  See `Edifice.Stateful`.
  """
  @spec step(
          atom(),
          Edifice.Stateful.params(),
          Edifice.Stateful.state(),
          Nx.Tensor.t(),
          keyword()
        ) ::
          {Nx.Tensor.t(), Edifice.Stateful.state()}
  def step(name, params, state, frame, opts \\ []) do
    {module, _opts} = resolve_stateful!(name, [])

    case Keyword.get(opts, :compiler) do
      nil -> module.step(params, state, frame)
      compiler -> Edifice.Stateful.jit_step(module, compiler).(params, state, frame)
    end
  end

  defp warm_jit(module, params, state, opts, compiler) do
    case Keyword.get(opts, :embed_dim) do
      nil ->
        require Logger

        Logger.warning(
          "[Edifice.init_state] compiler: #{inspect(compiler)} given but :embed_dim " <>
            "is not in opts — skipping JIT warmup; the first step/5 call will compile instead"
        )

      embed_dim ->
        batch_size = Keyword.get(opts, :batch_size, 1)
        frame = Nx.broadcast(Nx.tensor(0.0, type: {:f, 32}), {batch_size, embed_dim})
        {_out, _state} = Edifice.Stateful.jit_step(module, compiler).(params, state, frame)
        :ok
    end
  end

  defp resolve_stateful!(name, opts) do
    {module, merged_opts} = resolve!(name, opts)

    unless Edifice.Stateful.stateful?(module) do
      raise ArgumentError,
            "#{inspect(name)} (#{inspect(module)}) does not implement the " <>
              "Edifice.Stateful step contract. Stateful architectures: " <>
              (list_architectures()
               |> Enum.filter(&Edifice.Stateful.stateful?/1)
               |> Enum.join(", "))
    end

    {module, merged_opts}
  end

  @doc """
  Get the module for a named architecture.

  ## Examples

      iex> Edifice.module_for(:mamba)
      Edifice.SSM.Mamba

      iex> Edifice.module_for(:mlp)
      Edifice.Feedforward.MLP
  """
  @spec module_for(atom()) :: module()
  def module_for(name) do
    case Map.fetch(@architecture_registry, name) do
      {:ok, {module, _}} ->
        module

      {:ok, module} ->
        module

      :error ->
        available = list_architectures() |> Enum.join(", ")
        raise ArgumentError, "Unknown architecture #{inspect(name)}. Available: #{available}"
    end
  end

  # Normalize input dimension options so users can pass any of the scalar
  # names and the right one reaches each module.
  defp normalize_input_dim(opts) do
    value =
      Keyword.get(opts, :embed_dim) ||
        Keyword.get(opts, :input_size) ||
        Keyword.get(opts, :input_dim) ||
        Keyword.get(opts, :obs_size)

    if value do
      opts
      |> Keyword.put_new(:embed_dim, value)
      |> Keyword.put_new(:input_size, value)
      |> Keyword.put_new(:input_dim, value)
      |> Keyword.put_new(:obs_size, value)
    else
      opts
    end
  end

  # ============================================================================
  # FP8 Quantization
  # ============================================================================

  @doc """
  Quantize model parameters to FP8 for inference.

  See `Edifice.Quantization.FP8.quantize/2` for full documentation.

  ## Example

      params = Axon.Loop.run(loop, data, %{}, epochs: 10)
      q_params = Edifice.quantize_fp8(params)
  """
  def quantize_fp8(params, opts \\ []) do
    Edifice.Quantization.FP8.quantize(params, opts)
  end

  @doc """
  Dequantize FP8 parameters back to original precision.

  See `Edifice.Quantization.FP8.dequantize/1` for full documentation.
  """
  def dequantize_fp8(params) do
    Edifice.Quantization.FP8.dequantize(params)
  end

  # ============================================================================
  # Multi-GPU Sharding
  # ============================================================================

  @doc """
  Create a data-parallel inference function across multiple devices.

  See `Edifice.Sharding.data_parallel/3` for full documentation.

  ## Example

      dp_predict = Edifice.data_parallel(predict_fn, params, num_devices: 4)
      output = dp_predict.(input)
  """
  def data_parallel(predict_fn, params, opts \\ []) do
    Edifice.Sharding.data_parallel(predict_fn, params, opts)
  end
end
