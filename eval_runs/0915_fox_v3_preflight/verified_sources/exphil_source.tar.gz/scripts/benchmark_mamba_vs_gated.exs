#!/usr/bin/env elixir
# Benchmark: Mamba variants inference speed
#
# Run:  mix run scripts/benchmark_mamba_vs_gated.exs
#       mix run scripts/benchmark_mamba_vs_gated.exs --only cumsum_t,cumsum_l
#       mix run scripts/benchmark_mamba_vs_gated.exs --only mamba,mamba_hs
#
# Available IDs: gated_ssm, mamba, mamba_cumsum, cumsum_t, cumsum_l, mamba_hs, mamba_ssd

alias ExPhil.Networks.{Mamba, GatedSSM, MambaCumsum, MambaHillisSteele, MambaSSD}
alias ExPhil.Training.Output

# Parse --only flag
{opts, _, _} = OptionParser.parse(System.argv(), strict: [only: :string])
only_filter = case opts[:only] do
  nil -> nil
  str -> str |> String.split(",") |> Enum.map(&String.trim/1) |> MapSet.new()
end

Output.banner("Mamba Variants Inference Benchmark")

# Configuration
embed_size = 287
hidden_size = 256
state_size = 16
seq_len = 60
batch_size = 32
warmup = 5
iterations = 20

Output.config([
  {"Embed size", embed_size},
  {"Hidden size", hidden_size},
  {"Sequence length", seq_len},
  {"Batch size", batch_size},
  {"Iterations", iterations}
])

# Check backend
backend = Nx.default_backend()
Output.puts("\nBackend: #{inspect(backend)}")
if match?({EXLA.Backend, _}, backend) do
  Output.success("GPU acceleration available")
else
  Output.warning("CPU only - results will be slow")
end

# All available models
all_models = [
  {:gated_ssm, "GatedSSM", fn opts -> GatedSSM.build(opts) end},
  {:mamba, "Mamba (Blelloch)", fn opts -> Mamba.build(opts) end},
  {:mamba_cumsum, "MambaCumsum (Blelloch)", fn opts -> MambaCumsum.build(opts) end},
  {:cumsum_t, "Cumsum (transposed)", fn opts -> MambaCumsum.build(Keyword.put(opts, :scan_algo, :cumsum_transposed)) end},
  {:cumsum_l, "Cumsum (logspace)", fn opts -> MambaCumsum.build(Keyword.put(opts, :scan_algo, :cumsum_logspace)) end},
  {:mamba_hs, "Mamba (Hillis-Steele)", fn opts -> MambaHillisSteele.build(opts) end},
  {:mamba_ssd, "Mamba (SSD)", fn opts -> MambaSSD.build(opts) end}
]

# Filter models if --only specified
models = case only_filter do
  nil -> all_models
  filter ->
    filtered = Enum.filter(all_models, fn {id, _, _} -> MapSet.member?(filter, Atom.to_string(id)) end)
    if filtered == [] do
      Output.error("No models matched filter: #{Enum.join(filter, ", ")}")
      Output.puts("Available IDs: #{Enum.map_join(all_models, ", ", fn {id, _, _} -> id end)}")
      System.halt(1)
    end
    filtered
end

Output.puts("Testing #{length(models)} model(s): #{Enum.map_join(models, ", ", fn {id, _, _} -> id end)}")

model_opts = [
  embed_size: embed_size,
  hidden_size: hidden_size,
  state_size: state_size,
  num_layers: 2,
  window_size: seq_len
]

# Create input
Output.puts("\nCreating input tensor...")
key = Nx.Random.key(42)
{input, _} = Nx.Random.uniform(key, shape: {batch_size, seq_len, embed_size}, type: :f32)

# Benchmark each model
results =
  for {id, name, builder} <- models do
    Output.puts("\n" <> String.duplicate("-", 50))
    Output.puts("#{name}")
    Output.puts(String.duplicate("-", 50))

    try do
      Output.puts("  Building...")
      model = builder.(model_opts)
      build_opts = if Code.ensure_loaded?(EXLA), do: [mode: :inference, compiler: EXLA], else: [mode: :inference]
      {init_fn, pred_fn} = Axon.build(model, build_opts)
      params = init_fn.(Nx.template({batch_size, seq_len, embed_size}, :f32), Axon.ModelState.empty())

      Output.puts("  Warmup (#{warmup} iterations)...")
      for _ <- 1..warmup, do: pred_fn.(params, input)

      Output.puts("  Timing (#{iterations} iterations)...")
      times = for _ <- 1..iterations do
        {time_us, _} = :timer.tc(fn ->
          result = pred_fn.(params, input)
          if match?({EXLA.Backend, _}, Nx.default_backend()) do
            Nx.backend_transfer(result, Nx.BinaryBackend)
          else
            result
          end
        end)
        time_us / 1000
      end

      mean = Enum.sum(times) / length(times)
      std = :math.sqrt(Enum.sum(Enum.map(times, &((&1 - mean) * (&1 - mean)))) / length(times))

      Output.puts("  Result: #{Float.round(mean, 2)} ± #{Float.round(std, 2)} ms")

      {id, name, mean, std, :ok}
    rescue
      e ->
        Output.error("  FAILED: #{Exception.message(e)}")
        {id, name, 0.0, 0.0, :error}
    end
  end

# Summary
Output.puts("\n" <> String.duplicate("=", 60))
Output.puts("SUMMARY")
Output.puts(String.duplicate("=", 60))

# Find baseline (first successful result, or GatedSSM if present)
baseline_result = Enum.find(results, fn {id, _, _, _, _} -> id == :gated_ssm end) ||
                  Enum.find(results, fn {_, _, _, _, status} -> status == :ok end)
baseline_ms = case baseline_result do
  {_, _, ms, _, :ok} -> ms
  _ -> 1.0  # Avoid division by zero
end
baseline_name = case baseline_result do
  {_, name, _, _, _} -> name
  _ -> "N/A"
end

Output.puts("\n| Model | Time (ms) | vs #{baseline_name} | 60 FPS? |")
Output.puts("|-------|-----------|-------------|---------|")

for {_id, name, mean, _std, status} <- results do
  if status == :ok and mean > 0 do
    ratio = if baseline_ms > 0, do: Float.round(mean / baseline_ms, 2), else: 0.0
    fps_ok = if mean < 16.67, do: "YES", else: "NO"
    Output.puts("| #{String.pad_trailing(name, 20)} | #{String.pad_leading(Float.to_string(Float.round(mean, 1)), 9)} | #{String.pad_leading("#{ratio}x", 11)} | #{String.pad_leading(fps_ok, 7)} |")
  else
    Output.puts("| #{String.pad_trailing(name, 20)} | FAILED |")
  end
end

Output.puts("\n60 FPS threshold: 16.67ms")
Output.puts("")
Output.success("Benchmark complete!")
