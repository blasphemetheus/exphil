# Generalized DAgger retrain for scripted-expert drills: aggregate a drill
# fixture with live rollout replays relabeled by the drill's expert, retrain.
# Same protocol as dagger_multishine.exs (which it generalizes): rollouts are
# ordinary Slippi replays of the policy playing; the expert corrects every
# visited frame; the policy's ACTUAL press rides in the prev-action channel.
#
#   mix run scripts/dagger_drill.exs --expert mewtwo_fair \
#     --rollouts "~/Slippi/Game_X.slp,~/Slippi/Game_Y.slp" \
#     --out checkpoints/mewtwo_fair_dagger1_policy.bin
#
# Experts:
#   multishine  - Fox multishine (ExPhil.Agents.MultishineExpert)
#   mewtwo_fair - Mewtwo SH/FH/DJ fair chains with L-cancels
#                 (ExPhil.Agents.MewtwoFairExpert)

require Logger
Logger.configure(level: :warning)

alias ExPhil.Training.{ConversionSampling, Data, EpochLoss, Imitation, MemoryLedger, Output, ProbeRegularizer}
ExPhil.Training.Inhibitor.hold("dagger drill")
alias ExPhil.Data.Peppi
alias ExPhil.Embeddings

{opts, _argv, invalid} =
  OptionParser.parse(System.argv(),
    strict: [
      expert: :string,
      rollouts: :string,
      fixture: :string,
      out: :string,
      prev_action: :boolean,
      action_delay: :integer,
      prev_action_dropout: :float,
      scheduled_sampling: :float,
      ss_ramp: :integer,
      port: :integer,
      lr: :float,
      backbone: :string,
      # ms_g20 line (2026-09-08): --head autoregressive (joint per-frame
      # heads — down+B must land on the SAME frame) and --clean-loss (drop
      # the pos_weight/focal/oversample stack that inflates rare buttons;
      # the 09-05 generalist ablation killed taunt/shine-grab spam 165x
      # with no collapse). Both opt-in so the g19 recipe stays reproducible.
      head: :string,
      clean_loss: :boolean,
      target_loss: :float,
      max_epochs: :integer,
      hidden_size: :integer,
      nan_forensics: :boolean,
      collapse_forensics: :boolean,
      init_from: :string,
      initial_out: :string,
      replay_scene: :string,
      snapshot_all: :boolean,
      mixed_precision: :boolean,
      precision: :string,
      recurrent_state: :string,
      window: :integer,
      transition_weight: :float,
      conversion_weight: :float,
      opener_weight: :float,
      opener_lookback: :integer,
      learn_player_styles: :boolean,
      stream_chunk_size: :integer,
      stream_shard_dir: :string,
      open_shards: :integer,
      probe_reg: :float,
      probe_reg_every: :integer,
      probe_eval_every: :integer,
      probe_basin: :boolean,
      probe_every: :integer,
      probe_entries: :string,
      snippet_frames: :string,
      recorded_frames: :string,
      recorded_prefix_weight: :integer,
      recorded_prefix_frames: :integer,
      off_loop_labels: :string,
      allow_snippet_delay_mismatch: :boolean,
      y_augment: :float,
      y_augment_offset: :float,
      y_augment_frames: :integer,
      opp_randomize_frames: :integer,
      mirror_frames: :integer,
      opp_context_frames: :integer,
      opp_randomize_chars: :string,
      opp_scramble_frames: :integer,
      margin_weight: :float,
      awbc_beta: :float,
      awbc: :boolean,
      awbc_shuffle: :boolean,
      awbc_air_reward: :float,
      distill_from: :string,
      distill_weight: :float,
      distill_tau: :float,
      poison_spec: :string,
      reject_at: :integer,
      reject_on: :string,
      bc_replays: :string,
      bc_sample: :integer,
      mamba_chunk_size: :integer,
      mamba_matmul_scan: :boolean,
      debug_grads_after: :integer,
      resume: :boolean,
      snapshot_every: :integer,
      preflight: :boolean,
      memory_check: :string,
      rollout_cap_per_state: :integer,
      opening_replays: :string,
      x_hold_extend: :integer,
      queue_depth: :integer,
      with_delay_id: :boolean,
      stage_internals: :boolean,
      action_frame_buckets: :integer,
      multi_delay: :string,
      pipeline_offset: :integer,
      shift_jitter: :integer
    ]
  )

# GUARDS_BACKLOG #9: OptionParser silently collects unrecognized flags
# in `invalid` — refusing them here cost one wasted overnight arm
# (0825: --stage-internals dropped without a word; the run trained the
# plain recipe and only the checkpoint metadata exposed it).
if invalid != [] do
  IO.puts(:stderr, "UNRECOGNIZED FLAGS: #{inspect(invalid)} — refusing to train on a wrong premise.")
  System.halt(2)
end

# expert_char: the expert's character's internal ID — fixtures auto-detect
# which port the expert player is on (recordings land on whichever port the
# controller happened to claim; observed: same drill recorded P1 one day,
# P2 the next after an adapter re-plug)
{expert_mod, default_fixture, default_out, expert_char} =
  case opts[:expert] || "multishine" do
    "recorded_mewtwo" ->
      unless opts[:recorded_frames] && !opts[:rollouts] && !opts[:fixture],
        do: raise("recorded_mewtwo requires --recorded-frames and forbids fixtures/rollout relabeling")
      {ExPhil.Agents.RecordedOnlyExpert, nil, "checkpoints/mewtwo_neutral_policy.bin", 16}

    "multishine" ->
      {ExPhil.Agents.MultishineExpert, "test/fixtures/replays/fox_multishine_closed.slp",
       "checkpoints/multishine_dagger_policy.bin", 1}

    "mewtwo_fair" ->
      # Varied recording (SH/FH/DJ fair) + dense metronomic SH-fair-only +
      # approach-fair (varied-distance dash-ins for the distance-keyed table)
      {ExPhil.Agents.MewtwoFairExpert,
       "test/fixtures/replays/mewtwo_fair_chains.slp," <>
         "test/fixtures/replays/mewtwo_shfair_only.slp," <>
         "test/fixtures/replays/mewtwo_approach_fair.slp," <>
         "test/fixtures/replays/mewtwo_turnaround_fair.slp," <>
         "test/fixtures/replays/mewtwo_oos_chains.slp," <>
         "test/fixtures/replays/mewtwo_ground_neutral.slp",
       "checkpoints/mewtwo_fair_dagger_policy.bin", 16}

    "fox_recovery" ->
      # Rules-only (recovery is pure geometry): no fixture; every ordinary
      # replay with offstage moments is a rollout to relabel
      {ExPhil.Agents.FoxRecoveryExpert, nil, "checkpoints/fox_recovery_dagger_policy.bin", 1}

    "mewtwo_techchase" ->
      # Rules-only REACTION drill: reads the opponent's tech choice from
      # their action state. Rollouts = games vs --dummy tech_random.
      {ExPhil.Agents.MewtwoTechChaseExpert, nil,
       "checkpoints/mewtwo_techchase_dagger_policy.bin", 16}

    "mewtwo_combo" ->
      # Composite: fair expert when the opponent stands, chase expert when
      # they're down — the full approach->fair->knockdown->punish cycle
      {ExPhil.Agents.MewtwoComboExpert,
       ExPhil.Agents.FixtureSets.mewtwo_combo_csv(),
       "checkpoints/mewtwo_combo_dagger_policy.bin", 16}

    other ->
      Output.error("Unknown expert #{inspect(other)} (multishine | mewtwo_fair | fox_recovery)")
      System.halt(1)
  end

# --fixture accepts a comma-separated list: multiple recordings of the same
# drill combine into one expert table (denser where they overlap, variance
# averaged out) and all contribute training frames. Rules-only experts
# (fox_recovery) have no fixture at all.
fixture_paths =
  (opts[:fixture] || default_fixture || "")
  |> String.split(",", trim: true)
  |> Enum.map(&Path.expand/1)
out_path = opts[:out] || default_out
prev_action = Keyword.get(opts, :prev_action, true)
prev_action_dropout = opts[:prev_action_dropout] || 0.1
# REACTION delay on top of Peppi's causal pairing (INVARIANTS.md item 1,
# 2026-09-09): the old default 2 counted in the legacy producing convention;
# 1 is the same pairing in the new numbering. --multi-delay lists count the
# same way ("2,3" before the rebase == "1,2" now); delay-id tags follow.
action_delay = Keyword.get(opts, :action_delay, 1)

# --stream-chunk-size N (#33/data-scaling): stream training data as per-file
# embedding shards (ExPhil.Data.TrainingShards) instead of materializing the
# whole frame list + embedding tensor. Peak RAM becomes O(largest file), flat
# in pool size — the all-in-RAM path caps ~5.6M frames; the five-char corpus
# needs ~10x. nil (default) = the all-in-RAM path, byte-identical to before.
streaming = opts[:stream_chunk_size]
port = opts[:port] || 1
# Constant LR blows up late as the aggregate grows; keep it modest (see
# dagger_multishine.exs — same convergence setup)
learning_rate = opts[:lr] || 2.0e-4

# --backbone tests whether drill conclusions transfer across architectures.
# Each backbone brings its OWN shape via Config.backbone_defaults — mamba
# under the GRU drill shape (window 16, 1 layer) diverges at epoch 4.
backbone = String.to_atom(opts[:backbone] || "gru")

head =
  case opts[:head] do
    nil -> :independent
    "independent" -> :independent
    "autoregressive" -> :autoregressive
    other -> raise ArgumentError, "--head must be independent|autoregressive (got #{other})"
  end

# --clean-loss: the v16a-verdicted loss (V2_PREP item 0). Imitation's
# defaults are still the v1-era anti-collapse stack.
clean_loss_opts =
  if opts[:clean_loss],
    do: [button_pos_weight: nil, focal_loss: false, action_oversample: 1.0, entropy_weight: 0.0],
    else: []
bb_defaults = ExPhil.Training.Config.backbone_defaults(backbone) || []
# --window overrides bb_defaults (gru default is 60 — NOT 16; the || 16
# fallback below never fires for known backbones). Exploding-BPTT
# hypothesis (2026-07-13): both forensics runs detonated at param_max ~5.2
# regardless of precision — 60 backward Jacobians overflow at a critical
# weight scale. Shorter windows raise that ceiling steeply.
# Fallbacks match the common bb_defaults values (60/2) so they can't lie —
# the old `|| 16` never fired for any known backbone yet had the whole team
# believing "window 16" for a week (2026-07-13 discovery).
window = opts[:window] || bb_defaults[:window_size] || 60
recurrent_state = case opts[:recurrent_state] do
  nil -> if(backbone == :gru, do: :zeros, else: :legacy_random)
  "zeros" -> :zeros
  "legacy-random" -> :legacy_random
  other -> raise ArgumentError, "unsupported --recurrent-state #{inspect(other)}"
end
compute_precision = case opts[:precision] do
  nil -> if(recurrent_state == :zeros, do: :f32, else: :bf16)
  "f32" -> :f32
  "bf16" -> :bf16
  other -> raise ArgumentError, "unsupported --precision #{inspect(other)}"
end

rollout_paths =
  (opts[:rollouts] || "")
  |> String.split(",", trim: true)
  |> Enum.map(&Path.expand/1)
  |> Enum.flat_map(&Path.wildcard/1)

if rollout_paths == [] do
  if fixture_paths == [] and is_nil(opts[:recorded_frames]) do
    Output.error("Fixture-less expert with no rollouts — nothing to train on. Pass --rollouts.")
    System.halt(1)
  end

  Output.warning(
    "No rollouts — bootstrap mode: training on the supplied recordings " <>
      "(iteration 0 of a new drill). Play a game with the result and feed " <>
      "the replay back as the first rollout."
  )
end

Output.banner("Drill DAgger Trainer")

Output.config([
  {"Expert", inspect(expert_mod)},
  {"Fixtures", Enum.map(fixture_paths, &Path.basename/1)},
  {"Rollouts", length(rollout_paths)},
  {"Prev-action", prev_action},
  {"Prev-action dropout", prev_action_dropout},
  {"Scheduled sampling",
   if(opts[:scheduled_sampling],
     do: "#{opts[:scheduled_sampling]} (ramp #{opts[:ss_ramp] || 10} epochs)",
     else: "off"
   )},
  {"Action delay", action_delay},
  {"Conversion weight", opts[:conversion_weight] || "off"},
  {"Probe regularizer", if(opts[:probe_reg], do: "#{opts[:probe_reg]} (refit every #{opts[:probe_reg_every] || 5})", else: "off")},
  {"Out", out_path}
])

# Which port is the expert's character on in this replay? (nil char or no
# match falls back to the given default port)
detect_port = fn replay, default ->
  case replay |> Peppi.to_training_frames(player_port: default) |> Enum.take(1) do
    [f] ->
      Enum.find_value(f.game_state.players, default, fn {p, pl} ->
        if pl && trunc(pl.character || -1) == expert_char, do: p
      end)

    _ ->
      default
  end
end

load_frames = fn path, detect? ->
  # Archive + timeout-truncated seed .slp include corrupt/partial files
  # (2026-07-22). Skip them (-> []) rather than crash the whole run; the
  # BC min-frames filter and empty-rollout handling drop them downstream.
  case Peppi.parse(path) do
    {:error, reason} ->
      Output.warning("skipping unparseable replay #{Path.basename(path)}: #{inspect(reason)}")
      []

    {:ok, replay} ->
      use_port = if detect? and expert_char, do: detect_port.(replay, port), else: port

      if use_port != port do
        Output.puts("  #{Path.basename(path)}: expert character on port #{use_port} — normalizing")
      end

      frames =
        replay
        |> Peppi.to_training_frames(
          player_port: use_port,
          opponent_port: if(use_port == 1, do: 2, else: 1)
        )
        |> Enum.reject(&(&1.game_state.frame < 0))

      # Normalize so the expert is ALWAYS players[1] downstream — the shared
      # table build and relabeling assume one port across all sources
      if use_port == port do
        frames
      else
        Enum.map(frames, fn f ->
          gs = f.game_state
          swapped = %{1 => gs.players[use_port], 2 => gs.players[port]}
          %{f | game_state: %{gs | players: swapped}}
        end)
      end
  end
end

# The multishine fixture ends with an SD (recorder holds pure left, no
# buttons, to end the game) — those frames are junk training targets
fixture_filter = fn frames ->
  if expert_mod == ExPhil.Agents.MultishineExpert do
    Enum.reject(frames, fn %{controller: c} ->
      c.main_stick.x < 0.25 and c.main_stick.y > 0.4 and
        not c.button_b and not c.button_x
    end)
  else
    frames
  end
end

# Fixture: human = expert; recorded controllers are the labels. Kept as
# per-replay lists so shift_actions never crosses replay boundaries.
fixture_frame_lists = Enum.map(fixture_paths, fn p -> fixture_filter.(load_frames.(p, true)) end)
fixture_frames = List.flatten(fixture_frame_lists)
Output.puts("Fixture frames: #{length(fixture_frames)} across #{length(fixture_paths)} recording(s)")

# --bc-replays (r16): human demonstration replays as DIRECT behavior
# cloning — recorded controllers are the labels (port-normalized like
# fixtures), added to the training pool but NOT fed to the expert table.
# This supplies neutral/initiation vocabulary the scripted expert lacks
# (the 2026-07-19 "never initiates in neutral" gap) without polluting the
# teacher. --bc-sample N picks N replays at random (seeded) to control the
# BC fraction so human frames don't drown the drill signal.
bc_paths =
  (opts[:bc_replays] || "")
  |> String.split(",", trim: true)
  |> Enum.map(&Path.expand/1)
  |> Enum.flat_map(&Path.wildcard/1)

bc_paths =
  case opts[:bc_sample] do
    nil -> bc_paths
    n -> :rand.seed(:exsss, {7, 7, 7}) && Enum.take(Enum.shuffle(bc_paths), n)
  end

# Archive quality varies — some replays parse empty/truncated (observed
# 2026-07-22 on corpus/archive/mewtwo). Skip anything under @bc_min_frames.
bc_min_frames = 600

# Streaming defers BC loading into the shard build's process_fn (one file
# at a time), so nothing accumulates here.
bc_frame_lists =
  if streaming do
    []
  else
    bc_paths
    |> Enum.map(fn p -> load_frames.(p, true) end)
    |> Enum.filter(fn frames -> length(frames) >= bc_min_frames end)
  end

bc_frames = List.flatten(bc_frame_lists)

cond do
  bc_paths != [] and streaming ->
    Output.puts("BC replays: #{length(bc_paths)} human game(s) — streamed at shard build")

  bc_paths != [] ->
    skipped = length(bc_paths) - length(bc_frame_lists)

    Output.puts(
      "BC replays: #{length(bc_frames)} frames across #{length(bc_frame_lists)} human games" <>
        if(skipped > 0, do: " (#{skipped} skipped: empty/short)", else: "")
    )

  true ->
    :ok
end

# --learn-player-styles (r17): condition the policy on WHO it's imitating so
# the archive's distinct Mewtwos don't average into mush. The registry is
# built from the BC replays' netplay names (get_player_tag prefers them);
# from_frames attaches a per-frame name_id, precompute embeds it into the
# always-present name one-hot. Fixture/rollout frames (bot self-play, no
# human tag) fall through to name_id 0. At inference, --style-tag NAME
# picks a style. Registry persisted next to the checkpoint at export.
player_registry =
  if opts[:learn_player_styles] && bc_paths != [] do
    {:ok, reg} = ExPhil.Training.PlayerRegistry.from_replays(bc_paths)
    n = map_size(reg.tag_to_id)

    Output.puts(
      "Style conditioning: #{n} distinct player(s) in the registry " <>
        "(#{inspect(reg.tag_to_id |> Map.keys() |> Enum.take(6))}#{if n > 6, do: ", ...", else: ""})"
    )

    if n == 0 do
      Output.warning("--learn-player-styles set but no player identities found — styles inert")
    end

    reg
  end

# Expert table from ALL fixture recordings combined (BC replays excluded)
expert = expert_mod.from_frames(fixture_frames, player_port: port)

# --off-loop-labels drop|hold (INVARIANTS 14 + RECOVERY_LABEL_CONFIRMATION 09-13):
# at a shift k > 0 the expert can only project states ON its loop. `drop`
# (default) omits off-loop frames at k > 0 — delayed recovery supervision
# must come from --recorded-frames (the teacher's recorded future). `hold`
# is the g26 legacy rule (the recovery input held at every k), measured
# wrong 18/21 at shift 4; kept for equal-budget A/B only.
off_loop_labels = String.to_atom(opts[:off_loop_labels] || "drop")

unless off_loop_labels in [:drop, :hold],
  do: raise("--off-loop-labels must be drop or hold, got #{inspect(opts[:off_loop_labels])}")

label_opts = [expert: expert, player_port: port, off_loop: off_loop_labels]

opp_port = if port == 1, do: 2, else: 1

relabel = fn frames, recorded ->
  Enum.flat_map(frames, fn frame ->
    prev = recorded[frame.game_state.frame + action_delay - 1]

    case expert_mod.label(expert, frame.game_state.players[port], prev, frame.game_state.players[opp_port]) do
      {:ok, correction} ->
        [
          frame
          |> Map.put(:controller, correction)
          |> Map.put(:prev_controller, prev)
          # INVARIANTS item 14: this list's labels are the EXPERT's; its delayed
          # labels must come from the expert too (Labels.at_delay), never from
          # shifting along the student's recorded future.
          |> Map.put(:label_source, {:expert, expert_mod})
        ]

      :skip ->
        []
    end
  end)
end

button_sig = fn c ->
  {c.button_a, c.button_b, c.button_x, c.button_y, c.button_z, c.button_l, c.button_r}
end

# Scenario-seed slicing (#38 / drills design 2026-07-23): a seed dir
# built by build_seed_dir.exs carries seed_meta.json mapping each .slp
# basename -> %{handoff, window}. Seeds are sliced to the response
# [handoff, handoff+window] BEFORE relabeling — the prefix is identical
# across all attempts from one handoff and the --finalize SD tail is
# junk; training on either would skew the pool. The `recorded` map is
# built from the UNSLICED frames so prev-action lookups at the slice
# boundary still resolve.
seed_meta_by_dir =
  rollout_paths
  |> Enum.map(&Path.dirname/1)
  |> Enum.uniq()
  |> Map.new(fn dir ->
    meta =
      case File.read(Path.join(dir, "seed_meta.json")) do
        {:ok, bin} ->
          case Jason.decode(bin) do
            {:ok, decoded} -> decoded
            _ -> %{}
          end

        _ ->
          %{}
      end

    {dir, meta}
  end)

# One rollout -> expert-relabeled frames. Factored out so the streaming
# shard build can call it per file (one at a time) instead of accumulating
# every rollout's frames up front.
process_rollout = fn path ->
  raw = load_frames.(path, false)
  recorded = Map.new(raw, fn f -> {f.game_state.frame, f.controller} end)

  raw =
    case seed_meta_by_dir[Path.dirname(path)][Path.basename(path)] do
      %{"handoff" => handoff, "window" => window} ->
        sliced =
          Enum.filter(raw, fn f ->
            f.game_state.frame >= handoff and f.game_state.frame <= handoff + window
          end)

        Output.puts(
          "  #{Path.basename(path)}: seed sliced to [#{handoff}, #{handoff + window}] " <>
            "(#{length(sliced)}/#{length(raw)} frames)"
        )

        sliced

      _ ->
        raw
    end

  relabeled = relabel.(raw, recorded)

  disagreements =
    Enum.count(relabeled, fn f ->
      button_sig.(f.controller) != button_sig.(recorded[f.game_state.frame])
    end)

  pct = Float.round(100.0 * disagreements / max(length(relabeled), 1), 1)
  Output.puts("  #{Path.basename(path)}: #{length(relabeled)} frames, #{pct}% corrected")

  relabeled
end

rollout_frame_lists = if streaming, do: [], else: Enum.map(rollout_paths, process_rollout)

# Coverage-balanced rollouts (--rollout-cap-per-state K, opt-in; nil = old
# behavior). A stuck policy emits a PATHOLOGICAL trajectory: one state
# repeated for thousands of frames. Relabeled, that is thousands of copies
# of a single correction, which swamps the fixture and teaches the policy to
# emit that one correction unconditionally.
#
# Measured 2026-07-24 (multishine): a BC policy jammed holding the grounded
# reflector produced 2609 rollout frames, ~2100 of them the SAME state, vs
# 1679 fixture frames. DAgger round 1 collapsed from "holds one shine
# forever" to "never shines at all" — it had learned "always tap X".
# Capping per {action, action_frame, on_ground} keeps full STATE coverage
# (every distinct off-distribution state the policy visited is still
# corrected) while restoring the loop's share of the data.
rollout_frame_lists =
  case opts[:rollout_cap_per_state] do
    nil ->
      rollout_frame_lists

    cap when cap > 0 ->
      capped =
        Enum.map(rollout_frame_lists, fn frames ->
          frames
          |> Enum.group_by(fn f ->
            p = f.game_state.players[port]
            if p, do: {trunc(p.action), trunc(p.action_frame), p.on_ground}, else: :unknown
          end)
          |> Enum.flat_map(fn {_key, group} -> Enum.take(group, cap) end)
          |> Enum.sort_by(& &1.game_state.frame)
        end)

      before_n = rollout_frame_lists |> List.flatten() |> length()
      after_n = capped |> List.flatten() |> length()

      Output.puts(
        "  rollout cap #{cap}/state: #{before_n} -> #{after_n} frames " <>
          "(#{before_n - after_n} redundant repeats dropped; state coverage unchanged)"
      )

      capped
  end

# Streaming shard build (#33): every source is processed ONE AT A TIME —
# load -> relabel/slice -> shift -> weights + probe labels -> embed -> f16
# shard -> discard. Nothing accumulates, so peak RAM is O(largest file).
# Weights and probe labels are baked per shard here, which is why the
# eager sampling_weights / probe_frame_labels blocks below are skipped.
recorded_paths =
  (opts[:recorded_frames] || "")
  |> String.split(",", trim: true)
  |> Enum.flat_map(&Path.wildcard(Path.expand(&1)))

if opts[:recorded_frames] && recorded_paths == [],
  do: raise("--recorded-frames matched no files")

recorded_prefix_frames = opts[:recorded_prefix_frames] || (window + (opts[:queue_depth] || 1) - 1)
if opts[:recorded_prefix_frames] && !opts[:recorded_prefix_weight],
  do: raise("--recorded-prefix-frames requires --recorded-prefix-weight")
if opts[:recorded_prefix_weight] && (streaming || recorded_paths == []),
  do: raise("--recorded-prefix-weight requires eager --recorded-frames")

recorded_frame_lists = Enum.flat_map(recorded_paths, fn path ->
  lists = ExPhil.Training.RecordedFrames.load!(path)
  if opts[:recorded_prefix_weight],
    do: ExPhil.Training.RecordedPrefixSampling.mark(lists, path),
    else: lists
end)

if recorded_paths != [] do
  Output.puts("Recorded inputs: #{length(recorded_frame_lists)} lists, " <>
    "#{Enum.sum(Enum.map(recorded_frame_lists, &length/1))} unshifted causal frames")
end

if streaming && recorded_paths != [],
  do: raise("--recorded-frames currently requires eager training; refusing to omit data")

{shard_manifest, shard_dir} =
  if streaming do
    dir = opts[:stream_shard_dir] || "#{out_path}.shards"
    econf = ExPhil.Embeddings.Game.Config.default()

    specs =
      Enum.map(fixture_frame_lists, &{:fixture, &1}) ++
        Enum.map(bc_paths, &{:bc, &1}) ++
        Enum.map(rollout_paths, &{:rollout, &1})

    process_fn = fn
      {:fixture, list} ->
        ExPhil.Training.Labels.at_delay(list, action_delay, label_opts)

      {:bc, p} ->
        fr = load_frames.(p, true)
        if length(fr) >= bc_min_frames, do: ExPhil.Training.Labels.at_delay(fr, action_delay, label_opts), else: []

      {:rollout, p} ->
        p |> process_rollout.() |> ExPhil.Training.Labels.at_delay(action_delay, label_opts)
    end

    spec_key = fn
      {:fixture, list} -> "fixture:#{:erlang.phash2(list)}"
      {kind, p} -> "#{kind}:#{p}"
    end

    Output.puts("Streaming shard build -> #{dir} (#{length(specs)} sources)")

    {:ok, st} =
      ExPhil.Data.TrainingShards.build(specs, dir,
        embed_config: econf,
        window: window,
        use_prev_action: prev_action,
        prev_action_dropout: prev_action_dropout,
        conversion_weight: opts[:conversion_weight],
        opener_weight: opts[:opener_weight],
        opener_lookback: opts[:opener_lookback],
        probe_reg?: (opts[:probe_reg] || 0.0) > 0,
        process_fn: process_fn,
        spec_key: spec_key,
        progress: fn done, total, _ ->
          if rem(done, 5) == 0, do: IO.write(:stderr, "\r  shard #{done}/#{total}\e[K")
        end
      )

    IO.write(:stderr, "\r\e[K")

    Output.success(
      "Shards: #{st.files} built, #{st.skipped} reused, #{st.total_frames} frames -> #{dir}"
    )

    {ExPhil.Data.TrainingShards.load_manifest(dir), dir}
  else
    {nil, nil}
  end

# --snippet-frames GLOB (task #19, 2026-08-03): pre-relabeled snippet
# files from scripts/snippet_mine.exs (term_to_binary'd training-frame
# lists, consecutive frame numbers). MIXED into the pool as extra
# per-snippet lists (rule 3: mix, never replace; shift_actions can't
# cross snippet boundaries since each snippet is its own list). Snippets
# are already expert-relabeled — they skip the drill's relabel pass by
# construction (they enter as fixture-style lists, not rollouts).
snippet_frame_lists =
  (opts[:snippet_frames] || "")
  |> String.split(",", trim: true)
  |> Enum.flat_map(&Path.wildcard(Path.expand(&1)))
  |> Enum.flat_map(fn p ->
    # MixFrames envelope (unified 2026-08-03): %{action_delay, frame_lists,
    # ...}. Warn on a delay mismatch for the same reason MixFrames does —
    # a wrong :prev_controller alignment corrupts training silently.
    case p |> File.read!() |> :erlang.binary_to_term() do
      %{frame_lists: raw_lists} = payload ->
        # INVARIANTS item 14: mined snippets are expert-relabeled (snippet_mine
        # runs MultishineExpert.label per frame) — tag them so their delayed
        # labels come from the expert, not from shifting the recording.
        lists = Enum.map(raw_lists, &ExPhil.Training.Labels.tag(&1, {:expert, ExPhil.Agents.MultishineExpert}))
        # INVARIANTS.md item 1 (2026-09-10): compare in REACTION terms, and
        # refuse files mined before the causal rebase outright — their
        # frames bake the OLD (landing-convention) expert-table labels, so
        # even a matching number is one frame off after the shift.
        alias ExPhil.Data.LabelConvention
        export_delay = LabelConvention.reaction_delay(payload)

        if LabelConvention.of(payload) == :producing do
          Output.error(
            "#{Path.basename(p)} predates the causal label rebase (no label_convention stamp): " <>
              "its relabeled frames carry landing-convention expert labels and would train " <>
              "one frame early. Re-mine with scripts/snippet_mine.exs --action-delay #{action_delay}."
          )

          unless opts[:allow_snippet_delay_mismatch], do: System.halt(1)
        end

        if export_delay != action_delay do
          # FATAL since 2026-08-04 (GOTCHA #86): this was a warning, cycle
          # 3a launched over it, and 100 GPU-minutes produced an invalid
          # checkpoint (stand 104.9 vs 421.4 for the same data aligned —
          # the misalignment also manufactured 80 phantom miner anchors).
          # A contract mismatch that corrupts training must abort.
          Output.error(
            "#{Path.basename(p)} exported at action_delay=#{export_delay} but this drill " <>
              "uses #{action_delay} — the :prev_controller channel would be misaligned by " <>
              "#{abs(export_delay - action_delay)} frame(s). Re-mine with " <>
              "--action-delay #{action_delay} (or pass --allow-snippet-delay-mismatch " <>
              "if you are deliberately studying the corruption)."
          )

          unless opts[:allow_snippet_delay_mismatch] do
            System.halt(1)
          end
        end

        lists

      other when is_list(other) ->
        # Legacy bare-list snippet file (pre-unification). Accept, but say so.
        Output.warning("#{Path.basename(p)}: legacy bare-list .frames (no action_delay contract)")
        [other]
    end
  end)
  |> Enum.reject(&(&1 == []))

if snippet_frame_lists != [] do
  Output.puts(
    "Snippets: #{length(snippet_frame_lists)} lists, " <>
      "#{Enum.sum(Enum.map(snippet_frame_lists, &length/1))} pre-relabeled frames"
  )
end

all_frame_lists =
  fixture_frame_lists ++ bc_frame_lists ++ rollout_frame_lists ++ snippet_frame_lists ++
    recorded_frame_lists

# F3 distill-anchor provenance (per-LIST): anchor only clean-cycle data —
# fixture + rollout true; bc (human) + snippet false. Lists appended by
# later augmentation stages (opening synth, y-augment) are fixture-
# derived/expert-relabeled = clean; handled below by treating any list
# beyond this base count as true.
distill_base_flags =
  List.duplicate(true, length(fixture_frame_lists)) ++
    List.duplicate(false, length(bc_frame_lists)) ++
    List.duplicate(true, length(rollout_frame_lists)) ++
    List.duplicate(false, length(snippet_frame_lists)) ++
    List.duplicate(false, length(recorded_frame_lists))

# --opening-replays GLOB (2026-07-31): the farm-11 lesson ported to drills.
# Harvest real openings (spawn -> first cycle entry) from prior live replays
# and graft expert-relabeled entries onto them. The fixture's openings are
# clean teacher lead-ins only; policies trained without coverage of the LIVE
# opening distribution fall into the neutral/absorber fixed point (2026-07-31:
# freeze-trunk v1 inert, d3-loop round-2 inert — both offline-converged).
all_frame_lists =
  case opts[:opening_replays] do
    nil ->
      all_frame_lists

    glob ->
      extra =
        glob
        |> Path.wildcard()
        |> Enum.flat_map(fn p -> load_frames.(p, true) end)

      opening_synth =
        ExPhil.Data.RecoverySynth.build_opening(List.flatten(fixture_frame_lists),
          port: port,
          lead_in: window,
          expert: expert,
          extra_sources: extra
        )

      Output.puts("Synthetic opening frames: #{length(opening_synth)}")
      all_frame_lists ++ [opening_synth]
  end

# --y-augment FRAC (2026-08-04, cycle 4a): platform-competence repair by
# label-preserving altitude augmentation. The absorber diagnosis showed the
# X/JC head is silenced by the OWN-Y channel alone (grounded-at-height is
# OOD for FD-only data; patch-confirmed), and the relapse dashboard showed
# every lineage checkpoint carries the hole — g10b merely routes around it.
# The multishine cycle is position-independent, so shifting whole frame
# lists up by a platform offset creates grounded-at-height exemplars with
# correct labels for free. Whole lists are shifted (never frames within a
# list) so window histories stay internally consistent.
# Dose is a FRAME budget, not a list fraction: cycle-4a run 1 (2026-08-04)
# sampled 25% of lists, landed 44,450 frames (3.5x the known-safe snippet
# scale) and P3'd the core (stand 421 -> 82) — while moving plat X_mean
# −5.8 -> −1.35, so the signal works and only the dose was wrong. Budget
# default matches the validated snippet dose. Small lists are preferred
# (fixture/snippet-scale, cleanest cycles) to keep composition skew low.
y_aug = opts[:y_augment] || 0.0

all_frame_lists =
  if y_aug > 0.0 do
    offset = opts[:y_augment_offset] || 23.45
    budget = opts[:y_augment_frames] || 12_000

    shifted =
      all_frame_lists
      |> Enum.sort_by(&length/1)
      |> Enum.reduce_while({[], 0}, fn list, {acc, n} ->
        if n >= budget,
          do: {:halt, {acc, n}},
          else: {:cont, {[list | acc], n + length(list)}}
      end)
      |> elem(0)
      |> Enum.map(fn list ->
        Enum.map(list, fn f ->
          p = f.game_state.players[port]

          %{
            f
            | game_state: %{
                f.game_state
                | players: Map.put(f.game_state.players, port, %{p | y: p.y + offset})
              }
          }
        end)
      end)

    Output.puts(
      "Y-augment: #{length(shifted)} lists (+#{offset} own-y) = " <>
        "#{Enum.sum(Enum.map(shifted, &length/1))} grounded-at-height frames " <>
        "(budget #{budget})"
    )

    all_frame_lists ++ shifted
  else
    all_frame_lists
  end

# --opp-randomize-frames N (2026-08-07, fight-state arc): opponent-feature
# randomization. Same hour / same recipe, g10b multishined strict chain 58
# vs a still human FOX but chain 1 vs a still MEWTWO (first non-Fox human
# opponent the lineage ever faced) — the drill corpus is Fox-mirror-only,
# and opponent features are load-bearing context the cycle anchors on (the
# g6 opponent-percent-as-clock lesson, generalized). The multishine cycle
# is opponent-independent, so re-dressing the opponent in sampled drill
# lists creates correct-label exemplars vs a diverse roster for free.
# Per-LIST constant redress (never per-frame) keeps window histories
# internally consistent: one list = one coherent "different opponent".
# Randomized per list: character (diverse-body roster below — no ICs, the
# Nana fields would lie), percent (uniform 0-120, breaks percent anchors),
# x nudge (uniform ±25, varies spacing). Action states are left alone —
# the dummy's real idle states stay valid across characters; forging
# action ids risks impossible combos. Frame budget + smallest-lists-first
# follow the validated y-augment dosing pattern.
opp_rand_budget = opts[:opp_randomize_frames] || 0

all_frame_lists =
  if opp_rand_budget > 0 do
    # Internal ids (bridge/replay convention: Fox=1, Mewtwo=16):
    # Mewtwo 16, Marth 18, Jigglypuff 15, Bowser 5, Sheik 7, Falco 22,
    # Ganondorf 25, Pikachu 12 — spans size/float/animation space and
    # includes the low-tier program targets.
    roster =
      case opts[:opp_randomize_chars] do
        nil -> [16, 18, 15, 5, 7, 22, 25, 12]
        s -> s |> String.split(",") |> Enum.map(&String.to_integer(String.trim(&1)))
      end

    # RANDOM list sample, deliberately NOT smallest-first (the y-augment
    # dosing pattern): g13 (2026-08-07) redressed the smallest = cleanest
    # fixture-grade lists, so the best cycle exemplars all wore roster
    # characters and the policy learned the accidental correlation —
    # INVERTED live: stand-Mewtwo c22 (from c1) but stand-Fox 421 -> 5.
    # Random sampling (+ keeping Fox in the roster) breaks the
    # quality<->character confound.
    redressed =
      all_frame_lists
      |> Enum.shuffle()
      |> Enum.reduce_while({[], 0}, fn list, {acc, n} ->
        if n >= opp_rand_budget,
          do: {:halt, {acc, n}},
          else: {:cont, {[list | acc], n + length(list)}}
      end)
      |> elem(0)
      |> Enum.map(fn list ->
        new_char = Enum.random(roster)
        new_percent = :rand.uniform() * 120.0
        x_nudge = (:rand.uniform() - 0.5) * 50.0

        Enum.map(list, fn f ->
          opp_ports = Map.keys(f.game_state.players) -- [port]

          players =
            Enum.reduce(opp_ports, f.game_state.players, fn opp_port, acc ->
              Map.update!(acc, opp_port, fn o ->
                %{o | character: new_char, percent: new_percent, x: o.x + x_nudge}
              end)
            end)

          %{f | game_state: %{f.game_state | players: players}}
        end)
      end)

    Output.puts(
      "Opp-randomize: #{length(redressed)} lists = " <>
        "#{Enum.sum(Enum.map(redressed, &length/1))} redressed-opponent frames " <>
        "(budget #{opp_rand_budget}, roster #{inspect(roster)})"
    )

    all_frame_lists ++ redressed
  else
    all_frame_lists
  end

# --mirror-frames N (2026-09-12, coverage map instrument #2): MIRRORED copies
# of sampled lists (x -> -x for everyone, facings flipped, main-stick x
# mirrored on the LABEL — ExPhil.Training.Augmentation.mirror/1). ep57's
# map showed mirror is NOT learned (JC out of shine p 0.48/0.30, aerial
# phase 0.09/0.03 on the mirrored fixture): the fixture is one-sided and no
# recipe ever mirrored it. Per-list whole-history mirror keeps windows
# coherent; random list sample (the g13 confound lesson); frame budget.
mirror_budget = opts[:mirror_frames] || 0

all_frame_lists =
  if mirror_budget > 0 do
    mirrored =
      all_frame_lists
      |> Enum.shuffle()
      |> Enum.reduce_while({[], 0}, fn list, {acc, n} ->
        if n >= mirror_budget,
          do: {:halt, {acc, n}},
          else: {:cont, {[list | acc], n + length(list)}}
      end)
      |> elem(0)
      |> Enum.map(fn list -> Enum.map(list, &ExPhil.Training.Augmentation.mirror/1) end)

    Output.puts(
      "Mirror: #{length(mirrored)} lists = #{Enum.sum(Enum.map(mirrored, &length/1))} mirrored frames (budget #{mirror_budget})"
    )

    all_frame_lists ++ mirrored
  else
    all_frame_lists
  end

# --opp-context-frames N (2026-09-12, coverage map instrument #2): the
# opponent CONTEXT the map found the policy blind to — its ACTION (shield
# 179, grab 212, shine 361 collapse the JC out of shine f1 to p 0.00-0.03;
# dash/jab/usmash/hitstun were fine) and its SIDE/CLOSENESS (behind, or
# within ~20 units, kills the aerial phase). --opp-randomize-frames left
# action states alone and nudged x by ±25 around the fixture's +120; this
# one sets, per LIST (coherent history), an opponent action from that set
# with a matching grounded flag and action_frame, and places the opponent
# at a signed offset drawn from behind/close/normal bands. Labels untouched
# (the multishine inputs do not depend on the opponent). Frame budget +
# random list sample, same as the other redresses.
opp_ctx_budget = opts[:opp_context_frames] || 0

all_frame_lists =
  if opp_ctx_budget > 0 do
    # {action id, grounded?}: the map's red cells first, then the neighbours
    # that share their animation families, so the set is not a lookup table.
    ctx_actions = [
      {179, true}, {178, true}, {212, true}, {361, true}, {362, true}, {363, true},
      {14, true}, {20, true}, {44, true}, {63, true}, {25, false}, {29, false}
    ]

    # Signed offset bands (opponent x - own x): behind, close-front, mid, far
    ctx_offsets = [{-45.0, -10.0}, {5.0, 25.0}, {25.0, 60.0}, {60.0, 140.0}]

    contextual =
      all_frame_lists
      |> Enum.shuffle()
      |> Enum.reduce_while({[], 0}, fn list, {acc, n} ->
        if n >= opp_ctx_budget,
          do: {:halt, {acc, n}},
          else: {:cont, {[list | acc], n + length(list)}}
      end)
      |> elem(0)
      |> Enum.map(fn list ->
        {action, grounded?} = Enum.random(ctx_actions)
        {lo, hi} = Enum.random(ctx_offsets)
        offset = lo + :rand.uniform() * (hi - lo)
        # facing: toward the subject half the time, away the other half
        toward? = :rand.uniform() < 0.5
        af = :rand.uniform(6)

        Enum.map(list, fn f ->
          own = f.game_state.players[port]
          opp_ports = Map.keys(f.game_state.players) -- [port]

          players =
            Enum.reduce(opp_ports, f.game_state.players, fn opp_port, acc ->
              Map.update!(acc, opp_port, fn o ->
                x = own.x + offset
                facing = if toward?, do: if(x > own.x, do: -1, else: 1), else: if(x > own.x, do: 1, else: -1)

                %{
                  o
                  | action: action,
                    action_frame: af,
                    on_ground: grounded?,
                    x: x,
                    y: if(grounded?, do: own.y, else: own.y + 20.0),
                    facing: facing
                }
              end)
            end)

          %{f | game_state: %{f.game_state | players: players}}
        end)
      end)

    Output.puts(
      "Opp-context: #{length(contextual)} lists = #{Enum.sum(Enum.map(contextual, &length/1))} frames " <>
        "(budget #{opp_ctx_budget}; actions #{inspect(Enum.map(ctx_actions, &elem(&1, 0)))}, offsets behind/close/mid/far)"
    )

    all_frame_lists ++ contextual
  else
    all_frame_lists
  end

# --opp-scramble-frames N (2026-08-08, fight-state round 3): per-FRAME
# opponent scramble — the true-dropout shape after g13/g13b showed
# per-list coherent redress teaches character CONDITIONING (rung-0
# dependence ROSE both rounds), not invariance. Here every frame of a
# sampled list gets an independently random opponent (character, percent,
# x-nudge) — temporally incoherent noise no recurrent state can anchor
# on. The only stable signal left in a scrambled list is the cycle
# itself; the gradient's cheapest fit is to IGNORE the opponent channel.
# Labels untouched (the multishine cycle is opponent-independent).
# Random list sample (never smallest-first — the g13 confound), budget
# in frames per the validated dosing pattern.
opp_scramble_budget = opts[:opp_scramble_frames] || 0

all_frame_lists =
  if opp_scramble_budget > 0 do
    # Internal ids incl. Fox; no ICs (fake Nana fields would lie).
    scramble_roster = [1, 16, 18, 15, 5, 7, 22, 25, 12]

    scrambled =
      all_frame_lists
      |> Enum.shuffle()
      |> Enum.reduce_while({[], 0}, fn list, {acc, n} ->
        if n >= opp_scramble_budget,
          do: {:halt, {acc, n}},
          else: {:cont, {[list | acc], n + length(list)}}
      end)
      |> elem(0)
      |> Enum.map(fn list ->
        Enum.map(list, fn f ->
          opp_ports = Map.keys(f.game_state.players) -- [port]

          players =
            Enum.reduce(opp_ports, f.game_state.players, fn opp_port, acc ->
              Map.update!(acc, opp_port, fn o ->
                # v4 (g15): FULL-block scramble. v3 (g14) scrambled only
                # char/percent/x and the policy learned to ignore exactly
                # those (rung-0 1.08, stand record 430) while the UNMASKED
                # fields kept gating the cycle — no Mewtwo transfer.
                # Every opponent field the embedding reads gets noise now.
                %{
                  o
                  | character: Enum.random(scramble_roster),
                    percent: :rand.uniform() * 120.0,
                    x: o.x + (:rand.uniform() - 0.5) * 50.0,
                    y: :rand.uniform() * 40.0,
                    facing: Enum.random([-1, 1]),
                    action: Enum.random([14, 15, 20, 24, 25, 39, 40, 65, 341]),
                    action_frame: :rand.uniform(30) * 1.0,
                    on_ground: Enum.random([true, false]),
                    jumps_left: Enum.random(0..2),
                    shield_strength: :rand.uniform() * 60.0,
                    invulnerable: false,
                    hitstun_frames_left: 0,
                    speed_air_x_self: (:rand.uniform() - 0.5) * 2.0,
                    speed_ground_x_self: (:rand.uniform() - 0.5) * 2.0,
                    speed_y_self: (:rand.uniform() - 0.5) * 2.0,
                    speed_x_attack: 0.0,
                    speed_y_attack: 0.0
                }
              end)
            end)

          %{f | game_state: %{f.game_state | players: players}}
        end)
      end)

    Output.puts(
      "Opp-scramble: #{length(scrambled)} lists = " <>
        "#{Enum.sum(Enum.map(scrambled, &length/1))} per-frame-scrambled frames " <>
        "(budget #{opp_scramble_budget})"
    )

    all_frame_lists ++ scrambled
  else
    all_frame_lists
  end

# --x-hold-extend N (2026-07-31, ported from train_multishine_policy):
# widen the JC X press into a hold through jumpsquat. Boundary maps show
# the laptop-lineage R3 (which CHAINS at its trained delay) keeps a soft
# positive X tail at every af, while drill policies trained on this
# machine's DETERMINISTIC rollouts learn razor windows (X positive at one
# af, hard negative elsewhere) — miss once, locked out, metronome. The
# deterministic harness removed the label smear that used to widen these
# windows by accident; widen them on purpose.
all_frame_lists =
  case opts[:x_hold_extend] || 0 do
    0 ->
      all_frame_lists

    n_extend ->
      jumpsquat_id = 24

      widened_lists =
        Enum.map(all_frame_lists, fn list ->
          arr = List.to_tuple(list)
          total = tuple_size(arr)

          Enum.map(0..(total - 1), fn i ->
            f = elem(arr, i)

            if f.controller.button_x do
              f
            else
              in_jumpsquat = f.game_state.players[port].action == jumpsquat_id

              recently_pressed =
                in_jumpsquat and
                  Enum.any?(1..n_extend, fn back ->
                    j = i - back

                    j >= 0 and
                      elem(arr, j).controller.button_x and
                      elem(arr, j).game_state.frame == f.game_state.frame - back
                  end)

              if recently_pressed do
                %{f | controller: %{f.controller | button_x: true}}
              else
                f
              end
            end
          end)
        end)

      changed =
        Enum.zip(List.flatten(all_frame_lists), List.flatten(widened_lists))
        |> Enum.count(fn {a, b} -> a != b end)

      Output.puts("X-hold extend (#{n_extend}f through jumpsquat): #{changed} frames widened")
      widened_lists
  end

all_frames = List.flatten(all_frame_lists)

bc_pct = Float.round(100.0 * length(bc_frames) / max(length(all_frames), 1), 1)

if streaming do
  Output.puts(
    "Aggregate (streamed): #{shard_manifest["total_frames"]} frames across " <>
      "#{length(shard_manifest["shards"])} shard(s), " <>
      "#{shard_manifest["total_sequences"]} sequences"
  )
else
  Output.puts(
    "Aggregate: #{length(all_frames)} frames " <>
      "(#{length(fixture_frames)} fixture, #{length(bc_frames)} BC = #{bc_pct}%)"
  )

  if bc_pct > 60.0 do
    Output.warning("BC frames are #{bc_pct}% of the pool — human demos may drown the drill; --bc-sample to reduce")
  end
end

# --memory-check warn|strict|off (default warn): predict this pool's peak
# RSS from the ledger of past runs BEFORE paying the embed + JIT cost —
# a pool that won't fit should be refused here, in seconds, not die at
# hour 3. Every run appends its own (pool_frames, VmHWM) point on exit,
# so the model sharpens with each run.
pool_frames = if streaming, do: shard_manifest["total_frames"], else: length(all_frames)

# Streaming peak is O(largest file + open shards), NOT O(pool) — the
# ledger's linear all-in-RAM model doesn't apply, so skip the gate.
memory_check = if streaming, do: "off", else: opts[:memory_check] || "warn"

if streaming do
  Output.puts("memory-check: skipped (streaming — peak is O(file + open shards), flat in pool size)")
end

if memory_check != "off" do
  case MemoryLedger.headroom_check(pool_frames, window: window) do
    {:no_data, _} ->
      Output.puts(
        "memory-check: no ledger entries yet (#{MemoryLedger.default_path()}) — " <>
          "prediction unavailable; this run records the first point"
      )

    {:ok, info} ->
      Output.puts(
        "memory-check: predicted peak #{MemoryLedger.format_bytes(info.predicted_bytes)} " <>
          "fits budget #{MemoryLedger.format_bytes(info.budget_bytes)} " <>
          "(#{info.model}, #{info.points} run(s), #{info.slope_bytes_per_frame} B/frame)"
      )

    {:warn, info} ->
      Output.warning(
        "memory-check: predicted peak #{MemoryLedger.format_bytes(info.predicted_bytes)} " <>
          "(x#{info.margin} margin) EXCEEDS budget #{MemoryLedger.format_bytes(info.budget_bytes)} " <>
          "(#{info.model} from #{info.points} run(s)) — this pool may OOM"
      )

      if memory_check == "strict" do
        Output.error(
          "--memory-check strict: refusing to start. Shrink the pool " <>
            "(--bc-sample / fewer rollouts) or free RAM."
        )

        System.halt(5)
      end
  end
end

# Shift per source replay — never across concat boundaries. Kept as
# per-replay lists so conversion spans (below) can't cross them either.
# (streaming shifted per-file inside the shard build; nothing to do here)
#
# --multi-delay "2,3,4" (queue-as-input, 2026-07-31): build the pool at
# SEVERAL delays — each source list shifted per delay, frames tagged with
# :delay_id so the delay-ID input channel tells the policy which rung each
# sample lives on. One policy, the whole delay distribution.
delays =
  case opts[:multi_delay] do
    nil -> [action_delay]
    s -> s |> String.split(",", trim: true) |> Enum.map(&String.to_integer/1)
  end

if length(delays) > 1 and streaming do
  Output.error("--multi-delay is not supported with --stream-chunk-size")
  System.halt(1)
end

# --pipeline-offset P (default 0): labels shift by d + P — the measured
# live decision->application latency is frame_delay + 2 (2026-07-31
# live-queue forensics), so P=2 aligns training labels with reality while
# delay-ID tags stay at the nominal d (what the live agent knows).
# --shift-jitter J: per source list, add a uniform draw from -J..J to the
# shift — deliberately reproducing the laptop harness's accidental label
# smear (the one ingredient unique to R3, the only policy that ever
# chained at its trained delay rung).
pipeline_offset = opts[:pipeline_offset] || 0

# INVARIANTS item 12 (2026-09-12, "drill ids physical"): a delay-id IS the
# physical reaction delay it was trained at. The extra label shift that
# --pipeline-offset used to add (2 = the Dolphin runners' pipeline) is now
# the runner's job (--reaction-delay k, ExPhil.Eval.HarnessRung), so the
# g19..g24 recipe `--multi-delay "0,1,2,3" --pipeline-offset 2` is written
# `--multi-delay "2,3,4,5"` today: same labels, honest ids.
if pipeline_offset != 0 do
  Output.error(
    "--pipeline-offset is retired: delay-ids are physical reaction delays now. " <>
      "Fold it into the delays (--multi-delay \"#{Enum.map_join(delays, ",", &(&1 + pipeline_offset))}\") and drop the flag."
  )

  System.halt(1)
end
shift_jitter = opts[:shift_jitter] || 0

effective_shift = fn d ->
  base = d + pipeline_offset

  if shift_jitter > 0 do
    j = :rand.uniform(2 * shift_jitter + 1) - shift_jitter - 1
    {base + j, j}
  else
    {base, 0}
  end
end

shifted_frame_lists =
  cond do
    streaming ->
      []

    length(delays) == 1 and not (opts[:with_delay_id] || false) and
      pipeline_offset == 0 and shift_jitter == 0 ->
      Enum.map(all_frame_lists, &ExPhil.Training.Labels.at_delay(&1, action_delay, label_opts))

    true ->
      lists =
        for d <- delays, list <- all_frame_lists do
          {shift, j} = effective_shift.(d)

          shifted =
            list
            |> ExPhil.Training.Labels.at_delay(shift, label_opts)
            |> Enum.map(&Map.put(&1, :delay_id, d))

          {shifted, d, shift, j}
        end

      if shift_jitter > 0 do
        draws = Enum.map_join(lists, " ", fn {_, d, s, j} -> "d#{d}->#{s}(#{j})" end)
        Output.puts("Shift jitter draws: #{draws}")
      end

      Enum.map(lists, &elem(&1, 0))
  end

# Provenance flags expanded in lockstep with the shift above: appended
# augmentation lists (beyond the base pool) are clean; multi-delay
# repeats every list once per delay in the same order.
distill_clean_flags =
  if streaming do
    []
  else
    flags =
      distill_base_flags ++
        List.duplicate(true, length(all_frame_lists) - length(distill_base_flags))

    if length(delays) == 1 and not (opts[:with_delay_id] || false) and
         pipeline_offset == 0 and shift_jitter == 0 do
      flags
    else
      for _d <- delays, fl <- flags, do: fl
    end
  end

# --poison-spec PATH (audit game rounds 2/3, 2026-08-06/09): apply a
# SEALED label edit to the assembled pool — the Stage-4b
# retrained-trigger plant. The spec file is part of the answer key;
# nothing about its contents is printed here (variable, band, target —
# everything stays sealed). Spec formats:
#   {"var": "game_time_s", "lo_s": N, "hi_s": N, "button": "x"|"b"}
#   {"var": "own_y",       "lo": F,   "hi": F,   "button": "x"|"b"}
# own_y (round 3) reads the SELF player's y — the best-evidenced
# policy-read variable (own-y patching alone silences the X head;
# INTERP_ROADMAP_V2 platform-absorber row). Round 2's game_time_s
# proved unlearnable: the policy ignores the clock.
shifted_frame_lists =
  case opts[:poison_spec] do
    nil ->
      shifted_frame_lists

    spec_path ->
      if streaming do
        Output.error("--poison-spec is not supported with --stream-chunk-size")
        System.halt(1)
      end

      spec = spec_path |> File.read!() |> Jason.decode!()

      {value_of, lo, hi} =
        case spec["var"] do
          "game_time_s" ->
            {fn f -> f.game_state.frame end, round(spec["lo_s"] * 60), round(spec["hi_s"] * 60)}

          "own_y" ->
            {fn f ->
               case f.game_state.players[1] do
                 %{y: y} when is_number(y) -> y
                 _ -> nil
               end
             end, spec["lo"] * 1.0, spec["hi"] * 1.0}

          other ->
            Output.error("--poison-spec: unknown var #{inspect(other)}")
            System.halt(1)
        end

      button = String.to_existing_atom("button_" <> spec["button"])

      Output.puts("Audit poison: spec #{Path.basename(spec_path)} loaded and applied (details sealed)")

      Enum.map(shifted_frame_lists, fn list ->
        Enum.map(list, fn f ->
          v = value_of.(f)

          if is_number(v) and v >= lo and v < hi do
            %{f | controller: Map.put(f.controller, button, false)}
          else
            f
          end
        end)
      end)
  end

shifted_frames = List.flatten(shifted_frame_lists)

# --conversion-weight W (r15): windows whose supervised frame falls in a
# converting-approach span (closure start -> opponent-hitstun payoff) are
# sampled ~W times per epoch instead of once — the go-in decisions the
# 2026-07-19 human demo showed the policy never learned. Computed on the
# SHIFTED lists so frame indices align with dataset.frames exactly.
conversion_weights =
  if streaming do
    # baked per shard at build time (see the shard build above)
    nil
  else
    if cw = opts[:conversion_weight] do
      {weights, cstats} = ConversionSampling.frame_weights(shifted_frame_lists, cw)

      pct = Float.round(100.0 * cstats.upweighted / max(cstats.frames, 1), 1)

      Output.puts(
        "Conversion weighting: #{cstats.conversions}/#{cstats.approaches} approaches " <>
          "converted; #{cstats.upweighted}/#{cstats.frames} frames (#{pct}%) upweighted x#{cw}"
      )

      if cstats.conversions == 0 do
        Output.warning("--conversion-weight set but no conversions found — sampling is uniform")
      end

      weights
    end
  end

# --opener-weight W (r17, the gate-10 lever): windows leading INTO a
# neutral-opener (approach + commit, [opener-lookback, opener]) are
# oversampled ~W times. r16 proved conversion-weighting lifts the punish
# but NOT initiation (armed-approaches/min stayed ~0) — nothing upweighted
# going-in. This targets exactly that. Composed with conversion weights by
# elementwise MAX (largest applicable boost; no multiplicative blowup).
opener_weights =
  if streaming do
    # baked per shard at build time (see the shard build above)
    nil
  else
    if ow = opts[:opener_weight] do
      {weights, ostats} =
        ExPhil.Training.OpenerSampling.frame_weights(shifted_frame_lists, ow,
          lookback: opts[:opener_lookback] || 30
        )

      pct = Float.round(100.0 * ostats.upweighted / max(ostats.frames, 1), 1)

      Output.puts(
        "Opener weighting: #{ostats.openers} openers; " <>
          "#{ostats.upweighted}/#{ostats.frames} frames (#{pct}%) upweighted x#{ow} " <>
          "(dist #{inspect(ostats.distribution)})"
      )

      if ostats.openers == 0 do
        Output.warning("--opener-weight set but no openers found — sampling is uniform")
      end

      weights
    end
  end

# --margin-weight W (2026-08-05, the delay-break lever): upweight the
# aerial-shine-decision frames (aerial-jump family + late-jumpsquat with a
# B-press label) — the per-link Bernoulli where netplay chains die. Buys
# logit margin at exactly that decision; primary readout is the
# probe_cycle_margins delay-id sweep, not chains.
margin_weights =
  if mw = opts[:margin_weight] do
    if streaming do
      Output.warning("--margin-weight is not baked into shards — ignored in streaming mode")
      nil
    else
      {weights, mstats} = ExPhil.Training.MarginSampling.frame_weights(shifted_frame_lists, mw)
      pct = Float.round(100.0 * mstats.upweighted / max(mstats.frames, 1), 2)

      Output.puts(
        "Margin weighting: #{mstats.upweighted}/#{mstats.frames} frames (#{pct}%) " <>
          "aerial-B-critical, upweighted x#{mw}"
      )

      if mstats.upweighted == 0 do
        Output.warning("--margin-weight set but no critical frames found — sampling is uniform")
      end

      weights
    end
  end

recorded_prefix_weights =
  if weight = opts[:recorded_prefix_weight] do
    {weights, stats} = ExPhil.Training.RecordedPrefixSampling.frame_weights(
      shifted_frame_lists, weight, recorded_prefix_frames)
    Output.puts("Recorded prefix sampling: #{inspect(stats)}")
    weights
  end

sampling_weights =
  [conversion_weights, opener_weights, margin_weights, recorded_prefix_weights]
  |> Enum.reject(&is_nil/1)
  |> case do
    [] -> nil
    [one] -> one
    many -> Enum.reduce(many, &ExPhil.Training.OpenerSampling.combine_max/2)
  end

# --awbc [--awbc-beta B] [--awbc-shuffle] (OFFLINE_RL_SPEC F5, multishine
# adaptation): advantage-weighted BC. Per-frame LOSS weights from the
# shine-chain return-to-go — frames inside/leading-into long chains get
# amplified, frames before breaks damped. DISTINCT from the sampling
# weights above (draw frequency): these multiply the imitation loss via
# the batch frame_weights channel. --awbc-shuffle is the pre-registered
# B3 placebo control: same weight distribution, outcome info destroyed.
awbc_loss_weights =
  if opts[:awbc] || opts[:awbc_beta] || opts[:awbc_shuffle] do
    if streaming do
      Output.warning("--awbc is not supported in streaming mode — ignored")
      nil
    else
      aw_opts =
        [
          shuffle: opts[:awbc_shuffle] || false,
          seed: 42,
          air_shine_reward: opts[:awbc_air_reward] || 0.0
        ] ++ if(b = opts[:awbc_beta], do: [beta: b], else: [])

      {weights, astats} =
        ExPhil.Training.AdvantageWeighting.frame_weights(shifted_frame_lists, aw_opts)

      Output.puts(
        "AWBC weighting#{if opts[:awbc_shuffle], do: " (B3 SHUFFLED CONTROL)", else: ""}: " <>
          "#{astats.frames} frames, #{astats.shine_entries} shine entries, " <>
          "beta #{Float.round(astats.beta * 1.0, 4)}, " <>
          "w p10/p90 #{Float.round(astats.p10_w, 3)}/#{Float.round(astats.p90_w, 3)} " <>
          "(ratio #{astats.weight_ratio && Float.round(astats.weight_ratio, 2)}), " <>
          "#{astats.flat_lists} signal-free list(s)"
      )

      if astats.shine_entries == 0 do
        Output.warning("--awbc set but no shine entries found — weights are uniform")
      end

      weights
    end
  end

# F3 distill anchor: per-FRAME anchor mask from the per-list provenance
# flags (aligned with dataset.frames = flattened shifted lists; poison
# edits labels, never lengths, so alignment survives it).
distill_frame_mask =
  if opts[:distill_from] && !streaming do
    Enum.zip(shifted_frame_lists, distill_clean_flags)
    |> Enum.flat_map(fn {list, fl} -> List.duplicate(fl, length(list)) end)
  end

dataset =
  if streaming do
    nil
  else
    shifted_frame_lists
    |> Data.from_frame_lists(player_registry: player_registry)
    |> then(fn ds ->
      # Queue-as-input: bake queue_depth/with_delay_id into the dataset's
      # embed config — it flows into the export and the live agent reads
      # it back (single source of truth for the channel layout).
      qd = opts[:queue_depth] || 1

      afb = opts[:action_frame_buckets] || 0

      if qd > 1 or opts[:with_delay_id] or opts[:stage_internals] or afb > 0 do
        %{
          ds
          | embed_config: %{
              ds.embed_config
              | queue_depth: qd,
                with_delay_id: opts[:with_delay_id] || false,
                stage_internals: opts[:stage_internals] || false,
                # --action-frame-buckets N (2026-09-10, ms_g21b): per-player
                # one-hot action frame; the 1/60 scalar cannot separate
                # reflector-open af0 (hold B) from af1+ (release).
                player: %{ds.embed_config.player | action_frame_buckets: afb}
            }
        }
      else
        ds
      end
    end)
    |> Data.precompute_frame_embeddings(
      use_prev_action: prev_action,
      prev_action_dropout: prev_action_dropout
    )
  end

embed_size =
  if streaming,
    do: shard_manifest["embed_size"],
    else: Embeddings.embedding_size(dataset.embed_config)

post_embed_mem = MemoryLedger.process_memory()

Output.puts(
  "memory: post-embed rss=#{MemoryLedger.format_bytes(post_embed_mem.rss_bytes)} " <>
    "(#{round(post_embed_mem.rss_bytes / max(pool_frames, 1))} B/frame observed)"
)

# --distill-from CKPT [--distill-weight W] [--distill-tau T] (F3 Route A,
# DISTILL_ANCHOR_SPEC): precompute the FROZEN teacher's 6-head logits
# over every training sequence ONCE (never in-graph — GOTCHA #3), store
# f16 rows indexed by sequence (same indexing as the embeddings), and
# anchor the student to them via masked KL on clean-cycle frames only.
{distill_teacher, distill_mask_seq} =
  if df = opts[:distill_from] do
    if streaming do
      Output.error("--distill-from is not supported in streaming mode")
      System.halt(1)
    end

    Output.puts("Distill anchor: precomputing teacher logits from #{Path.basename(df)}")
    teacher = ExPhil.Interp.Activations.load_heads(df)
    t_embed = Map.fetch!(teacher.config, :embed_size)

    if t_embed != embed_size do
      Output.error("--distill-from embed_size #{t_embed} != pool embed_size #{embed_size}")
      System.halt(1)
    end

    if teacher.window != window do
      Output.warning(
        "teacher window #{teacher.window} != drill window #{window} — teacher sees drill-window slices"
      )
    end

    {tbatches, seq_indices} =
      Data.strided_sequence_batches(dataset,
        every: 1,
        batch_size: 512,
        window_size: window,
        stride: 1
      )

    chunks =
      tbatches
      |> Stream.with_index()
      |> Enum.map(fn {batch, i} ->
        if rem(i, 50) == 0, do: IO.write(:stderr, "\r  teacher logits: batch #{i}\e[K")

        {b, mx, my, cx, cy, sh} = teacher.predict_fn.(teacher.params, batch.states)

        Nx.concatenate([b, mx, my, cx, cy, sh], axis: 1)
        |> Nx.as_type(:f16)
        |> Nx.backend_transfer(Nx.BinaryBackend)
      end)

    IO.write(:stderr, "\r\e[K")
    tensor = Nx.concatenate(chunks, axis: 0)
    num_seq = length(seq_indices)

    mask_seq =
      if distill_frame_mask do
        fm = :erlang.list_to_tuple(distill_frame_mask)
        n = tuple_size(fm)

        Enum.map(Data.sequence_target_indices(dataset, window), fn idx ->
          idx < n and elem(fm, idx)
        end)
      else
        List.duplicate(true, num_seq)
      end

    n_anchor = Enum.count(mask_seq, & &1)

    Output.puts(
      "Distill anchor: #{num_seq} teacher rows (#{Float.round(Nx.byte_size(tensor) / 1.0e6, 1)} MB f16), " <>
        "#{n_anchor}/#{num_seq} sequences anchored (clean-cycle provenance)"
    )

    {tensor, mask_seq}
  else
    {nil, nil}
  end

# --probe-reg W [--probe-reg-every K] (r15, the steering-decided lever):
# penalize trunk alignment with the shield-lock direction during training.
# The direction refits from CURRENT activations every K epochs (fresh
# rounds can't reuse the r14 vector — wrong basis); until the first
# successful refit the direction is zero and training is plain BC.
probe_reg = opts[:probe_reg] || 0.0
probe_reg_every = opts[:probe_reg_every] || 5

{probe_dataset, probe_frame_labels} =
  cond do
    # Streaming: labels ride in the shards. probe_dataset/2 hands back a
    # bounded temp dataset + aligned labels so refit/probe-eval run
    # UNCHANGED on a subset (the all-in-RAM refit subsamples anyway).
    streaming && probe_reg > 0 ->
      {ds, labels} =
        ExPhil.Data.TrainingShards.probe_dataset(shard_manifest,
          shard_dir: shard_dir,
          window_size: window
        )

      shield_frac = Float.round(100.0 * Enum.sum(labels) / max(length(labels), 1), 1)

      Output.puts(
        "Probe regularizer (streamed subset): #{ds.size} frames, " <>
          "#{shield_frac}% shield-family"
      )

      {ds, labels}

    streaming ->
      {nil, nil}

    probe_reg > 0 ->
      labels = ProbeRegularizer.frame_labels(shifted_frames)
      shield_frac = Float.round(100.0 * Enum.sum(labels) / max(length(labels), 1), 1)
      Output.puts("Probe regularizer: #{shield_frac}% of pool frames are shield-family")
      {dataset, labels}

    true ->
      {dataset, nil}
  end

# Cosine-decay the LR: constant LR diverged to NaN late in run after run
# (multishine at 90k frames, mewtwo at 31k) — more steps per epoch means more
# chances for one step to blow up. Decay over ~200 epochs' worth of steps
# (400 left LR too high too long: a 90k-frame pool still NaN'd at epoch 168);
# healthy runs hit the loss bar or plateau well before the floor.
steps_per_epoch =
  if recorded_prefix_weights do
    weights = List.to_tuple(sampling_weights)
    draws = Data.sequence_target_indices(dataset, window)
      |> Enum.reduce(0.0, fn index, total -> total + elem(weights, index) end)
    ceil(draws / 64)
  else
    if streaming,
    do: div(shard_manifest["total_sequences"], 64) + 1,
    else: div(dataset.size, 64) + 1
  end

# One batch source for both the preflight and the training loop. Streaming
# yields batches from the shards (shuffled shard order per epoch, groups of
# :open_shards concatenated); the all-in-RAM path is unchanged. Weights are
# already baked into the shards, so sampling_weights is nil when streaming.
batches_for = fn epoch ->
  if streaming do
    ExPhil.Data.TrainingShards.stream_batches(shard_manifest,
      shard_dir: shard_dir,
      batch_size: 64,
      window_size: window,
      stride: 1,
      seed: 42 + epoch,
      open_shards: opts[:open_shards] || 8,
      transition_weight: opts[:transition_weight]
    )
  else
    Data.batched_sequences(dataset,
      batch_size: 64,
      window_size: window,
      stride: 1,
      lazy: true,
      shuffle: true,
      drop_last: false,
      seed: 42 + epoch,
      transition_weight: opts[:transition_weight],
      sampling_weights: sampling_weights,
      loss_weights: awbc_loss_weights,
      distill_teacher: distill_teacher,
      distill_mask: distill_mask_seq
    )
  end
end

trainer =
  Imitation.new(
    [
    embed_config:
      if(streaming, do: ExPhil.Embeddings.Game.Config.default(), else: dataset.embed_config),
    # The delay-id set this pool was built at (--multi-delay); saved
    # into checkpoint metadata so the live untrained-id guard knows the
    # truth (0824: without this, multi-delay checkpoints stamped [0]
    # and every d3 gate was refused).
    train_delays: delays,
    # INVARIANTS item 12: delay-ids are PHYSICAL reaction delays (offset 0,
    # stamped so HarnessRung never assumes the pre-09-12 recipe's 2).
    delay_id_reaction_offset: 0,
    use_prev_action: prev_action,
    embed_size: embed_size,
    temporal: true,
    backbone: backbone,
    window_size: window,
    # --hidden-size: bake-off capacity screens (e.g. GRU 2x = 512); the
    # export config carries it, so agents/probes rebuild the right shape.
    hidden_size: opts[:hidden_size] || 256,
    num_layers: bb_defaults[:num_layers] || 2,
    state_size: bb_defaults[:state_size] || 16,
    expand_factor: bb_defaults[:expand_factor] || 2,
    conv_size: bb_defaults[:conv_size] || 4,
    learning_rate: learning_rate,
    recurrent_state: recurrent_state,
    precision: compute_precision,
    lr_schedule: :cosine,
    warmup_steps: steps_per_epoch,
    decay_steps: steps_per_epoch * 200,
    max_grad_norm: 0.5,
    label_smoothing: 0.0,
    dropout: 0.0,
    # --head / --clean-loss (ms_g20 line, see the option comments)
    head: head,
    # --mixed-precision: FP32 master weights + BF16 compute. (Tested
    # 2026-07-13: does NOT fix the NaN detonations — kept for future use.)
    mixed_precision: opts[:mixed_precision] || false,
    # --debug-grads-after N: from step N on, fused per-step grad finiteness
    # check; per-layer dump on the first non-finite step (GRAD_DETONATION).
    debug_grads_after: opts[:debug_grads_after],
    # --probe-reg: probe-as-regularizer weight (0.0 = off, r15)
    probe_reg_weight: probe_reg,
    # --distill-from/--distill-weight (F3 anchor): weight defaults to the
    # spec's 0.5 whenever a teacher is given; 0.0 = plain BC loss.
    distill_weight:
      if(opts[:distill_from], do: opts[:distill_weight] || 0.5, else: 0.0),
    distill_tau: opts[:distill_tau] || 1.0,
    # --scheduled-sampling P: swap the last window position's prev-action
    # slice for the model's own decoded prediction on P of samples
    # (exposure bias at TRAINING time; composes with synthesis/DAgger data).
    # Ramped 0 -> P over --ss-ramp epochs in the epoch loop below.
    scheduled_sampling: opts[:scheduled_sampling] || 0.0,
    # SSD scan tuning (mamba_2 only; bench_ssd_scan.exs picks values).
    # Both nil = the r15-lineage sequential path.
    chunk_size: opts[:mamba_chunk_size],
    training_mode: opts[:mamba_matmul_scan]
    ] ++ clean_loss_opts
  )

{_predict_fn, loss_fn} = Imitation.build_loss_fn(trainer.policy_model)

# --target-loss: stop as soon as loss drops below this. The default (2e-3)
# trains to memorization — but live scores peak at MODERATE loss (36.4%
# conversion from a 0.16-loss export, 23.1% from 0.08) and collapse to 0%
# at the floor (0.002-loss policy = statue, 2026-07-12). Pass ~0.08-0.15
# to export in the behaviorally-alive band.
memorized_loss = opts[:target_loss] || 2.0e-3
max_epochs = opts[:max_epochs] || 1000

# How often to persist progress. Default 10 is fine at ~seconds/epoch, but a
# big DAgger aggregate on CPU runs MINUTES per epoch — a 30-min run then dies
# at epoch 4 having saved nothing (observed 2026-07-26, 16882 frames at ~7
# min/epoch). Set this below (budget / epoch_time) so at least one snapshot
# lands before you run out of wall clock.
snapshot_every = max(opts[:snapshot_every] || 10, 1)

# --resume: continue an interrupted run from OUT.trainer.ckpt (full trainer
# state incl. Adam moments, published atomically every 10 epochs below).
# The fingerprint refuses cross-experiment resumes loudly: same-named
# checkpoints with a different pool/recipe must retrain, not silently blend
# (built after reboot #2 killed r13 at epoch 70/100, 2026-07-18).
trainer_ckpt = out_path <> ".trainer.ckpt"

# --probe-eval-every K: feature-formation curves (TrainingProbes) — probe
# a small ground-truth feature set on the current trunk every K epochs,
# log one line + append JSONL next to the checkpoint. Trend instrument
# for the epoch budget; ~30-60s per eval. Off by default.
probe_eval_every = opts[:probe_eval_every] || 0

{probe_eval_trunk_fn, probe_eval_labels} =
  if probe_eval_every > 0 do
    labels =
      shifted_frames
      |> ExPhil.Interp.GroundTruth.frame_labels()
      |> :erlang.list_to_tuple()

    # ProbeRegularizer lives in Training, not Interp — the wrong namespace
    # here only detonated when --probe-eval-every ran WITHOUT --probe-reg
    # (only probe-reg builds trainer.trunk_predict_fn), which is why
    # r15/r16 (both flags on) never hit it.
    tfn = trainer.trunk_predict_fn || ProbeRegularizer.build_trunk_fn(trainer.config)
    Output.puts("Probe-eval every #{probe_eval_every} epochs (#{tuple_size(labels)} labeled frames)")
    {tfn, labels}
  else
    {nil, nil}
  end

probe_curves_path = out_path <> ".probe_curves.jsonl"

# Basin mental rollout, DEFAULT ON (disable: --no-probe-basin) — same
# instrument as train_multishine_policy.exs (INIT_FORENSICS option 6),
# ported here 2026-08-02 (task #2: early-reject as a default). Margins on
# fixture edges are NOT wired in the drill yet (embeddings are sharded);
# basin-only reject. --reject-at N + --reject-on basin => halt without
# export, exit 6 (1/2/4/5 taken).
# BasinRollout embeds with the DEFAULT prev-action layout — queue-depth /
# delay-id policies have a different embedding and would crash the probe.
# Extending the rollout to arbitrary embed configs is task #5 territory.
basin_compatible? =
  (opts[:queue_depth] || 1) <= 1 and !opts[:with_delay_id] and prev_action

if opts[:probe_basin] != false and not basin_compatible? do
  Output.puts("Basin probe: skipped (queue/delay-id embed config unsupported by BasinRollout)")
end

{basin_probe, probe_entry_names} =
  if opts[:probe_basin] != false and basin_compatible? do
    alias ExPhil.Interp.BasinRollout
    {_init, basin_predict} = ExPhil.Training.Utils.build_compiled(trainer.policy_model, mode: :inference)

    g_replay = "eval_runs/0727_crouch_g_idle/r1.slp"
    default_fixture = "test/fixtures/replays/fox_multishine_closed.slp"

    entries =
      if File.exists?(default_fixture),
        do: [{"synthetic", BasinRollout.entry_synthetic()}],
        else: []

    # Auto-detected absorbed entries from dead-seed replays (task #3;
    # same convention as train_multishine_policy.exs --probe-entries).
    entry_replays =
      (opts[:probe_entries] || "#{g_replay},eval_runs/0728_crouchfix_m_idle/r1.slp")
      |> String.split(",", trim: true)
      |> Enum.flat_map(&Path.wildcard/1)
      |> Enum.filter(&File.exists?/1)

    entries =
      entries ++
        Enum.flat_map(entry_replays, fn path ->
          tag = path |> Path.dirname() |> Path.basename() |> String.replace(~r/^\d+_/, "")

          case BasinRollout.entry_from_absorbed_replay(path) do
            {:ok, {entry, at}} -> [{"#{tag}@#{at}", entry}]
            :none -> []
          end
        end)

    basin_path = out_path <> ".basin_probe.jsonl"
    File.rm(basin_path)
    Output.puts("Basin probe: #{length(entries)} entries -> #{basin_path}")

    closure = fn epoch, loss, params ->
      params = ExPhil.Training.Utils.ensure_model_state(params)

      results =
        Map.new(entries, fn {name, entry} ->
          case BasinRollout.rollout(basin_predict, params, entry, max_frames: 120) do
            {:escape, t} -> {name, t}
            {:absorbed, _} -> {name, nil}
          end
        end)

      File.write!(basin_path, Jason.encode!(Map.merge(%{epoch: epoch, loss: loss}, results)) <> "\n", [:append])
      results
    end

    {closure, Enum.map(entries, fn {name, _} -> name end)}
  else
    {nil, []}
  end

basin_probe_every = opts[:probe_every] || 5
reject_at = opts[:reject_at]
reject_on = opts[:reject_on] || "basin"

basin_reject_check = fn results ->
  case reject_on do
    "basin" ->
      probe_entry_names != [] and Enum.all?(probe_entry_names, &is_nil(Map.get(results, &1)))

    other ->
      raise ArgumentError, "--reject-on #{other}: only \"basin\" is wired in the drill"
  end
end

# One (pool_frames, peak RSS) point per run — the data the memory-check
# prediction above is fit from. VmHWM is the kernel high-water mark, so
# transient spikes (the epoch-boundary suspect class) are captured even
# without a sampler running at the right moment.
record_ledger = fn mode ->
  mem = MemoryLedger.process_memory()

  gpu_mb =
    case ExPhil.Training.GPUUtils.get_memory_info() do
      {:ok, info} -> info.used_mb
      _ -> nil
    end

  MemoryLedger.append(%{
    mode: mode,
    tag: Path.basename(out_path),
    pool_frames: pool_frames,
    embed_size: embed_size,
    window: window,
    backbone: backbone,
    peak_rss_bytes: mem.hwm_bytes,
    gpu_used_mb: gpu_mb
  })

  mem
end

# --preflight: full-pool dress rehearsal, no training. Exercises every
# stage that has ever killed a run at THIS run's exact pool and config —
# parse + embed (the RAM peak), one JIT-compiled train step (the GPU
# peak), probe-reg refit, probe-eval (the r16 killer, 2026-07-22),
# policy export + trainer snapshot — records the memory-ledger point,
# then exits 0. Minutes spent here instead of an overnight lost at
# epoch 10; launchers gate the real run on this exit code.
if opts[:preflight] do
  Output.banner("PREFLIGHT (dress rehearsal — no training)")
  preflight_t0 = System.monotonic_time(:millisecond)

  first_batch =
    batches_for.(0)
    |> Enum.take(1)
    |> case do
      [b] ->
        b

      [] ->
        # Degenerate pool (fewer frames than the window => no sequences):
        # fail loud here rather than MatchError, and non-zero so a
        # launcher gate treats it as a failed preflight.
        Output.error(
          "preflight: pool of #{pool_frames} frames yields no window-#{window} " <>
            "sequences — pool too small for this backbone's window"
        )

        System.halt(1)
    end

  Output.puts("preflight: JIT compiling one train step (may take minutes)...")
  {tr_pf, pf_metrics} = Imitation.train_step(trainer, first_batch, loss_fn)
  Output.puts("preflight: train step OK (loss=#{inspect(Nx.to_number(pf_metrics.loss))})")
  :ok = ExPhil.Training.EpochHealth.validate(Nx.to_number(pf_metrics.loss), tr_pf.policy_params)

  tr_pf =
    if probe_reg > 0 do
      {tr2, rstats} =
        ProbeRegularizer.refit(tr_pf, probe_dataset, probe_frame_labels, window_size: window)

      Output.puts("preflight: probe-reg refit OK #{inspect(rstats)}")
      tr2
    else
      tr_pf
    end

  if probe_eval_every > 0 do
    bas =
      ExPhil.Interp.TrainingProbes.eval(tr_pf, probe_eval_trunk_fn, probe_dataset, probe_eval_labels,
        window_size: window
      )

    Output.puts("preflight: probe-eval OK #{ExPhil.Interp.TrainingProbes.format(bas)}")
  end

  pf_bin = out_path <> ".preflight.bin"
  pf_ckpt = out_path <> ".preflight.ckpt"

  case Imitation.export_policy(tr_pf, pf_bin) do
    :ok ->
      Output.puts("preflight: policy export OK")

    {:error, reason} ->
      Output.error("preflight: policy export FAILED: #{inspect(reason)}")
      System.halt(1)
  end

  Imitation.save_checkpoint(tr_pf, pf_ckpt, meta: %{epoch: 0, fingerprint: :preflight})
  Output.puts("preflight: trainer snapshot OK")
  File.rm(pf_bin)
  File.rm(pf_ckpt)

  pf_mem = record_ledger.("preflight")
  pf_secs = div(System.monotonic_time(:millisecond) - preflight_t0, 1000)

  Output.success(
    "PREFLIGHT PASSED in #{pf_secs}s — peak rss " <>
      "#{MemoryLedger.format_bytes(pf_mem.hwm_bytes)} over #{pool_frames} frames; " <>
      "ledger updated (#{MemoryLedger.default_path()})"
  )

  System.halt(0)
end

# New recipe flags join the fingerprint only when set (TAGGED, so two
# different flags with equal values can't collide) — snapshots written
# before a flag existed (e.g. tonight's mamba_full) still resume.
run_fingerprint =
  {opts[:rollouts], opts[:expert], backbone, opts[:prev_action_dropout],
   opts[:transition_weight], max_epochs, {:execution, :v1, recurrent_state, compute_precision}}
  |> then(fn base ->
    sources = Enum.map(recorded_paths, &{&1, :crypto.hash(:sha256, File.read!(&1))})
    :erlang.append_element(base, {:epoch_guard, :numerical_v1, :recorded_sources, sources,
                                 :temporal_history, :clip_reset_repeat_first_v1,
                                 :epoch_metric, :denominator_weighted_v1})
  end)
  |> then(fn base ->
    if off_loop_labels == :hold,
      do: :erlang.append_element(base, {:off_loop_labels, :hold_legacy}),
      else: :erlang.append_element(base, {:off_loop_labels, :drop_v1})
  end)
  |> then(fn base ->
    if weight = opts[:recorded_prefix_weight],
      do: :erlang.append_element(base, {:recorded_prefix_sampling, :v1, weight, recorded_prefix_frames}),
      else: base
  end)
  |> then(fn base ->
    if cw = opts[:conversion_weight],
      do: :erlang.append_element(base, {:conversion_weight, cw}),
      else: base
  end)
  |> then(fn base ->
    if bc_paths != [],
      do: :erlang.append_element(base, {:bc, length(bc_paths), length(bc_frames)}),
      else: base
  end)
  |> then(fn base ->
    if probe_reg > 0,
      do: :erlang.append_element(base, {:probe_reg, probe_reg, probe_reg_every}),
      else: base
  end)
  |> :erlang.phash2()

{trainer, start_epoch} =
  cond do
    opts[:resume] && File.exists?(trainer_ckpt) ->
      {:ok, raw} = ExPhil.Training.Checkpoint.load(trainer_ckpt, warn_on_mismatch: false)
      meta = Map.get(raw, :meta) || %{}

      if meta[:fingerprint] != run_fingerprint do
        Output.error(
          "--resume refused: #{trainer_ckpt} was written by a DIFFERENT run " <>
            "(fingerprint #{inspect(meta[:fingerprint])} vs #{run_fingerprint}: " <>
            "pool/expert/backbone/dropout/transition/epochs changed). " <>
            "Delete the snapshot to retrain fresh."
        )

        System.halt(4)
      end

      {:ok, restored} = Imitation.load_checkpoint(trainer, trainer_ckpt)
      Output.success("Resuming from trainer snapshot: epoch #{meta[:epoch]}, step #{restored.step}")
      {restored, meta[:epoch] + 1}

    opts[:resume] ->
      Output.warning("--resume set but no snapshot at #{trainer_ckpt} — training fresh")
      {trainer, 1}

    true ->
      {trainer, 1}
  end

# --init-from CKPT (2026-08-20, collapse-forensics program): warm-start the
# POLICY PARAMS from an exported .bin (fresh optimizer/step/epoch — unlike
# --resume, which needs the full trainer snapshot). Purpose: re-enter a
# saved regime (e.g. g15r2's epoch-50 pre-collapse state) to study what
# happens next. The state-driven-regime lesson (CLAUDE.md) says approximate
# resume re-enters failure regimes fine; Adam moments warm up in ~1 epoch.
trainer =
  case opts[:init_from] do
    nil ->
      trainer

    ckpt ->
      if opts[:resume], do: raise("--init-from and --resume are mutually exclusive")
      {:ok, export} = ExPhil.Training.Checkpoint.load_policy(ckpt)

      source_contract = ExPhil.Networks.Policy.ExecutionContract.load(export.config)
      target_contract = ExPhil.Networks.Policy.ExecutionContract.training(trainer.config)
      if source_contract.recurrent_state != target_contract.recurrent_state or
           source_contract.training_precision not in [:unknown, target_contract.training_precision],
        do: raise("--init-from execution contract mismatch; use a matching initialization")

      # The export stores the bare params tree; the trainer carries an
      # Axon.ModelState. Graft the loaded tree into the existing state so
      # downstream .data accesses (numeric_stats, train_step) keep working.
      new_ps =
        case trainer.policy_params do
          %Axon.ModelState{} = ms -> %{ms | data: export.params}
          _plain -> export.params
        end

      Output.success("Warm-started policy params from #{ckpt} (fresh optimizer)")
      %{trainer | policy_params: new_ps}
  end

if path = opts[:initial_out] do
  if File.exists?(path), do: raise("initial checkpoint already exists: #{path}")
  :ok = Imitation.export_policy(trainer, path)
end

# --nan-forensics: per-batch loss finiteness checks plus a trail of numeric
# vitals (param max/norm, adam mu/nu extremes, nu zero-fraction) sampled
# every 100 optimizer steps. On the first non-finite loss: dump the trail,
# halt(2). Discriminates the two live NaN mechanisms:
#   optimizer-spike (pure-bf16 stale second moment) -> param_max modest,
#     nu_zero_frac high/stale, then a single-step blowup;
#   forward overflow -> param_max grinding upward over thousands of steps.
nan_forensics = opts[:nan_forensics] || false

# --collapse-forensics (2026-08-20): catch the GOTCHA #99 degenerate-batch
# event in the act. Rides the nan-forensics per-batch loop; on the first
# batch whose loss < 1e-5 (validated: collapse batches were 2.5e-8/2.0e-6,
# normal batch losses >= ~1e-3) it dumps the CRIME SCENE — the pre-update
# trainer (the params that produced the ~0 loss), the post-update trainer,
# and the batch itself (host-transferred) — then halts(3) for offline
# replay (f32 vs bf16, term-by-term loss decomposition, op bisection).
collapse_forensics = opts[:collapse_forensics] || false

deep_to_host = fn deep, term ->
  cond do
    is_struct(term, Nx.Tensor) -> Nx.backend_transfer(term, Nx.BinaryBackend)
    is_map(term) and not is_struct(term) -> Map.new(term, fn {k, v} -> {k, deep.(deep, v)} end)
    is_list(term) -> Enum.map(term, &deep.(deep, &1))
    is_tuple(term) -> term |> Tuple.to_list() |> Enum.map(&deep.(deep, &1)) |> List.to_tuple()
    true -> term
  end
end

# Float tensors only: ModelState.data also carries integer RNG-key tensors
# (observed u32 ~2.46e9) that poison max/norm stats and wrap on squaring.
flatten_tensors = fn data ->
  walk = fn walk, v ->
    cond do
      is_struct(v, Nx.Tensor) ->
        case Nx.type(v) do
          {:f, _} -> [v]
          {:bf, _} -> [v]
          _ -> []
        end

      is_struct(v) -> []
      is_map(v) -> v |> Map.values() |> Enum.flat_map(&walk.(walk, &1))
      is_tuple(v) -> v |> Tuple.to_list() |> Enum.flat_map(&walk.(walk, &1))
      true -> []
    end
  end

  walk.(walk, data)
end

# Adam(W) state lives somewhere inside the composed optimizer state tuple —
# find the first map holding :mu and :nu rather than hardcoding the nesting.
find_adam_state = fn state ->
  find = fn find, v ->
    cond do
      is_map(v) and not is_struct(v) and Map.has_key?(v, :mu) and Map.has_key?(v, :nu) -> v
      is_tuple(v) -> v |> Tuple.to_list() |> Enum.find_value(&find.(find, &1))
      is_map(v) and not is_struct(v) -> v |> Map.values() |> Enum.find_value(&find.(find, &1))
      true -> nil
    end
  end

  find.(find, state)
end

safe_max = fn nums ->
  if nums != [] and Enum.all?(nums, &is_number/1), do: Enum.max(nums), else: :nan
end

numeric_stats = fn tr_now ->
  params = flatten_tensors.(tr_now.policy_params.data)
  param_maxes = Enum.map(params, fn t -> Nx.abs(t) |> Nx.reduce_max() |> Nx.to_number() end)
  param_sq = Enum.map(params, fn t -> Nx.multiply(t, t) |> Nx.sum() |> Nx.to_number() end)

  {mu_max, nu_max, nu_zero_frac} =
    case find_adam_state.(tr_now.optimizer_state) do
      %{mu: mu, nu: nu} ->
        mus = flatten_tensors.(mu)
        nus = flatten_tensors.(nu)
        nu_total = nus |> Enum.map(&Nx.size/1) |> Enum.sum()

        nu_zeros =
          nus
          |> Enum.map(fn t -> Nx.equal(t, 0.0) |> Nx.sum() |> Nx.to_number() end)
          |> Enum.sum()

        {safe_max.(Enum.map(mus, fn t -> Nx.abs(t) |> Nx.reduce_max() |> Nx.to_number() end)),
         safe_max.(Enum.map(nus, fn t -> Nx.reduce_max(t) |> Nx.to_number() end)),
         Float.round(nu_zeros / max(nu_total, 1), 4)}

      _ ->
        {nil, nil, nil}
    end

  %{
    param_max: safe_max.(param_maxes),
    param_norm:
      if(Enum.all?(param_sq, &is_number/1),
        do: Float.round(:math.sqrt(Enum.sum(param_sq)), 3),
        else: :nan
      ),
    mu_max: mu_max,
    nu_max: nu_max,
    nu_zero_frac: nu_zero_frac
  }
end

# --replay-scene PREFIX (2026-08-20, GOTCHA #99 mechanism hunt): offline
# replay of a captured collapse/spike scene. PREFIX is the dumped file
# prefix (e.g. checkpoints/collapse_scene/spike1). Loads the PRE-update
# trainer + the batch, reruns train_step under THIS process's nx stack,
# prints the loss (twice — determinism check) and the max param diff vs
# the recorded POST trainer. Run once per nx checkout and compare: a
# stack-dependent loss or param divergence isolates the bug mechanically.
# Uses the drill's own loss_fn/pool construction so the computation is
# byte-for-byte the training one. Halts before any training.
if prefix = opts[:replay_scene] do
  find1 = fn glob ->
    case Path.wildcard(glob) do
      [one] -> one
      other -> raise "expected exactly one #{glob}, got #{inspect(other)}"
    end
  end

  pre_path = find1.(prefix <> "_pre_trainer_step*.ckpt")
  batch_path = find1.(prefix <> "_batch_step*.bin")
  scene_json = find1.(prefix <> "_scene_step*.json")
  scene = scene_json |> File.read!() |> Jason.decode!()

  {:ok, tr_scene} = Imitation.load_checkpoint(trainer, pre_path)
  batch = batch_path |> File.read!() |> :erlang.binary_to_term()

  Output.puts("REPLAY scene #{prefix}: recorded loss #{scene["loss"]} at step #{scene["step"]}")
  Output.puts("REPLAY nx stack: #{:os.cmd(~c(git -C #{Path.expand("~/git/nx")} log --oneline -1)) |> to_string() |> String.trim()}")

  {tr_after, m1} = Imitation.train_step(tr_scene, batch, loss_fn)
  {_, m2} = Imitation.train_step(tr_scene, batch, loss_fn)
  Output.puts("REPLAY loss run1=#{inspect(Nx.to_number(m1.loss))} run2=#{inspect(Nx.to_number(m2.loss))}")

  case Path.wildcard(prefix <> "_post_trainer_step*.ckpt") do
    [post_path] ->
      {:ok, tr_post} = Imitation.load_checkpoint(trainer, post_path)
      replayed = flatten_tensors.(tr_after.policy_params.data)
      recorded = flatten_tensors.(tr_post.policy_params.data)

      diffs =
        Enum.zip(replayed, recorded)
        |> Enum.map(fn {a, b} ->
          Nx.subtract(Nx.as_type(a, :f32), Nx.as_type(b, :f32))
          |> Nx.abs()
          |> Nx.reduce_max()
          |> Nx.to_number()
        end)

      Output.puts(
        "REPLAY post-params vs recorded post: max|diff|=#{Enum.max(diffs)} " <>
          "(#{Enum.count(diffs, &(&1 > 1.0e-6))}/#{length(diffs)} tensors differ >1e-6)"
      )

    _ ->
      Output.puts("REPLAY: no post trainer recorded (skipping param diff)")
  end

  System.halt(0)
end

# Track the best epoch so a late divergence still exports a usable policy.
# On NaN, restore the best params and CONTINUE (up to 5 restores) instead of
# halting: every LR >= 1.5e-4 run NaN'd mid-run (5-for-5 at 2e-4, 2026-07-13)
# and halting forfeits the rest of the epoch budget. The shuffle seed varies
# by epoch so a restored retry sees a different batch order rather than
# deterministically re-diverging (grad clipping 0.5 is already on; these
# NaNs are forward-pass overflows, so a fresh trajectory is the only out).
{best, final_loss, epochs_used} =
  Enum.reduce_while(start_epoch..max_epochs, {trainer, nil, 0, [], nil, 0}, fn epoch,
                                                                     {tr, _, _, history, best,
                                                                      restores} ->
    # Scheduled sampling ramp: 0 -> P linearly over --ss-ramp epochs
    # (default 10). Standard curriculum — early epochs learn the mapping
    # teacher-forced, later epochs see self-conditioned prev-action.
    tr =
      case opts[:scheduled_sampling] do
        nil ->
          tr

        p_max ->
          ramp = max(opts[:ss_ramp] || 10, 1)
          p = min(p_max, p_max * epoch / ramp)
          %{tr | config: Map.put(tr.config, :ss_p_current, p)}
      end

    {tr, epoch_metrics} =
      batches_for.(epoch)
      |> then(fn batches ->
        if nan_forensics or collapse_forensics do
          batches
          |> Enum.reduce_while({tr, EpochLoss.new(), []}, fn batch, {tr_acc, aggregate, trail} ->
            {tr_next, metrics} = Imitation.train_step(tr_acc, batch, loss_fn)
            loss_num = Nx.to_number(metrics.loss)
            step = tr_next.step

            # Per-batch loss series (2026-08-20 cross-stack overlay test):
            # with the per-epoch-seeded shuffle, two stacks see the same
            # batch order — the series diverging timestamps the first
            # corrupted step. Appended, cheap (one line per step).
            if collapse_forensics do
              File.write!(out_path <> ".batchloss", "#{epoch} #{step} #{loss_num}\n", [:append])
            end

            dump_scene = fn tag ->
              dir = "checkpoints/collapse_scene"
              File.mkdir_p!(dir)

              Output.error(
                "#{String.upcase(tag)} SCENE: batch loss #{inspect(loss_num)} at step #{step}, " <>
                  "epoch #{epoch} — dumping to #{dir}/"
              )

              Imitation.save_checkpoint(tr_acc, "#{dir}/#{tag}_pre_trainer_step#{step}.ckpt")
              Imitation.save_checkpoint(tr_next, "#{dir}/#{tag}_post_trainer_step#{step}.ckpt")

              File.write!(
                "#{dir}/#{tag}_batch_step#{step}.bin",
                :erlang.term_to_binary(deep_to_host.(deep_to_host, batch))
              )

              File.write!(
                "#{dir}/#{tag}_scene_step#{step}.json",
                Jason.encode!(%{
                  tag: tag,
                  step: step,
                  epoch: epoch,
                  loss: loss_num,
                  stats: inspect(numeric_stats.(tr_next)),
                  trail: Enum.map(trail, fn {s, l, st} -> [s, l, inspect(st)] end)
                })
              )
            end

            if collapse_forensics and is_number(loss_num) and loss_num < 1.0e-5 do
              dump_scene.("collapse")
              Output.success("Collapse scene dumped. Halting for offline replay.")
              System.halt(3)
            end

            # Spike scenes (2026-08-20, second forensics round): the wild
            # stack spikes (47x, 153x one-epoch jumps) ~4x more often than
            # it collapses; a spiked batch is the same scrambled-update
            # event with the opposite sign and serves the both-stacks
            # replay identically. Dump up to 3, do NOT halt — a collapse
            # later in the run is still the prize.
            spike_dumps = Process.get(:spike_dumps, 0)

            if collapse_forensics and is_number(loss_num) and loss_num > 0.3 and
                 epoch > 1 and spike_dumps < 3 do
              Process.put(:spike_dumps, spike_dumps + 1)
              dump_scene.("spike#{spike_dumps + 1}")
            end

            trail =
              if rem(step, 100) == 0 do
                stats = numeric_stats.(tr_next)
                # The ~150 eager EXLA ops per sample leave device buffers
                # behind until BEAM GC frees the refs — without this the GPU
                # OOMs by step ~3000 (observed 2026-07-13).
                :erlang.garbage_collect()
                Enum.take([{step, loss_num, stats} | trail], 30)
              else
                trail
              end

            # Cliff checkpoints: full trainer state (params + optimizer)
            # every 25k steps once inside the failure zone, keep last 2 —
            # later experiments resume from the cliff instead of re-paying
            # the 40-90 min approach ("build the time-savers first").
            if rem(step, 25_000) == 0 and step >= 250_000 do
              File.mkdir_p!("checkpoints/cliffs")
              path = "checkpoints/cliffs/cliff_step#{step}.ckpt"
              Output.puts("saving cliff checkpoint: #{path}")
              Imitation.save_checkpoint(tr_next, path)

              "checkpoints/cliffs/cliff_step*.ckpt"
              |> Path.wildcard()
              |> Enum.sort_by(fn p ->
                Regex.run(~r/step(\d+)/, p) |> List.last() |> String.to_integer()
              end)
              |> Enum.drop(-2)
              |> Enum.each(&File.rm/1)
            end

            if rem(step, 1000) == 0 and trail != [] do
              {_, _, st} = hd(trail)
              Output.puts("forensics step #{step}: loss=#{inspect(loss_num)} #{inspect(st)}")
            end

            if is_number(loss_num) do
              aggregate = EpochLoss.add(aggregate, loss_num, batch, tr_acc.config[:policy_type] || :autoregressive)
              {:cont, {tr_next, aggregate, trail}}
            else
              Output.error(
                "FORENSICS: first non-finite loss (#{inspect(loss_num)}) " <>
                  "at optimizer step #{step}, epoch #{epoch}"
              )

              Output.puts("post-mortem (already-poisoned) stats: #{inspect(numeric_stats.(tr_next))}")
              Output.puts("trail (newest first, sampled every 100 steps):")

              Enum.each(trail, fn {s, l, st} ->
                Output.puts("  step #{s}: loss=#{inspect(l)} #{inspect(st)}")
              end)

              System.halt(2)
            end
          end)
          |> then(fn {tr_next, aggregate, _trail} -> {tr_next, aggregate} end)
        else
          Enum.reduce(batches, {tr, EpochLoss.new()}, fn batch, {tr_acc, aggregate} ->
            {tr_next, metrics} = Imitation.train_step(tr_acc, batch, loss_fn)
            {tr_next, EpochLoss.add(aggregate, metrics.loss, batch, tr_acc.config[:policy_type] || :autoregressive)}
          end)
        end
      end)

    loss = EpochLoss.mean(epoch_metrics)

    loss =
      case ExPhil.Training.EpochHealth.validate(loss, tr.policy_params) do
        :ok -> loss
        {:error, reason} -> {:invalid_epoch, reason, loss}
      end

    # Per-epoch heartbeat (2026-07-22): previously only rem(epoch,5)==0
    # logged, so the drill went SILENT for 4 of every 5 epochs. With
    # ~10-min mamba_2 epochs that's ~40 min of no log output during
    # healthy training — long enough that a log-mtime heartbeat monitor
    # false-alarms (observed while watching the r16 relaunch). One line
    # every epoch keeps mtime advancing, so "pid alive AND log advancing"
    # is a sound liveness signal again without needing to poll GPU util.
    rss = MemoryLedger.process_memory().rss_bytes

    Output.puts(
      "epoch #{epoch}/#{max_epochs}: loss=#{inspect(loss)} " <>
        "metric=denominator_weighted_v1 batches=#{epoch_metrics.batches} " <>
        "mass=#{epoch_metrics.mass} rss=#{MemoryLedger.format_bytes(rss)}"
    )

    # Probe-as-regularizer refit (r15): re-derive the shield-lock direction
    # from the network's CURRENT activations. Skipped on NaN epochs — the
    # restore path below rewinds params, and a direction fit on poisoned
    # activations would ride along.
    tr =
      if probe_reg > 0 and is_number(loss) and rem(epoch, probe_reg_every) == 0 do
        {tr2, rstats} = ProbeRegularizer.refit(tr, probe_dataset, probe_frame_labels, window_size: window)
        Output.puts("probe-reg refit @ epoch #{epoch}: #{inspect(rstats)}")
        tr2
      else
        tr
      end

    loss =
      if probe_reg > 0 and is_number(loss) do
        case ExPhil.Training.EpochHealth.validate(loss, tr.policy_params) do
          :ok -> loss
          {:error, reason} -> {:invalid_epoch, reason, loss}
        end
      else
        loss
      end

    # Mid-training publish: a play-able snapshot every 10 epochs, so the
    # run can be eye-tested while it trains (from a separate worktree —
    # NO-MIX). Write-then-rename is atomic on the same filesystem, so a
    # reader can never observe a torn file. Warm-restart caveat: mid-cycle
    # snapshots can look worse than the final export.
    #
    # Snapshot runs BEFORE probe-eval (r16 lesson, 2026-07-22): both fire
    # on the same epochs, and when probe-eval crashed at epoch 10 the run
    # died before its first save — 10 epochs of work gone. Risky
    # instrumentation goes last so a death there costs 0 epochs.
    # --snapshot-all (2026-08-20, behavioral gate-sweep recipe): keep a
    # policy snapshot for EVERY epoch. Rationale: chain skill lives on
    # transient peaks that continued training destroys, and loss anti-
    # correlates with behavior late in training (0820_collapse_forensics)
    # — checkpoint selection must happen by POST-RUN behavioral gating
    # over these snapshots, not by loss. ~3.8MB each.
    if opts[:snapshot_all] == true and is_number(loss) do
      snap = Path.rootname(out_path) <> "_ep#{epoch}.bin"

      case Imitation.export_policy(tr, snap) do
        :ok -> :ok
        err -> Output.warning("snapshot-all export failed at epoch #{epoch}: #{inspect(err)}")
      end
    end

    if rem(epoch, snapshot_every) == 0 and is_number(loss) do
      latest = Path.rootname(out_path) <> "_latest.bin"
      tmp = latest <> ".tmp"

      case Imitation.export_policy(tr, tmp) do
        :ok -> File.rename!(tmp, latest)
        _ -> File.rm(tmp)
      end

      # Trainer snapshot for --resume (full state incl. Adam moments;
      # atomic inside save_checkpoint). ~11MB sync write every 10 epochs
      # — negligible next to a ~110s epoch. Deleted on successful export.
      Imitation.save_checkpoint(tr, trainer_ckpt,
        meta: %{epoch: epoch, fingerprint: run_fingerprint}
      )
    end

    # Feature-formation curves (--probe-eval-every)
    if probe_eval_every > 0 and is_number(loss) and rem(epoch, probe_eval_every) == 0 do
      bas = ExPhil.Interp.TrainingProbes.eval(tr, probe_eval_trunk_fn, probe_dataset, probe_eval_labels, window_size: window)
      Output.puts("probe-eval @ epoch #{epoch}: #{ExPhil.Interp.TrainingProbes.format(bas)}")

      File.write!(
        probe_curves_path,
        Jason.encode!(%{epoch: epoch, loss: loss, probes: bas}) <> "\n",
        [:append]
      )
    end

    # Basin rollout (risky instrumentation last, after the snapshot)
    basin_results =
      if basin_probe != nil and (epoch == 1 or rem(epoch, basin_probe_every) == 0) and
           is_number(loss) do
        basin_probe.(epoch, loss, tr.policy_params)
      end

    best =
      case best do
        nil -> if is_number(loss), do: {tr, loss}, else: nil
        {_, best_loss} ->
          if is_number(loss) and loss < best_loss,
            do: {tr, loss},
            else: best
      end

    history =
      if is_number(loss),
        do: Enum.take([loss | history], 100),
        else: history

    plateaued? =
      length(history) == 100 and is_number(loss) and
        List.last(history) - Enum.min(history) < 1.0e-3

    cond do
      not is_number(loss) and best != nil and restores < 5 ->
        {best_tr, best_loss} = best

        Output.warning(
          "Invalid numerical epoch #{epoch}: #{inspect(loss)} — restored best params " <>
            "(loss=#{Float.round(best_loss * 1.0, 5)}), continuing " <>
            "(restore #{restores + 1}/5)"
        )

        {:cont, {best_tr, best_loss, epoch, history, best, restores + 1}}

      not is_number(loss) -> {:halt, {tr, loss, epoch, history, best, restores}}

      reject_at != nil and epoch >= reject_at and is_map(basin_results) and
          basin_reject_check.(basin_results) ->
        {:halt, {tr, {:rejected, loss, basin_results}, epoch, history, best, restores}}

      loss < memorized_loss -> {:halt, {tr, loss, epoch, history, best, restores}}
      plateaued? -> {:halt, {tr, loss, epoch, history, best, restores}}
      true -> {:cont, {tr, loss, epoch, history, best, restores}}
    end
  end)
  |> then(fn {_tr, loss, epoch, _, best, _} -> {best, loss, epoch} end)

# Early-reject intercepts BEFORE the divergence/best-export logic: a
# rejected seed must not fall through to "export best epoch instead".
case final_loss do
  {:rejected, loss, probe_row} ->
    File.write!(
      out_path <> ".rejected.json",
      Jason.encode!(Map.merge(%{rejected_at_epoch: epochs_used, loss: loss, reject_on: reject_on}, probe_row))
    )

    Output.warning(
      "EARLY-REJECT (#{reject_on}) at epoch #{epochs_used}: #{inspect(probe_row)} — no policy exported"
    )

    System.halt(6)

  _ ->
    :ok
end

case {is_number(final_loss), best} do
  {_, nil} ->
    Output.error("Training diverged with no usable epoch — no policy exported")
    System.halt(1)

  {false, {_best_tr, best_loss}} ->
    Output.warning(
      "Training diverged (#{inspect(final_loss)}) at epoch #{epochs_used} — " <>
        "exporting best epoch instead (loss=#{Float.round(best_loss * 1.0, 5)})"
    )

  {true, {_best_tr, best_loss}} ->
    Output.puts("Training finished: best aggregate loss=#{inspect(best_loss)} after #{epochs_used} epochs")
end

{best_trainer, _best_loss} = best

case Imitation.export_policy(best_trainer, out_path) do
  :ok ->
    Output.success("Policy exported: #{out_path}")

    # Persist the style vocabulary next to the checkpoint (r17): inference
    # (--style-tag) needs the same tag->id map the policy trained on.
    if player_registry && map_size(player_registry.tag_to_id) > 0 do
      players_path = "#{out_path}.players.json"
      ExPhil.Training.PlayerRegistry.to_json(player_registry, players_path)
      Output.puts("Player registry: #{players_path}")
    end

    final_mem = record_ledger.("train")

    Output.puts(
      "memory: run peak rss #{MemoryLedger.format_bytes(final_mem.hwm_bytes)} " <>
        "over #{pool_frames} frames — ledger updated (#{MemoryLedger.default_path()})"
    )

    # The run finished — the resume snapshot is a cliff we no longer need
    File.rm(trainer_ckpt)

  {:error, reason} ->
    Output.error("Export failed: #{inspect(reason)}")
    System.halt(1)
end
