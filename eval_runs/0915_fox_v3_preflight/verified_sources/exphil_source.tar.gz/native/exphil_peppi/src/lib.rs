//! ExPhil Peppi NIF
//!
//! Rust NIF for parsing Slippi replay files using the Peppi library.
//! Provides fast, native parsing of .slp files for training data extraction.

use peppi::game::Game;
use peppi::frame::transpose::{Frame, Data, Pre};
use peppi::io::slippi;
use rustler::{Atom, NifResult, NifStruct};
use std::collections::HashMap;
use std::fs::File;
use std::io::BufReader;

mod atoms {
    rustler::atoms! {
        ok,
        error,
        nil,
    }
}

// ============================================================================
// NIF Structs - These map directly to Elixir structs
// ============================================================================

/// Parsed controller state
#[derive(Debug, NifStruct)]
#[module = "ExPhil.Data.Peppi.Controller"]
pub struct Controller {
    // Preserve the recorded f32 bytes: normalization can erase very small
    // values and signed zero. Playback must not reconstruct these from axes.
    pub processed: ProcessedInput,
    pub main_stick_x: f64,
    pub main_stick_y: f64,
    pub c_stick_x: f64,
    pub c_stick_y: f64,
    pub l_trigger: f64,
    pub r_trigger: f64,
    pub button_a: bool,
    pub button_b: bool,
    pub button_x: bool,
    pub button_y: bool,
    pub button_z: bool,
    pub button_l: bool,
    pub button_r: bool,
    pub button_start: bool,
    pub button_d_up: bool,
    pub button_d_down: bool,
    pub button_d_left: bool,
    pub button_d_right: bool,
}

/// Original pre-frame input fields, separate from the training representation.
#[derive(Debug, NifStruct)]
#[module = "ExPhil.Data.Peppi.ProcessedInput"]
pub struct ProcessedInput {
    pub rng_seed: u32,
    pub main_x: f64,
    pub main_y: f64,
    pub c_x: f64,
    pub c_y: f64,
    pub trigger: f64,
    pub buttons: u32,
    pub physical_buttons: u16,
    pub raw_main_x: Option<i8>,
    pub raw_main_y: Option<i8>,
    pub raw_c_x: Option<i8>,
    pub raw_c_y: Option<i8>,
}

/// Parsed player state for a single frame
#[derive(Debug, NifStruct)]
#[module = "ExPhil.Data.Peppi.PlayerFrame"]
pub struct PlayerFrame {
    pub character: i32,
    pub x: f64,
    pub y: f64,
    pub percent: f64,
    pub stock: i32,
    pub facing: i32,
    pub action: u16,
    pub action_frame: f64,
    pub invulnerable: bool,
    pub jumps_left: i32,
    pub on_ground: bool,
    pub shield_strength: f64,
    pub hitstun_frames_left: f64,
    pub hitlag_left: f64,
    pub in_hitstun: Option<bool>,
    pub speed_air_x_self: f64,
    pub speed_ground_x_self: f64,
    pub speed_y_self: f64,
    pub speed_x_attack: f64,
    pub speed_y_attack: f64,
    pub controller: Controller,
}

/// A single parsed game frame
#[derive(Debug, NifStruct)]
#[module = "ExPhil.Data.Peppi.GameFrame"]
pub struct GameFrame {
    pub frame_number: i32,
    pub players: HashMap<i32, PlayerFrame>,
    // Stage events (Slippi spec >= 3.18; None on older replays):
    // Fountain of Dreams side-platform heights and the Pokemon Stadium
    // transformation state (event: 0 finished / 2 init / 3 on_monitor /
    // 4 receding / 5 rising / 6 finalize; type: 3 fire / 4 grass /
    // 5 normal / 6 rock / 9 water)
    pub fod_platform_left: Option<f64>,
    pub fod_platform_right: Option<f64>,
    pub stadium_event: Option<i32>,
    pub stadium_type: Option<i32>,
    /// Dreamland Whispy blow direction (raw u8 from the 0x40 event)
    pub whispy_direction: Option<i32>,
}

/// Player metadata from game start
#[derive(Debug, NifStruct)]
#[module = "ExPhil.Data.Peppi.PlayerMeta"]
pub struct PlayerMeta {
    pub port: i32,
    pub character: i32,
    pub character_name: String,
    pub tag: Option<String>,
    // Netplay identity (Slippi online): display name (e.g. "Plup") and
    // connect code (e.g. "PLUP#123"). Populated for online replays; None
    // for local/console games. Style-conditional training keys on the
    // netplay name because in-game name_tag is blank in netplay.
    pub netplay_name: Option<String>,
    pub netplay_code: Option<String>,
}

/// Replay metadata
#[derive(Debug, NifStruct)]
#[module = "ExPhil.Data.Peppi.ReplayMeta"]
pub struct ReplayMeta {
    pub frozen_stadium: Option<bool>,
    pub path: String,
    pub stage: i32,
    pub duration_frames: i32,
    pub players: Vec<PlayerMeta>,
}

/// Complete parsed replay
#[derive(Debug, NifStruct)]
#[module = "ExPhil.Data.Peppi.ParsedReplay"]
pub struct ParsedReplay {
    pub frames: Vec<GameFrame>,
    pub metadata: ReplayMeta,
}

// ============================================================================
// Character & Stage Mappings
// ============================================================================

/// Convert an INTERNAL (in-game) character ID to our standard frame-level ID.
///
/// Post-frame events carry the game's internal enum (Mario=0x00, Fox=0x01,
/// ..., Ganondorf=0x19, Roy=0x1A, ... Sandbag=0x20), NOT the external CSS
/// enum game-start uses. Historically post.character was fed through
/// `character_id/1` (the external table) — numerically the identity for
/// 0x00..=0x19, so every character trained to date got a consistent id and
/// no checkpoint noticed, but ids >= 0x1A fell to -1 (Roy -> -1, found by
/// libmelee_ex's differential work 2026-08-05). The frame-level convention
/// is therefore pinned as IDENTITY (standard id == internal id, 33 slots
/// matching the 33-dim character one-hot); unknowns clamp to 32, never -1
/// (a negative embedding index).
fn internal_character_id(char_id: u8) -> i32 {
    match char_id {
        0x00..=0x20 => char_id as i32,
        _ => 32,
    }
}

/// Convert peppi's external character ID to our standard ID
fn character_id(char_id: u8) -> i32 {
    // Peppi uses "external" character IDs (CSS order)
    // Map to our consistent ordering for embeddings
    match char_id {
        0x00 => 0,   // Captain Falcon
        0x01 => 1,   // Donkey Kong
        0x02 => 2,   // Fox
        0x03 => 3,   // Game & Watch
        0x04 => 4,   // Kirby
        0x05 => 5,   // Bowser
        0x06 => 6,   // Link
        0x07 => 7,   // Luigi
        0x08 => 8,   // Mario
        0x09 => 9,   // Marth
        0x0A => 10,  // Mewtwo
        0x0B => 11,  // Ness
        0x0C => 12,  // Peach
        0x0D => 13,  // Pikachu
        0x0E => 14,  // Ice Climbers (Popo)
        0x0F => 15,  // Jigglypuff
        0x10 => 16,  // Samus
        0x11 => 17,  // Yoshi
        0x12 => 18,  // Zelda
        0x13 => 19,  // Sheik
        0x14 => 20,  // Falco
        0x15 => 21,  // Young Link
        0x16 => 22,  // Dr. Mario
        0x17 => 23,  // Roy
        0x18 => 24,  // Pichu
        0x19 => 25,  // Ganondorf
        0x20 => 14,  // Ice Climbers (Nana) - same as Popo
        _ => -1,
    }
}

fn character_name(char_id: u8) -> String {
    // Peppi uses "external" character IDs (CSS order), not internal game IDs
    // See: https://github.com/hohav/peppi/blob/main/src/ssbm.rs
    match char_id {
        0x00 => "Captain Falcon",
        0x01 => "Donkey Kong",
        0x02 => "Fox",
        0x03 => "Game & Watch",
        0x04 => "Kirby",
        0x05 => "Bowser",
        0x06 => "Link",
        0x07 => "Luigi",
        0x08 => "Mario",
        0x09 => "Marth",
        0x0A => "Mewtwo",
        0x0B => "Ness",
        0x0C => "Peach",
        0x0D => "Pikachu",
        0x0E => "Ice Climbers",  // Popo
        0x0F => "Jigglypuff",
        0x10 => "Samus",
        0x11 => "Yoshi",
        0x12 => "Zelda",
        0x13 => "Sheik",
        0x14 => "Falco",
        0x15 => "Young Link",
        0x16 => "Dr. Mario",
        0x17 => "Roy",
        0x18 => "Pichu",
        0x19 => "Ganondorf",
        0x1A => "Master Hand",
        0x1B => "Crazy Hand",
        0x1C => "Wire Frame Male",
        0x1D => "Wire Frame Female",
        0x1E => "Giga Bowser",
        0x1F => "Sandbag",
        0x20 => "Ice Climbers",  // Nana (solo)
        _ => "Unknown",
    }.to_string()
}

/// Convert stage ID to our standard ID
// Netplay display name / connect code from a player, dropping empty
// strings (local/console replays carry an all-zero MeleeString -> "").
fn netplay_name(player: &peppi::game::Player) -> Option<String> {
    player.netplay.as_ref().and_then(|n| {
        let s = n.name.0.clone();
        if s.is_empty() { None } else { Some(s) }
    })
}

fn netplay_code(player: &peppi::game::Player) -> Option<String> {
    player.netplay.as_ref().and_then(|n| {
        let s = n.code.0.clone();
        if s.is_empty() { None } else { Some(s) }
    })
}

fn stage_id(stage: u16) -> i32 {
    // Standard Melee stage IDs
    match stage {
        2 => 2,   // Fountain of Dreams
        3 => 3,   // Pokemon Stadium
        8 => 8,   // Yoshi's Story
        28 => 28, // Dream Land N64
        31 => 31, // Battlefield
        32 => 32, // Final Destination
        _ => stage as i32,
    }
}

// ============================================================================
// Parsing Functions
// ============================================================================

fn parse_controller(pre: &Pre) -> Controller {
    let joystick = &pre.joystick;
    let cstick = &pre.cstick;
    let triggers = &pre.triggers_physical;
    let buttons = pre.buttons_physical;

    // Normalize from [-1, 1] to [0, 1]
    let main_x = (joystick.x as f64 + 1.0) / 2.0;
    let main_y = (joystick.y as f64 + 1.0) / 2.0;
    let c_x = (cstick.x as f64 + 1.0) / 2.0;
    let c_y = (cstick.y as f64 + 1.0) / 2.0;

    // Button masks for physical buttons (16-bit)
    const A: u16 = 0x0100;
    const B: u16 = 0x0200;
    const X: u16 = 0x0400;
    const Y: u16 = 0x0800;
    const Z: u16 = 0x0010;
    const L: u16 = 0x0040;
    const R: u16 = 0x0020;
    const START: u16 = 0x1000;
    const D_UP: u16 = 0x0008;
    const D_DOWN: u16 = 0x0004;
    const D_LEFT: u16 = 0x0001;
    const D_RIGHT: u16 = 0x0002;

    Controller {
        processed: ProcessedInput {
            rng_seed: pre.random_seed,
            main_x: joystick.x as f64,
            main_y: joystick.y as f64,
            c_x: cstick.x as f64,
            c_y: cstick.y as f64,
            trigger: pre.triggers as f64,
            buttons: pre.buttons,
            physical_buttons: buttons,
            raw_main_x: pre.raw_analog_x,
            raw_main_y: pre.raw_analog_y,
            raw_c_x: pre.raw_analog_cstick_x,
            raw_c_y: pre.raw_analog_cstick_y,
        },
        main_stick_x: main_x,
        main_stick_y: main_y,
        c_stick_x: c_x,
        c_stick_y: c_y,
        l_trigger: triggers.l as f64,
        r_trigger: triggers.r as f64,
        button_a: (buttons & A) != 0,
        button_b: (buttons & B) != 0,
        button_x: (buttons & X) != 0,
        button_y: (buttons & Y) != 0,
        button_z: (buttons & Z) != 0,
        button_l: (buttons & L) != 0,
        button_r: (buttons & R) != 0,
        button_start: (buttons & START) != 0,
        button_d_up: (buttons & D_UP) != 0,
        button_d_down: (buttons & D_DOWN) != 0,
        button_d_left: (buttons & D_LEFT) != 0,
        button_d_right: (buttons & D_RIGHT) != 0,
    }
}

fn parse_player_frame(data: &Data) -> PlayerFrame {
    let pre = &data.pre;
    let post = &data.post;

    // Direction is stored as f32: negative = left, positive = right
    let facing = if post.direction < 0.0 { -1 } else { 1 };

    // Extract velocities if available
    let (speed_air_x, speed_ground_x, speed_y, speed_x_attack, speed_y_attack) =
        if let Some(ref velocities) = post.velocities {
            (
                velocities.self_x_air as f64,
                velocities.self_x_ground as f64,
                velocities.self_y as f64,
                velocities.knockback_x as f64,
                velocities.knockback_y as f64,
            )
        } else {
            (0.0, 0.0, 0.0, 0.0, 0.0)
        };

    // Slippi post-frame 0x34: vulnerable / invulnerable / intangible.
    // Flags byte 1 bit 0x10 describes a reflector, not invulnerability.
    let invulnerable = post.hurtbox_state
        .map(|state| state != 0)
        .or_else(|| post.state_flags.map(|flags| flags.1 & 0x04 != 0))
        .unwrap_or(false);

    // Check if grounded
    let on_ground = post.airborne
        .map(|a| a == 0)
        .unwrap_or(true);

    PlayerFrame {
        character: internal_character_id(post.character),
        x: post.position.x as f64,
        y: post.position.y as f64,
        percent: post.percent as f64,
        stock: post.stocks as i32,
        facing,
        action: post.state,
        action_frame: post.state_age.unwrap_or(0.0) as f64,
        invulnerable,
        jumps_left: post.jumps.unwrap_or(2) as i32,
        on_ground,
        shield_strength: post.shield as f64,
        // Match libmelee's live 0x2B channel. This counter has other uses
        // outside hitstun; statistical consumers must consult in_hitstun.
        hitstun_frames_left: post.misc_as.unwrap_or(0.0) as f64,
        hitlag_left: post.hitlag.unwrap_or(0.0) as f64,
        in_hitstun: post.state_flags.map(|flags| flags.3 & 0x02 != 0),
        speed_air_x_self: speed_air_x,
        speed_ground_x_self: speed_ground_x,
        speed_y_self: speed_y,
        speed_x_attack: speed_x_attack,
        speed_y_attack: speed_y_attack,
        controller: parse_controller(pre),
    }
}

fn parse_frame(frame: &Frame) -> GameFrame {
    let mut players = HashMap::new();

    for port_data in &frame.ports {
        let port_num = port_data.port as i32 + 1;  // Convert 0-indexed to 1-indexed
        let player_frame = parse_player_frame(&port_data.leader);
        players.insert(port_num, player_frame);
    }

    // FoD platform-height events. Raw platform id 0 = RIGHT, 1 = LEFT —
    // pinned empirically (2026-08-11): players RIDING each platform in
    // the 0809 netplay FoD game match this assignment (mean|err| 3.2 vs
    // 13.9 for the reverse). Heights persist between events; consumers
    // hold the last seen value. The height value references a point
    // 5.125 units ABOVE the walkable surface (constant across 561
    // at-rest standing samples) — surface consumers subtract it.
    let mut fod_left = None;
    let mut fod_right = None;
    if let Some(plats) = &frame.fod_platforms {
        for p in plats {
            match p.platform {
                0 => fod_right = Some(p.height as f64),
                1 => fod_left = Some(p.height as f64),
                _ => {}
            }
        }
    }

    // Stadium transformation: take the last event of the frame
    let (stadium_event, stadium_type) = match &frame.stadium_transformations {
        Some(ts) if !ts.is_empty() => {
            let t = ts[ts.len() - 1];
            (Some(t.event as i32), Some(t.r#type as i32))
        }
        _ => (None, None),
    };

    let whispy_direction = match &frame.dreamland_whispys {
        Some(ws) if !ws.is_empty() => Some(ws[ws.len() - 1].direction as i32),
        _ => None,
    };

    GameFrame {
        frame_number: frame.id,
        players,
        fod_platform_left: fod_left,
        fod_platform_right: fod_right,
        stadium_event,
        stadium_type,
        whispy_direction,
    }
}

fn parse_game<G: Game>(game: &G, path: &str) -> ParsedReplay {
    // Extract metadata from game start
    let start = game.start();
    let stage = stage_id(start.stage);

    let mut player_metas = Vec::new();
    for player in &start.players {
        player_metas.push(PlayerMeta {
            port: player.port as i32 + 1,
            character: character_id(player.character),
            character_name: character_name(player.character),
            tag: player.name_tag.as_ref().map(|s| s.0.clone()),
            netplay_name: netplay_name(player),
            netplay_code: netplay_code(player),
        });
    }

    // Parse all frames
    let num_frames = game.len();
    let mut frames = Vec::with_capacity(num_frames);

    for idx in 0..num_frames {
        let frame = game.frame(idx);
        frames.push(parse_frame(&frame));
    }

    let metadata = ReplayMeta {
        frozen_stadium: start.is_frozen_ps,
        path: path.to_string(),
        stage,
        duration_frames: frames.len() as i32,
        players: player_metas,
    };

    ParsedReplay { frames, metadata }
}

// ============================================================================
// NIF Functions
// ============================================================================

/// Parse a single .slp replay file
#[rustler::nif]
fn parse_replay(path: String) -> NifResult<(Atom, ParsedReplay)> {
    let file = File::open(&path)
        .map_err(|e| rustler::Error::Term(Box::new(format!("Failed to open file: {}", e))))?;

    let mut reader = BufReader::new(file);
    let game = slippi::read(&mut reader, None)
        .map_err(|e| rustler::Error::Term(Box::new(format!("Failed to parse replay: {}", e))))?;

    let parsed = parse_game(&game, &path);
    Ok((atoms::ok(), parsed))
}

/// Parse a replay and return only frames for a specific player port
#[rustler::nif]
fn parse_replay_for_port(path: String, player_port: i32) -> NifResult<(Atom, ParsedReplay)> {
    let file = File::open(&path)
        .map_err(|e| rustler::Error::Term(Box::new(format!("Failed to open file: {}", e))))?;

    let mut reader = BufReader::new(file);
    let game = slippi::read(&mut reader, None)
        .map_err(|e| rustler::Error::Term(Box::new(format!("Failed to parse replay: {}", e))))?;

    let mut parsed = parse_game(&game, &path);

    // Filter to only include frames where the specified port has data
    parsed.frames.retain(|f| f.players.contains_key(&player_port));

    Ok((atoms::ok(), parsed))
}

/// Get replay metadata without parsing all frames (faster for filtering)
#[rustler::nif]
fn get_replay_metadata(path: String) -> NifResult<(Atom, ReplayMeta)> {
    let file = File::open(&path)
        .map_err(|e| rustler::Error::Term(Box::new(format!("Failed to open file: {}", e))))?;

    let mut reader = BufReader::new(file);
    let game = slippi::read(&mut reader, None)
        .map_err(|e| rustler::Error::Term(Box::new(format!("Failed to parse replay: {}", e))))?;

    let start = game.start();
    let stage = stage_id(start.stage);

    let mut player_metas = Vec::new();
    for player in &start.players {
        player_metas.push(PlayerMeta {
            port: player.port as i32 + 1,
            character: character_id(player.character),
            character_name: character_name(player.character),
            tag: player.name_tag.as_ref().map(|s| s.0.clone()),
            netplay_name: netplay_name(player),
            netplay_code: netplay_code(player),
        });
    }

    let metadata = ReplayMeta {
        frozen_stadium: start.is_frozen_ps,
        path: path.to_string(),
        stage,
        duration_frames: game.len() as i32,
        players: player_metas,
    };

    Ok((atoms::ok(), metadata))
}

// Register NIFs
rustler::init!("Elixir.ExPhil.Data.Peppi");

#[cfg(test)]
mod tests {
    #[test]
    fn combat_counters_and_reflector_flags_remain_distinct() {
        use peppi::frame::transpose::{Data, Pre, Post, StateFlags};
        let mut data = Data { pre: Pre::default(), post: Post::default() };
        data.post.misc_as = Some(17.0);
        data.post.hitlag = Some(4.0);
        data.post.state_flags = Some(StateFlags(0x10, 0x20, 0, 0, 0));
        data.post.hurtbox_state = Some(0);
        let p = super::parse_player_frame(&data);
        assert_eq!(p.hitstun_frames_left, 17.0);
        assert_eq!(p.hitlag_left, 4.0);
        assert_eq!(p.in_hitstun, Some(false));
        assert!(!p.invulnerable);
        data.post.state_flags = Some(StateFlags(0, 0, 0, 0x02, 0));
        data.post.hurtbox_state = Some(2);
        let p = super::parse_player_frame(&data);
        assert_eq!(p.in_hitstun, Some(true));
        assert!(p.invulnerable);
    }

    #[test]
    fn processed_inputs_preserve_original_bits_and_distinct_physical_fields() {
        let mut pre = peppi::frame::transpose::Pre::default();
        pre.joystick.x = -0.0;
        pre.joystick.y = f32::from_bits(1);
        pre.cstick.x = -0.9921875;
        pre.triggers = 0.375;
        pre.random_seed = 0xDEADBEEF;
        pre.buttons = 0x80000100;
        pre.buttons_physical = 0x0020;
        pre.triggers_physical.l = 0.125;
        pre.triggers_physical.r = 0.25;
        pre.raw_analog_x = Some(-128);
        pre.raw_analog_y = Some(127);
        let c = super::parse_controller(&pre);
        assert_eq!((c.processed.main_x as f32).to_bits(), pre.joystick.x.to_bits());
        assert_eq!((c.processed.main_y as f32).to_bits(), 1);
        assert_eq!(c.processed.trigger, 0.375);
        assert_eq!(c.processed.rng_seed, 0xDEADBEEF);
        assert_eq!(c.processed.buttons, 0x80000100);
        assert_eq!(c.processed.physical_buttons, 0x0020);
        assert_eq!(c.l_trigger, 0.125);
        assert_eq!(c.r_trigger, 0.25);
        assert_eq!(c.processed.raw_main_x, Some(-128));
        assert_eq!(c.processed.raw_main_y, Some(127));
        assert_eq!(c.processed.raw_c_x, None);
        assert!(!c.button_a);
        assert!(c.button_r);
    }

    // The frame-level convention is IDENTITY over internal ids (see
    // internal_character_id docs): checkpoints trained pre-fix depend on
    // 0x00..=0x19 staying numerically unchanged; Roy (0x1A) must be 26,
    // never -1; unknowns clamp into the 33-slot one-hot, never negative.
    #[test]
    fn internal_character_ids_identity_no_negatives() {
        assert_eq!(super::internal_character_id(0x01), 1); // Fox (unchanged)
        assert_eq!(super::internal_character_id(0x10), 16); // Mewtwo (unchanged)
        assert_eq!(super::internal_character_id(0x1A), 26); // Roy (was -1)
        assert_eq!(super::internal_character_id(0x20), 32); // Sandbag
        for id in 0..=255u8 {
            assert!(super::internal_character_id(id) >= 0);
        }
    }
}
