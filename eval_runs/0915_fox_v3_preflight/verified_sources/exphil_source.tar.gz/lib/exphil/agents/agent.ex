defmodule ExPhil.Agents.Agent do
  @moduledoc """
  GenServer that holds a trained policy and performs inference.

  An Agent encapsulates a neural network policy and provides a simple
  interface for getting actions from game states. Agents can be hot-swapped
  with new policies during runtime.

  ## Usage

      # Start an agent with a trained policy
      {:ok, agent} = ExPhil.Agents.Agent.start_link(
        name: :mewtwo_agent,
        policy_path: "checkpoints/mewtwo_policy.axon"
      )

      # Get action for a game state
      {:ok, action} = ExPhil.Agents.Agent.get_action(agent, game_state)

      # Get controller state directly
      {:ok, controller} = ExPhil.Agents.Agent.get_controller(agent, game_state)

      # Hot-swap policy
      :ok = ExPhil.Agents.Agent.load_policy(agent, "checkpoints/new_policy.axon")

  ## Frame Delay Handling

  For online play with frame delay, the agent can maintain a frame buffer:

      {:ok, agent} = ExPhil.Agents.Agent.start_link(
        name: :online_agent,
        policy_path: "checkpoints/policy.axon",
        frame_delay: 4
      )

  """

  use GenServer

  alias ExPhil.{Embeddings, Networks, Training}
  alias ExPhil.Bridge.{GameState, ControllerState}
  alias ExPhil.Training.Utils
  alias ExPhil.Error.AgentError

  require Logger

  @registry ExPhil.Registry

  defstruct [
    :name,
    :policy_params,
    :predict_fn,
    :embed_config,
    :bptt,
    # :parsed (default, no-op) | :live — see GOTCHAS #81
    :af_convention,
    :frame_delay,
    :frame_buffer,
    :deterministic,
    :temperature,
    :deterministic_buttons,
    # Mode-of-N decode (nil/1 = plain sampling): N joint draws per frame from
    # one forward, play the most frequent — see Networks.Policy.Sampling
    :mode_of_n,
    # Critic-selector decode (EVAL_DIRECTIONS task 2): loaded d2_critic_v1
    # artifact (%{mean, std, w, v, phi_size}) + K samples per decision.
    # nil = plain sampling. AR-head checkpoints only.
    :critic,
    :critic_k,
    # Button hysteresis for argmax button modes (nil = plain 0.5 threshold)
    :press_threshold,
    :release_threshold,
    :jump_debounce,
    :jump_cooldown,
    :use_prev_action,
    :ablate_prev_action,
    # Queue-as-input (2026-07-31): ring buffer of the agent's own K most
    # recent emitted controllers (newest first) + the declared delay this
    # session plays at. Populated only for policies whose embed config has
    # queue_depth > 1 / with_delay_id.
    :controller_queue,
    :delay_id,
    :allow_untrained_delay_id,
    # INVARIANTS item 12: which harness this agent plays in and that
    # harness's knob (ExPhil.Eval.HarnessRung); the delay-id is DERIVED
    # from them (or an explicit id is checked against them).
    :harness,
    :harness_knob,
    :reaction_delay,
    :delay_id_reaction_offset,
    :train_delays,
    # The loaded checkpoint's label pairing (:causal | :producing), kept so
    # a reconfigure of frame_delay re-derives delay_id the same way load did.
    :label_convention,
    :leace_eraser,
    # Steering-vector hook (Tier-0 shield-lock A/B): --steer-vector PATH +
    # --steer-alpha F project alpha of the trunk features' component along
    # a unit direction OUT before the heads. steer_v is the loaded (and
    # default-backend-copied) unit tensor; nil = hook inactive. Unlike
    # leace_eraser this applies on BOTH the windowed path (Axon.nx layer)
    # and the stateful step path (eager op on the step features).
    :steer_vector,
    :steer_alpha,
    :steer_v,
    # Style-conditional inference (flywheel P3a): index into the name/tag
    # one-hot the embedding ALWAYS carries (num_player_names slot). Training
    # with --player-registry maps tags -> ids; at inference this selects
    # whose style to imitate. 0 (the unknown-player id) = the pre-P3a
    # behavior, so existing checkpoints/callers are unaffected.
    :style_id,
    # The typed decode configuration (INVARIANTS.md item 7 phase B): built
    # by ExPhil.Agents.Decode.from_state/1 at init and after reconfigure;
    # every decision path derives its sampler options from it via
    # Decode.opts/3 — never from the loose fields above.
    :decode,
    # Path of the --player-registry JSON, kept so reconfigure(style_tag:)
    # can re-resolve tags exactly like init does (INVARIANTS.md item 7).
    :player_registry,
    # Uncertainty logging (flywheel A4): per-frame head confidences (already
    # computed by sampling) buffered and appended as JSONL to this path.
    # Low confidence = states the training data doesn't cover — a gap
    # signal that fires BEFORE failures do. nil = off (no overhead beyond
    # the confidence compute that happens anyway).
    :uncertainty_log,
    :uncertainty_buf,
    :last_controller,
    # Temporal inference config
    :temporal,
    :backbone,
    :window_size,
    :head,
    # JIT warmup tracking
    :warmed_up,
    # Action repeat (skip inference N-1 frames)
    :action_repeat,
    :frames_since_inference,
    :last_action,
    # Mamba incremental inference cache
    :mamba_cache,
    :use_incremental,
    # Edifice.Stateful step-path inference (O(1) per frame, GRU/LSTM only)
    # stateful_step: requested via opts; trunk_state != nil means ACTIVE
    :stateful_step,
    # Last game frame seen by the debounce — cooldown must tick in GAME
    # FRAMES, not compute calls (stateful-step runs ~2.2 calls/frame,
    # which shrank the "10-frame" window to ~4.5 real frames; the r14
    # instant-DJ escape, 2026-07-18)
    :last_debounce_frame,
    # Ground/air transition tracking: the window also arms at LIFTOFF
    # (tap-jump first jumps have no button release to arm on)
    :was_airborne,
    :trunk_state,
    :trunk_step_params,
    :heads_predict_fn,
    # true until the first post-reset frame has warmed the trunk (see
    # compute_stateful_step_action: replicates the windowed path's
    # pad-with-first-frame warmup so cold-start behavior matches)
    :trunk_cold,
    # Hybrid re-sync (task #11, 2026-08-02): every :stateful_resync frames
    # rebuild trunk_state from scratch through the last window_size
    # embedded frames (:step_frame_buffer, newest first) — the carried
    # state drifts from the trained sliding-window regime (~0.04 logit
    # gap at 40 frames, compounding); re-sync bounds drift to K frames
    # while keeping the O(1) step for the other K-1. nil = off.
    :stateful_resync,
    :step_frame_buffer,
    :steps_since_resync
  ]

  @type t :: %__MODULE__{}

  # ============================================================================
  # Client API
  # ============================================================================

  @typedoc "Start link options for Agent"
  @type start_option ::
          {:name, atom()}
          | {:policy_path, Path.t()}
          | {:policy, map()}
          | {:frame_delay, non_neg_integer()}
          | {:deterministic, boolean()}
          | {:temperature, float() | map()}
          | {:embed_config, map()}
          | {:action_repeat, pos_integer()}
          | {:use_incremental, boolean()}
          | {:stateful_step, boolean()}

  @doc """
  Start an Agent GenServer.

  ## Options
    - `:name` - Atom name for registry lookup
    - `:policy_path` - Path to exported policy file
    - `:policy` - Pre-loaded policy map (alternative to path)
    - `:frame_delay` - Frame delay for online play (default: 0)
    - `:deterministic` - Use deterministic action selection (default: false)
    - `:temperature` - Sampling temperature (default: 1.0). A number applies
      to every categorical head (buttons stay raw); a map applies per head —
      see `ExPhil.Networks.Policy.Sampling.sample/4`.
    - `:embed_config` - Embedding configuration (auto-detected from policy)
    - `:stateful_step` - O(1) recurrent inference via the Edifice.Stateful
      step API (temporal GRU/LSTM policies only; default: false). Enables
      `snapshot_state/1` / `restore_state/2` for netplay rollback.
  """
  @spec start_link([start_option()]) :: GenServer.on_start()
  def start_link(opts) do
    name = Keyword.get(opts, :name)

    gen_opts =
      if name do
        [name: {:via, Registry, {@registry, {:agent, name}}}]
      else
        []
      end

    GenServer.start_link(__MODULE__, opts, gen_opts)
  end

  @doc """
  Get the action for a game state.

  Returns a map with button presses and stick positions.
  """
  @spec get_action(GenServer.server(), GameState.t(), keyword()) ::
          {:ok, map()} | {:error, term()}
  def get_action(agent, game_state, opts \\ []) do
    GenServer.call(agent, {:get_action, game_state, opts})
  end

  @doc """
  Get action with confidence scores.

  Returns `{:ok, action, confidence}` where confidence is a map with:
  - `:overall` - Overall confidence (0-1)
  - `:buttons` - Button prediction confidence
  - `:main` - Main stick confidence
  - `:c` - C-stick confidence
  - `:shoulder` - Shoulder confidence
  """
  @spec get_action_with_confidence(GenServer.server(), GameState.t(), keyword()) ::
          {:ok, map(), map()} | {:error, term()}
  def get_action_with_confidence(agent, game_state, opts \\ []) do
    GenServer.call(agent, {:get_action_with_confidence, game_state, opts})
  end

  @doc """
  INSTRUMENT: draw `n` independent joint action samples at this game state
  (autoregressive-head checkpoints only, windowed temporal path).

  Skips the one-decision-per-frame debounce and does NOT mutate the agent's
  temporal buffer or caches — repeated calls and same-frame calls are safe.
  Used by interp_passk (Leg S): pass@k on an AR checkpoint needs n coherent
  sequential samples, not n draws from one forward's path-conditional logits.

  Opts: `:n` (default 16), `:key` (Nx.Random key), `:player_port`,
  `:temperature` (defaults to the agent's), `:timeout` (default 30_000).

  Returns `{:ok, [action_map]}` — bucket indices; run each through
  `ExPhil.Networks.Policy.to_controller_state/2` before comparing to a
  replay — or `{:error, reason}`.
  """
  @spec get_action_samples(GenServer.server(), GameState.t(), keyword()) ::
          {:ok, [map()]} | {:error, term()}
  def get_action_samples(agent, game_state, opts \\ []) do
    {timeout, opts} = Keyword.pop(opts, :timeout, 30_000)
    GenServer.call(agent, {:get_action_samples, game_state, opts}, timeout)
  end

  @doc """
  Get controller state for a game state.

  Returns a ControllerState struct ready to send to the bridge.
  """
  @spec get_controller(GenServer.server(), GameState.t(), keyword()) ::
          {:ok, ControllerState.t()} | {:error, term()}
  def get_controller(agent, game_state, opts \\ []) do
    GenServer.call(agent, {:get_controller, game_state, opts})
  end

  @doc """
  Like `get_controller/3` but also returns the confidence map.

  Returns `{:ok, controller_state, confidence}` with sticks/shoulder already
  undiscretized to the 0..1 analog range and buttons as booleans — the raw
  action map from `get_action_with_confidence/3` contains bucket INDICES,
  which must never be sent to the bridge directly.
  """
  @spec get_controller_with_confidence(GenServer.server(), GameState.t(), keyword()) ::
          {:ok, ControllerState.t(), map()} | {:error, term()}
  def get_controller_with_confidence(agent, game_state, opts \\ []) do
    # :timeout (default 5_000) is consumed here, not forwarded. Callers that
    # can race a backgrounded JIT warmup (async_runner's inference loop) pass
    # a long timeout: the first call queues behind the warmup in this
    # GenServer, and 2026-08-21 a 5s default crashed the game runner at
    # frame -123 with "Inferences: 0" (GOTCHA #100 follow-up).
    {timeout, opts} = Keyword.pop(opts, :timeout, 5_000)
    GenServer.call(agent, {:get_controller_with_confidence, game_state, opts}, timeout)
  end

  @doc """
  Load a new policy, hot-swapping the current one.
  """
  @spec load_policy(GenServer.server(), Path.t() | map()) :: :ok | {:error, term()}
  def load_policy(agent, policy_or_path) do
    GenServer.call(agent, {:load_policy, policy_or_path})
  end

  @doc """
  Get current agent configuration.
  """
  @spec get_config(GenServer.server()) :: map()
  def get_config(agent) do
    GenServer.call(agent, :get_config)
  end

  @doc """
  Update agent settings.
  """
  @spec configure(GenServer.server(), keyword()) :: :ok
  def configure(agent, opts) do
    GenServer.call(agent, {:configure, opts})
  end

  @doc """
  Reset the frame buffer. Call this when starting a new game.
  """
  @spec reset_buffer(GenServer.server()) :: :ok
  def reset_buffer(agent) do
    GenServer.call(agent, :reset_buffer)
  end

  @doc """
  Observe-only step: feed one game frame plus the controller that was
  ACTUALLY applied on it into the agent's history WITHOUT running
  inference (closed-loop correction validation, 2026-09-12).

  Advances exactly the state a decision would: the windowed frame buffer
  (or the stateful-step trunk), the prev-action channel and the
  queue-as-input ring — with `controller` standing in for the action the
  policy would have emitted. Lets a scenario prefix warm the agent with
  the RECORDED history so a handoff mid-chain sees a saturated window and
  a truthful own-input queue, instead of the cold start `reset_buffer/1`
  leaves (which no policy can chain from — RESULTS.md §6 control).

  `controller` is a `%ExPhil.Bridge.ControllerState{}` or nil (nil = no
  queue/prev-action update, frame only). Options: `:player_port`.
  """
  @spec observe(GenServer.server(), map(), ExPhil.Bridge.ControllerState.t() | nil, keyword()) ::
          :ok | {:error, term()}
  def observe(agent, game_state, controller, opts \\ []) do
    GenServer.call(agent, {:observe, game_state, controller, opts})
  end

  @doc """
  Warmup JIT compilation by running a dummy inference.

  Call this during menu navigation so the first real game frame
  gets fast inference. Returns the warmup time in milliseconds.
  """
  @spec warmup(GenServer.server()) :: {:ok, non_neg_integer()} | {:error, term()}
  def warmup(agent) do
    # 2 minute timeout for JIT
    GenServer.call(agent, :warmup, 120_000)
  end

  @doc """
  Check if the agent has been warmed up (JIT compiled).
  """
  @spec warmed_up?(GenServer.server()) :: boolean()
  def warmed_up?(agent) do
    GenServer.call(agent, :warmed_up?)
  end

  @doc """
  Update session-tunable settings on a warm agent (policy-server pool
  reuse): sampling knobs, delay configuration, style, af convention.
  Structural options (checkpoint, stateful_step, LEACE/steering,
  registries) are part of the server's pool key and cannot change here.
  Re-runs the untrained-delay-id guard when delay_id changes.
  """
  @spec reconfigure(GenServer.server(), keyword()) :: :ok | {:error, term()}
  def reconfigure(agent, opts) do
    GenServer.call(agent, {:reconfigure, opts})
  end

  @doc """
  Snapshot the agent's recurrent inference state as a serializable blob.

  This is the rollback primitive for netplay (task #9): frames get
  re-simulated when remote inputs arrive late, so the policy must be able
  to restore its state to frame k and replay deterministically.

  The blob captures the Edifice.Stateful trunk state plus the agent's own
  per-frame bookkeeping (jump cooldown, last action/controller for the
  prev-action channel and hysteresis). Only available in stateful-step
  mode (`stateful_step: true` with a temporal GRU/LSTM policy).

  Returns `{:ok, binary}` or `{:error, :not_stateful}`.
  """
  @spec snapshot_state(GenServer.server()) :: {:ok, binary()} | {:error, term()}
  def snapshot_state(agent) do
    GenServer.call(agent, :snapshot_state)
  end

  @doc """
  Restore a state previously captured with `snapshot_state/1`.

  After restore, feeding the same frames produces the same actions the
  original timeline would have produced (deterministic modes).
  """
  @spec restore_state(GenServer.server(), binary()) :: :ok | {:error, term()}
  def restore_state(agent, blob) when is_binary(blob) do
    GenServer.call(agent, {:restore_state, blob})
  end

  # ============================================================================
  # GenServer Callbacks
  # ============================================================================

  @impl true
  def init(opts) do
    frame_delay = Keyword.get(opts, :frame_delay, 0)
    deterministic = Keyword.get(opts, :deterministic, false)
    temperature = Keyword.get(opts, :temperature, 1.0)
    deterministic_buttons = Keyword.get(opts, :deterministic_buttons, false)
    mode_of_n = Keyword.get(opts, :mode_of_n)
    press_threshold = Keyword.get(opts, :press_threshold)
    release_threshold = Keyword.get(opts, :release_threshold)
    action_repeat = Keyword.get(opts, :action_repeat, 1)

    critic =
      case Keyword.get(opts, :critic_path) do
        nil ->
          nil

        path ->
          c = ExPhil.Agents.CriticSelector.load!(path)

          Logger.warning(
            "[Agent] Critic-selector decode ACTIVE (#{path}, phi_size #{c.phi_size}, " <>
              "K=#{Keyword.get(opts, :critic_k, 16)})"
          )

          c
      end

    critic_k = Keyword.get(opts, :critic_k, 16)

    # Allow disabling incremental inference for testing/comparison
    use_incremental = Keyword.get(opts, :use_incremental, true)

    # Interp P3 ablation: force the prev-action channel to zeros at
    # inference even for policies trained with it (live arm of the
    # closed-loop shield-lock / self-conditioning experiments)
    ablate_prev_action = Keyword.get(opts, :ablate_prev_action, false)

    # Style-conditional inference: :style_id (integer) wins; else
    # :style_tag resolved through a :player_registry JSON (from training's
    # --player-registry vocab). Unknown tag -> 0 with a warning. ONE
    # resolver, shared with reconfigure (INVARIANTS.md item 7).
    style_id = ExPhil.Agents.Decode.resolve_style_id(opts)

    state = %__MODULE__{
      name: Keyword.get(opts, :name),
      frame_delay: frame_delay,
      frame_buffer: :queue.new(),
      deterministic: deterministic,
      temperature: temperature,
      deterministic_buttons: deterministic_buttons,
      mode_of_n: mode_of_n,
      critic: critic,
      critic_k: critic_k,
      press_threshold: press_threshold,
      release_threshold: release_threshold,
      controller_queue: [],
      # nil = derive from the checkpoint's label convention at load
      # (ExPhil.Data.LabelConvention.delay_id/2); an explicit value (the
      # --delay-id-override path) is used as given.
      delay_id: Keyword.get(opts, :delay_id),
      allow_untrained_delay_id: Keyword.get(opts, :allow_untrained_delay_id, false),
      # INVARIANTS item 12: default = the async runner (every deploy card);
      # the sync runner and the scenario suite declare themselves.
      harness: Keyword.get(opts, :harness, :async_runner),
      harness_knob: Keyword.get(opts, :harness_knob),
      # THE knob (INVARIANTS item 12): the physical reaction delay this agent
      # plays at; runners/suite resolve it once (HarnessRung.resolve/3) and
      # pass it here. nil = derive from harness + knob (legacy callers).
      reaction_delay: Keyword.get(opts, :reaction_delay),
      jump_debounce: Keyword.get(opts, :jump_debounce),
      jump_cooldown: 0,
      ablate_prev_action: ablate_prev_action,
      leace_eraser: Keyword.get(opts, :leace_eraser),
      steer_vector: Keyword.get(opts, :steer_vector),
      steer_alpha: Keyword.get(opts, :steer_alpha) || 1.0,
      steer_v: nil,
      style_id: style_id,
      player_registry: Keyword.get(opts, :player_registry),
      uncertainty_log: Keyword.get(opts, :uncertainty_log),
      uncertainty_buf: [],
      # Temporal config - will be set when policy is loaded
      temporal: false,
      backbone: :mlp,
      window_size: 60,
      # Controller head (AUTOREGRESSIVE_HEAD_PLAN): set from checkpoint
      # config at load; :autoregressive dispatches sampling to
      # Policy.sample_autoregressive (predict_fn is then the TRUNK fn)
      head: :independent,
      # JIT warmup
      warmed_up: false,
      # Action repeat
      action_repeat: action_repeat,
      frames_since_inference: 0,
      last_action: nil,
      # Mamba incremental inference (will be initialized when Mamba policy loads)
      mamba_cache: nil,
      use_incremental: use_incremental,
      # Edifice.Stateful step-path inference (activated at policy load when
      # the backbone supports it)
      stateful_step: Keyword.get(opts, :stateful_step, false),
      af_convention: Keyword.get(opts, :af_convention, :parsed),
      trunk_state: nil,
      trunk_step_params: nil,
      heads_predict_fn: nil,
      trunk_cold: true,
      stateful_resync: Keyword.get(opts, :stateful_resync, nil),
      step_frame_buffer: [],
      steps_since_resync: 0
    }

    # Typed decode struct — the single source every decision path reads
    # (validated loudly here, not at frame 60).
    state = %{state | decode: ExPhil.Agents.Decode.from_state(state)}

    # Load policy if provided. An explicitly requested policy that fails to
    # load is FATAL: continuing without one runs a phantom (random-init)
    # policy, which scores 0 and looks like a real eval (2026-07-30 farm 10:
    # three "evals" ran against a checkpoint that was never written).
    load_result =
      cond do
        Keyword.has_key?(opts, :policy_path) ->
          load_policy_internal(state, Keyword.fetch!(opts, :policy_path))

        Keyword.has_key?(opts, :policy) ->
          load_policy_internal(state, Keyword.fetch!(opts, :policy))

        true ->
          {:ok, state}
      end

    case load_result do
      {:ok, state} ->
        {:ok, state}

      {:error, reason} ->
        Logger.error("[Agent] Failed to load policy: #{inspect(reason)} — refusing to start")
        {:stop, {:policy_load_failed, reason}}
    end
  end

  @impl true
  def handle_call({:get_action, game_state, opts}, _from, state) do
    case compute_action(state, game_state, opts) do
      {:ok, action, _confidence, new_state} ->
        {:reply, {:ok, action}, new_state}

      {:error, _} = error ->
        {:reply, error, state}
    end
  end

  @impl true
  def handle_call({:get_action_with_confidence, game_state, opts}, _from, state) do
    case compute_action(state, game_state, opts) do
      {:ok, action, confidence, new_state} ->
        {:reply, {:ok, action, confidence}, new_state}

      {:error, _} = error ->
        {:reply, error, state}
    end
  end

  @impl true
  def handle_call({:get_action_samples, game_state, opts}, _from, state) do
    # Reply with the UNCHANGED state on purpose: this is an instrument path
    # and must not perturb debounce bookkeeping, the temporal buffer, or any
    # cache (see compute_action_samples/3).
    {:reply, compute_action_samples(state, game_state, opts), state}
  end

  @impl true
  def handle_call({:get_controller, game_state, opts}, _from, state) do
    case compute_action(state, game_state, opts) do
      {:ok, action, confidence, new_state} ->
        controller = action_to_controller(action, state)
        new_state = log_uncertainty(new_state, game_state, confidence)
        {:reply, {:ok, controller}, new_state}

      {:error, _} = error ->
        {:reply, error, state}
    end
  end

  @impl true
  def handle_call({:get_controller_with_confidence, game_state, opts}, _from, state) do
    case compute_action(state, game_state, opts) do
      {:ok, action, confidence, new_state} ->
        controller = action_to_controller(action, state)
        {:reply, {:ok, controller, confidence}, new_state}

      {:error, _} = error ->
        {:reply, error, state}
    end
  end

  @impl true
  def handle_call({:load_policy, policy_or_path}, _from, state) do
    case load_policy_internal(state, policy_or_path) do
      {:ok, new_state} ->
        Logger.info("[Agent] Policy loaded successfully")
        {:reply, :ok, new_state}

      {:error, _} = error ->
        {:reply, error, state}
    end
  end

  @impl true
  def handle_call(:get_config, _from, state) do
    config = %{
      name: state.name,
      frame_delay: state.frame_delay,
      deterministic: state.deterministic,
      temperature: state.temperature,
      mode_of_n: state.mode_of_n,
      head: state.head,
      has_policy: state.policy_params != nil,
      # Temporal config
      temporal: state.temporal,
      backbone: state.backbone,
      window_size: state.window_size,
      buffer_size: :queue.len(state.frame_buffer),
      # Incremental inference status
      use_incremental: state.use_incremental,
      incremental_active: state.mamba_cache != nil,
      incremental_step: if(state.mamba_cache, do: state.mamba_cache.step, else: 0),
      # Edifice.Stateful step path status
      stateful_step: state.stateful_step,
      stateful_step_active: state.trunk_state != nil
    }

    {:reply, config, state}
  end

  @impl true
  def handle_call({:observe, game_state, controller, opts}, _from, state) do
    case do_observe(state, game_state, controller, opts) do
      {:ok, new_state, nil} -> {:reply, :ok, new_state}
      {:ok, new_state, probe} -> {:reply, {:ok, probe}, new_state}
      {:error, _} = err -> {:reply, err, state}
    end
  end

  @impl true
  def handle_call(:reset_buffer, _from, state) do
    # Reset mamba cache if using incremental inference
    new_mamba_cache =
      if state.backbone == :mamba and state.use_incremental do
        init_mamba_cache(state)
      else
        state.mamba_cache
      end

    # Reset the Edifice.Stateful trunk state (step path) — a fresh init is
    # exactly the state a fresh game should start from (equivalence pinned
    # by test/exphil/networks/stateful_step_equivalence_test.exs)
    new_trunk_state =
      if state.trunk_state != nil do
        init_trunk_state(state.trunk_step_params, state.embed_config, state.backbone)
      else
        nil
      end

    new_state = %{
      state
      | frame_buffer: :queue.new(),
        last_action: nil,
        last_controller: nil,
        controller_queue: [],
        frames_since_inference: 0,
        mamba_cache: new_mamba_cache,
        trunk_state: new_trunk_state,
        trunk_cold: true,
        step_frame_buffer: [],
        steps_since_resync: 0
    }

    {:reply, :ok, new_state}
  end

  @impl true
  def handle_call(:warmup, _from, state) do
    if state.policy_params == nil do
      {:reply, {:error, AgentError.new(:no_policy_loaded, agent: state.name)}, state}
    else
      Logger.info("[Agent] Starting JIT warmup...")
      start_time = System.monotonic_time(:millisecond)

      # Create a dummy game state for warmup
      stage_t0 = System.monotonic_time(:millisecond)
      dummy_state = create_dummy_game_state()
      dummy_embedded = embed_game_state(dummy_state, 1, state)

      stage = fn label, prev ->
        now = System.monotonic_time(:millisecond)
        Logger.info("[Agent] warmup stage #{label}: #{now - prev}ms")
        now
      end

      stage_t = stage.("embed", stage_t0)

      # Run inference to trigger JIT compilation
      cond do
        state.trunk_state != nil ->
          # Stateful step path: compile the trunk step + heads-only predict.
          # The warmup step runs on a THROWAWAY copy of the trunk state — the
          # real state must not advance before the first game frame.
          frame = Nx.reshape(dummy_embedded, {1, Nx.size(dummy_embedded)})

          {features, _new_trunk_state} =
            trunk_step_fn().(state.trunk_step_params, state.trunk_state, frame)

          stage_t = stage.("trunk_step", stage_t)

          # The live step path samples via Policy.sample(heads_predict_fn,
          # features) — same fused-sampler compile hazard as the windowed
          # path (see warmup_sample), so warm THAT program, not the bare
          # heads predict. (AR head: heads_predict_fn is nil and
          # warmup_sample dispatches to the sequential sampler.)
          warmup_sample(state, state.heads_predict_fn, features)

          _ = stage.("heads_sample", stage_t)

        state.temporal ->
          # For temporal models, we need a full window of dummy embeddings
          dummy_sequence =
            List.duplicate(dummy_embedded, state.window_size)
            |> Nx.stack()
            # Add batch dimension
            |> Nx.new_axis(0)

          warmup_sample(state, state.predict_fn, dummy_sequence)

        true ->
          # For MLP, just single frame
          input = Nx.reshape(dummy_embedded, {1, :auto})
          warmup_sample(state, state.predict_fn, input)
      end

      elapsed = System.monotonic_time(:millisecond) - start_time
      Logger.info("[Agent] JIT warmup complete (#{elapsed}ms)")

      {:reply, {:ok, elapsed}, %{state | warmed_up: true}}
    end
  end

  # Warmup must go through Policy.sample, not the bare predict_fn: sampling
  # runs the 6 heads through a SEPARATE fused JIT program (fused_det /
  # fused_stoch in Policy.Sampling), which otherwise compiles on the first
  # real game frame. Over netplay that ~1-2 min compile stalls the bot's
  # input feed and freezes BOTH peers at the match countdown (observed
  # Direct A/B 2026-08-07 — the human had to restart Dolphin). Two calls
  # cover the prev_buttons nil-vs-tensor hysteresis variants the live loop
  # hits on frame 1 vs frame 2+.
  defp warmup_sample(state, predict_fn, input) do
    # Same builder as the live paths (INVARIANTS.md item 7); the two
    # prev_buttons variants below override the last key.
    sample_opts = ExPhil.Agents.Decode.sample_opts(state, []) |> Keyword.delete(:prev_buttons)

    # AR-head checkpoints warm the sequential sampler instead — the same
    # program the live loop hits (stage1/stage2 kernels + trunk).
    # predict_fn == nil marks the stateful-step arm (input = features).
    sampler = fn opts ->
      cond do
        state.head == :autoregressive and predict_fn == nil ->
          Networks.Policy.sample_autoregressive_from_features(state.policy_params, input, opts)

        state.head == :autoregressive ->
          Networks.Policy.sample_autoregressive(state.policy_params, predict_fn, input, opts)

        true ->
          Networks.Policy.sample(state.policy_params, predict_fn, input, opts)
      end
    end

    t0 = System.monotonic_time(:millisecond)

    first = sampler.(Keyword.put(sample_opts, :prev_buttons, nil))

    t1 = System.monotonic_time(:millisecond)
    Logger.info("[Agent] warmup stage sample1 (predict+heads compile): #{t1 - t0}ms")

    _second = sampler.(Keyword.put(sample_opts, :prev_buttons, first[:buttons]))

    t2 = System.monotonic_time(:millisecond)
    Logger.info("[Agent] warmup stage sample2 (prev-buttons variant): #{t2 - t1}ms")

    # Critic-selector: the live path runs the TILED stage kernels
    # (ar_stage1/ar_stage2 at n=critic_k) — warm that shape too, or the
    # first real decision pays the compile (netplay freeze class, see
    # comment above). mode_of_n exercises the exact same kernels/shapes.
    if state.critic && state.head == :autoregressive do
      _ = sampler.(Keyword.put(sample_opts, :mode_of_n, state.critic_k))
      :ok = ExPhil.Agents.CriticSelector.warmup(state.critic, state.critic_k)

      Logger.info(
        "[Agent] warmup stage critic tiled kernels + pick (K=#{state.critic_k}): " <>
          "#{System.monotonic_time(:millisecond) - t2}ms"
      )
    end

    _confidence = Networks.Policy.compute_confidence(first)

    Logger.info(
      "[Agent] warmup stage confidence: #{System.monotonic_time(:millisecond) - t2}ms"
    )

    :ok
  end

  @tunable_opts [
    :deterministic,
    :temperature,
    :deterministic_buttons,
    :mode_of_n,
    :press_threshold,
    :release_threshold,
    :jump_debounce,
    :frame_delay,
    :delay_id,
    :allow_untrained_delay_id,
    :ablate_prev_action,
    :style_id,
    :style_tag,
    :stateful_resync,
    :af_convention
  ]

  @impl true
  def handle_call({:reconfigure, opts}, _from, state) do
    unknown = Keyword.keys(opts) -- @tunable_opts

    if unknown != [] do
      {:reply, {:error, {:not_tunable, unknown}}, state}
    else
      new_state =
        Enum.reduce(opts, state, fn {k, v}, acc -> Map.put(acc, k, v) end)

      # style_tag / style_id go through the SAME resolver init uses.
      # Before 2026-09-09 `reconfigure(style_tag: "X")` returned :ok and
      # did nothing (style_tag was never a struct field), so a style A/B
      # through the policy server ran two identical arms.
      new_state =
        if Keyword.has_key?(opts, :style_tag) or Keyword.has_key?(opts, :style_id) do
          %{
            new_state
            | style_id: ExPhil.Agents.Decode.resolve_style_id(opts, state.player_registry)
          }
          |> Map.delete(:style_tag)
        else
          new_state
        end

      # A new frame_delay without an explicit delay_id re-derives the id
      # from the checkpoint's label convention (same rule as load time).
      new_state =
        if (Keyword.has_key?(opts, :reaction_delay) or Keyword.has_key?(opts, :frame_delay) or
              Keyword.has_key?(opts, :harness_knob)) and
             not Keyword.has_key?(opts, :delay_id) and new_state.label_convention != nil do
          cfg = %{
            label_convention: new_state.label_convention,
            train_delays: new_state.train_delays,
            delay_id_reaction_offset: new_state.delay_id_reaction_offset,
            with_delay_id: Map.get(new_state.embed_config || %{}, :with_delay_id, false)
          }

          harness = new_state.harness || :async_runner
          knob = Keyword.get(opts, :harness_knob, new_state.frame_delay || 0)

          played =
            Keyword.get(opts, :reaction_delay) ||
              ExPhil.Eval.HarnessRung.reaction_delay(harness, knob)

          %{
            new_state
            | harness_knob: knob,
              reaction_delay: played,
              delay_id: ExPhil.Eval.HarnessRung.delay_id_for_reaction(played, cfg)
          }
        else
          new_state
        end

      # Delay-id guard applies to the NEW settings (pool reuse must not
      # sneak an untrained id past the boot-time check).
      if untrained_delay_id?(
           new_state.delay_id || 0,
           new_state.train_delays,
           Map.get(new_state.embed_config || %{}, :with_delay_id, false),
           new_state.allow_untrained_delay_id || false
         ) do
        {:reply, {:error, {:untrained_delay_id, new_state.delay_id}}, state}
      else
        # Rebuild the typed decode struct from the new fields (item 7 phase
        # B): reconfigure is the only other constructor call site.
        {:reply, :ok, %{new_state | decode: ExPhil.Agents.Decode.from_state(new_state)}}
      end
    end
  end

  @impl true
  def handle_call(:warmed_up?, _from, state) do
    {:reply, state.warmed_up, state}
  end

  @impl true
  def handle_call(:snapshot_state, _from, state) do
    if state.trunk_state == nil do
      {:reply, {:error, :not_stateful}, state}
    else
      blob =
        :erlang.term_to_binary(%{
          version: 1,
          trunk_state: Edifice.Stateful.serialize(state.trunk_state),
          trunk_cold: state.trunk_cold,
          jump_cooldown: state.jump_cooldown,
          last_action: state.last_action && Edifice.Stateful.serialize(state.last_action),
          last_controller: state.last_controller,
          frames_since_inference: state.frames_since_inference
        })

      {:reply, {:ok, blob}, state}
    end
  end

  @impl true
  def handle_call({:restore_state, blob}, _from, state) do
    if state.trunk_state == nil do
      {:reply, {:error, :not_stateful}, state}
    else
      snap = :erlang.binary_to_term(blob)

      new_state = %{
        state
        | trunk_state: Edifice.Stateful.deserialize(snap.trunk_state),
          trunk_cold: Map.get(snap, :trunk_cold, false),
          jump_cooldown: snap.jump_cooldown,
          last_action: snap.last_action && Edifice.Stateful.deserialize(snap.last_action),
          last_controller: snap.last_controller,
          frames_since_inference: snap.frames_since_inference
      }

      {:reply, :ok, new_state}
    end
  rescue
    e -> {:reply, {:error, {:invalid_snapshot, e}}, state}
  end

  @impl true
  def handle_call({:configure, opts}, _from, state) do
    state =
      state
      |> maybe_update(:deterministic, opts)
      |> maybe_update(:temperature, opts)
      |> maybe_update(:frame_delay, opts)
      |> maybe_update(:reaction_delay, opts)
      |> maybe_update(:press_threshold, opts)
      |> maybe_update(:release_threshold, opts)

    {:reply, :ok, state}
  end

  @impl true
  def terminate(_reason, state) do
    # Final uncertainty flush (flywheel A4) — partial buffers survive
    # normal GenServer.stop at session end.
    flush_uncertainty(state)
    :ok
  end

  # ============================================================================
  # Private
  # ============================================================================

  defp compute_action(state, _game_state, _opts) when state.policy_params == nil do
    {:error, AgentError.new(:no_policy_loaded, agent: state.name)}
  end

  defp compute_action(state, game_state, opts) do
    frame = game_state.frame

    cond do
      # ONE DECISION PER GAME FRAME. Async polls faster than Dolphin
      # produces frames (~1.4-2.2 calls/frame observed), and a same-frame
      # re-inference has no upside for identical state but actively
      # corrupts self-referential conditioning: after decision #1 pushes
      # the ring, re-inference #2 would embed with slot 1 = an action the
      # game hasn't applied yet. Training's invariant is one decision per
      # frame with slot 1 = the PREVIOUS frame's action — so on a repeated
      # frame, re-send the cached action. (frame < last is a NEW GAME,
      # which must infer; nil frames infer.)
      is_integer(frame) and frame == state.last_debounce_frame and state.last_action != nil ->
        default_conf = %{overall: 0.0, buttons: 0.0, main: 0.0, c: 0.0, shoulder: 0.0}
        {:ok, state.last_action, default_conf, state}

      # Action repeat: return cached action if we haven't hit the repeat interval
      state.action_repeat > 1 and state.last_action != nil and
          state.frames_since_inference < state.action_repeat ->
        # Return cached action with default confidence, increment counter
        new_state = %{state | frames_since_inference: state.frames_since_inference + 1}
        default_conf = %{overall: 0.0, buttons: 0.0, main: 0.0, c: 0.0, shoulder: 0.0}
        {:ok, state.last_action, default_conf, new_state}

      true ->
        # Time to run actual inference
        do_compute_action(state, game_state, opts)
    end
  end

  defp do_compute_action(state, game_state, opts) do
    try do
      warn_cold_start_mid_game(state, game_state)

      # Embed game state. Port: under Slippi Online the bridge detects the
      # bot's ACTUAL in-game port via connect codes (Slippi assigns ports
      # per session — the static --port guess ego-swapped the embedding
      # when the bot drew port 2, observed Direct 2026-08-01: the policy
      # saw the HUMAN as "self" and degenerated into hold-B).
      player_port = effective_port(game_state, opts)
      embedded = embed_game_state(game_state, player_port, state)

      # Critic-selector decode: inject the K-sample scorer for this decision
      # (closure captures this frame's raw state features; the sampler hands
      # it the trunk features + tiled candidates).
      opts = maybe_critic_opts(state, game_state, player_port, opts)

      # Route to appropriate inference mode
      {action, confidence, new_state} =
        cond do
          # GatedSSM with incremental inference (O(1) per frame).
          # Only :gated_ssm — the step/param-extraction code assumes GatedSSM
          # layer names; Mamba checkpoints (mamba_block_*) must use predict_fn.
          state.temporal and state.backbone == :gated_ssm and state.use_incremental and
              state.mamba_cache != nil ->
            compute_incremental_mamba_action(state, embedded, opts)

          # Edifice.Stateful step path (O(1) per frame): advance the GRU/LSTM
          # trunk state with the current frame only, then run the heads-only
          # predict on the resulting features. Opt-in via --stateful-step.
          state.temporal and state.trunk_state != nil ->
            compute_stateful_step_action(state, embedded, opts)

          # Standard temporal inference (O(window_size) per frame)
          state.temporal ->
            compute_temporal_action(state, embedded, opts)

          # Single-frame MLP inference
          true ->
            compute_single_frame_action(state, embedded, opts)
        end

      # Jump re-press debounce BEFORE caching, so hysteresis prev_buttons and
      # the prev-action channel both see the buttons actually emitted.
      # Airborne-only: grounded re-presses (jump out of shield, restarts) are
      # legitimate and cannot cause the liftoff double jump — suppressing
      # them locked the bot in shield (observed live 2026-07-15: OOS jump
      # blocked -> held shield through hits -> breaks).
      airborne? =
        case game_state.players[player_port] do
          %{on_ground: grounded} -> not grounded
          _ -> false
        end

      # Cooldown ticks by GAME-FRAME delta, not call count: multiple
      # inferences on one frame must not burn the window (r14 escape).
      frame = game_state.frame
      last_frame = new_state.last_debounce_frame

      # New game: frame counters reset (to -123)
      game_reset? = is_integer(frame) and is_integer(last_frame) and frame < last_frame

      frame_delta =
        cond do
          not (is_integer(frame) and is_integer(last_frame)) -> 1
          # On reset: resync, don't freeze
          game_reset? -> 1
          true -> frame - last_frame
        end

      # Arm the window at JUMPSQUAT and at LIFTOFF (not only on button
      # release): tap-jump first jumps never release a button, and at
      # ~2.2 calls/frame the agent can emit a press while still SEEING
      # grounded that lands airborne one frame later — jumpsquat (action
      # 24, visible 5f before liftoff on Mewtwo) is the earliest reliable
      # "a jump is already in progress" signal, when a second jump press
      # has no legitimate purpose (residual 1-2f DJs, 2026-07-18).
      player = game_state.players[player_port]
      in_jumpsquat? = player != nil and trunc(player.action || 0) == 24
      liftoff? = airborne? and new_state.was_airborne == false

      new_state =
        if (in_jumpsquat? or liftoff?) and is_integer(new_state.jump_debounce) and
             new_state.jump_debounce > 0 do
          %{new_state | jump_cooldown: max(new_state.jump_cooldown || 0, new_state.jump_debounce)}
        else
          new_state
        end

      # Suppression context includes jumpsquat: a NEW jump press during an
      # in-progress jumpsquat is the liftoff-DJ impulse arriving early
      # (grounded-at-decision, airborne-on-arrival). OOS jumps come from
      # shield states (178-182), never 24 — still pass. Drill restarts
      # press BEFORE entering 24 — still pass.
      {action, new_state} =
        apply_jump_debounce(action, new_state, airborne? or in_jumpsquat?, frame_delta)

      new_state = %{new_state | last_debounce_frame: frame, was_airborne: airborne?}

      # Remember the emitted controller for the prev-action channel (only
      # decoded here when the policy was trained to see it)
      last_controller =
        if new_state.use_prev_action do
          action_to_controller(action, new_state)
        else
          nil
        end

      # Queue-as-input ring buffer: newest first, truncated to the policy's
      # trained queue depth. Advanced by GAME FRAME, not by decision: async
      # runs >1 inference/frame, and per-decision pushes warp the ring's
      # timescale (slot k became "k CALLS ago" — invisible in the sync
      # harness where calls == frames, live corruption for queue policies).
      new_state =
        case queue_depth(new_state) do
          depth when depth > 1 and last_controller != nil ->
            queue =
              update_controller_queue(
                new_state.controller_queue || [],
                last_controller,
                frame_delta,
                game_reset?,
                depth
              )

            # EXPHIL_QUEUE_TRACE=1: one line per decision with the ring's
            # contents (live-queue forensics, 2026-07-31 — pair with the
            # replay to diff live slots against training-space queues).
            if System.get_env("EXPHIL_QUEUE_TRACE") do
              enc = fn c ->
                btns =
                  [{c.button_a, "A"}, {c.button_b, "B"}, {c.button_x, "X"},
                   {c.button_y, "Y"}, {c.button_z, "Z"}, {c.button_l, "L"},
                   {c.button_r, "R"}]
                  |> Enum.filter(&elem(&1, 0))
                  |> Enum.map_join(&elem(&1, 1))

                "#{btns}:#{Float.round(c.main_stick.x * 1.0, 4)},#{Float.round(c.main_stick.y * 1.0, 4)}"
              end

              slots = Enum.map_join(queue, " ", enc)

              # Applied inputs as the GAME reports them (live libmelee
              # controller_state) — replay-free ground truth for the
              # decode->send->apply chain.
              applied =
                case player && player.controller_state do
                  nil -> "-"
                  cs -> enc.(cs)
                end

              # act= is the bot's ACTION STATE — landed-technique ground
              # truth. Chains are scored from this via ShineChain (analyze_
              # qtrace.exs), never from the applied B presses: commanded
              # down-B is eaten during jumpsquat etc., so press runs
              # overcount chains wildly (0822 lesson).
              act = if player, do: player.action, else: "-"

              IO.puts("[qtrace] f#{frame} act=#{act} applied=#{applied} #{slots}")
            end

            %{new_state | controller_queue: queue}

          _ ->
            new_state
        end

      # Cache action for action repeat
      new_state = %{
        new_state
        | last_action: action,
          last_controller: last_controller,
          frames_since_inference: 1,
          # Mark as warmed up after first successful inference
          warmed_up: true
      }

      {:ok, action, confidence, new_state}
    rescue
      e ->
        Logger.error("[Agent] Error computing action: #{inspect(e)}")
        {:error, e}
    end
  end

  # INVARIANTS item 13 (guard): a stateful policy handed a MID-GAME state
  # with an empty history is off-distribution (09-12: ep57 could not chain
  # from its own game's handoffs until the suite warmed it with the true
  # history). Fires once per game, on the first decision only.
  defp warn_cold_start_mid_game(state, game_state) do
    frame = game_state.frame

    empty? =
      state.temporal and :queue.is_empty(state.frame_buffer) and
        (state.trunk_state == nil or state.trunk_cold)

    if empty? and is_integer(frame) and frame > (state.window_size || 0) + 120 do
      Logger.warning(
        "[Agent] COLD START mid-game at frame #{frame} with an empty history (window " <>
          "#{state.window_size}): warm the agent with the true history first " <>
          "(Agent.observe/4 per prefix frame; INVARIANTS item 13)"
      )
    end
  end

  # Observe-only history advance (see observe/4). Mirrors do_compute_action's
  # state bookkeeping minus the decision: embed (prev-action slot = the last
  # observed/emitted controller, queue = the ring as it stands), push the
  # frame into whichever history the inference path reads, then push the
  # applied controller into the ring by GAME-FRAME delta. last_action is
  # cleared so the same-frame decision cache cannot replay a stale action
  # on the first real decision after a warm-up.
  defp do_observe(state, game_state, controller, opts) do
    try do
      player_port = effective_port(game_state, opts)
      embedded = embed_game_state(game_state, player_port, state)

      probe? = Keyword.get(opts, :probe, false)

      {new_state, probe} =
        cond do
          state.temporal and state.trunk_state != nil ->
            {features, st} = observe_stateful_step(state, embedded)

            {st,
             probe? and state.heads_predict_fn != nil and
               head_probs(state.heads_predict_fn, state.policy_params, features, opts)}

          state.temporal ->
            buffer = :queue.in(embedded, state.frame_buffer)
            {buffer, _} = trim_buffer(buffer, state.window_size)

            probe =
              probe? and state.head != :autoregressive and
                (fn ->
                   seq =
                     if :queue.len(buffer) < state.window_size,
                       do: pad_sequence(buffer, state.window_size),
                       else: buffer_to_tensor(buffer)

                   seq = Nx.reshape(seq, {1, state.window_size, Nx.size(embedded)})
                   head_probs(state.predict_fn, state.policy_params, seq, opts)
                 end).()

            {%{state | frame_buffer: buffer}, probe}

          true ->
            {state, false}
        end

      probe = if probe == false, do: nil, else: probe

      frame = game_state.frame
      last_frame = new_state.last_debounce_frame
      game_reset? = is_integer(frame) and is_integer(last_frame) and frame < last_frame

      frame_delta =
        cond do
          not (is_integer(frame) and is_integer(last_frame)) -> 1
          game_reset? -> 1
          true -> frame - last_frame
        end

      airborne? =
        case game_state.players[player_port] do
          %{on_ground: grounded} -> not grounded
          _ -> false
        end

      new_state =
        case queue_depth(new_state) do
          depth when depth > 1 and controller != nil ->
            queue =
              update_controller_queue(
                new_state.controller_queue || [],
                controller,
                frame_delta,
                game_reset?,
                depth
              )

            %{new_state | controller_queue: queue}

          _ ->
            new_state
        end

      last_controller =
        cond do
          not new_state.use_prev_action -> nil
          controller != nil -> controller
          true -> new_state.last_controller
        end

      {:ok,
       %{
         new_state
         | last_debounce_frame: frame,
           was_airborne: airborne?,
           last_controller: last_controller,
           last_action: nil
       }, probe}
    rescue
      e ->
        Logger.error("[Agent] Error observing frame: #{inspect(e)}")
        {:error, e}
    end
  end

  # Stateful-step observe: same cold-start pad + one trunk step as the
  # decision path, features discarded. Resync is a decision-path concern;
  # the counter still ticks so the next decision resyncs on schedule.
  defp observe_stateful_step(state, embedded) do
    frame = Nx.reshape(embedded, {1, Nx.size(embedded)})

    trunk_state =
      if state.trunk_cold and not (state.bptt == true) do
        Enum.reduce(1..max(state.window_size - 1, 0)//1, state.trunk_state, fn _, st ->
          {_out, st} = trunk_step_fn().(state.trunk_step_params, st, frame)
          st
        end)
      else
        state.trunk_state
      end

    buffer = Enum.take([frame | state.step_frame_buffer], max(state.window_size - 1, 1))
    {features, new_trunk_state} = trunk_step_fn().(state.trunk_step_params, trunk_state, frame)

    {features,
     %{
       state
       | trunk_state: new_trunk_state,
         trunk_cold: false,
         step_frame_buffer: buffer,
         steps_since_resync: state.steps_since_resync + 1
     }}
  end

  # Teacher-forced head read for observe(probe: true): the independent
  # heads' probabilities on the history INCLUDING this frame (buttons =
  # per-button sigmoid in order a,b,x,y,z,l,r,d_up; sticks/shoulder =
  # softmax over buckets), at the agent's temperature unless overridden.
  # No sampling, no history mutation beyond the observe itself.
  defp head_probs(predict_fn, params, input, opts) do
    t = Keyword.get(opts, :temperature, 1.0) * 1.0

    {b, mx, my, cx, cy, sh} = predict_fn.(Utils.ensure_model_state(params), input)

    sm = fn l -> l |> Nx.squeeze() |> Nx.divide(t) |> Axon.Activations.softmax() |> Nx.to_flat_list() end

    %{
      buttons: b |> Nx.squeeze() |> Nx.divide(t) |> Nx.sigmoid() |> Nx.to_flat_list(),
      main_x: sm.(mx),
      main_y: sm.(my),
      c_x: sm.(cx),
      c_y: sm.(cy),
      shoulder: sm.(sh)
    }
  end

  # Jump re-press debounce (pathology #4 band-aid): after both jump buttons
  # (X=2, Y=3) release, suppress NEW press edges for jump_debounce frames.
  # Existing holds are never cut, so full hops are unaffected; the learned
  # 1-frame liftoff double jump cannot fire, while data-like DJs (12-16f
  # after liftoff) pass untouched.
  # Public for direct unit testing (pure tensor logic on a plain state map);
  # not part of the Agent API.
  @doc false
  def apply_jump_debounce(action, state, airborne?, frame_delta \\ 1)

  def apply_jump_debounce(action, %{jump_debounce: n} = state, airborne?, frame_delta)
      when is_integer(n) and n > 0 do
    buttons = action[:buttons]
    prev = state.last_action && state.last_action[:buttons]

    # Per-COLUMN X/Y values, not just the joint max: an X->Y alternation
    # (release X + press Y same frame, or press Y while X is held) reads
    # as a continuous hold under joint semantics and evaded suppression —
    # r12's debounce arm still produced 2f double jumps (WS3, 2026-07-17).
    col = fn t, i -> t |> Nx.slice_along_axis(i, 1, axis: 1) |> Nx.reduce_max() |> Nx.to_number() end
    {x_now, y_now} = {col.(buttons, 2), col.(buttons, 3)}
    {x_prev, y_prev} = if prev, do: {col.(prev, 2), col.(prev, 3)}, else: {0, 0}

    prev_jump? = x_prev > 0 or y_prev > 0
    want_jump? = x_now > 0 or y_now > 0
    # a jump COLUMN going 0 -> pressed is a new initiation even if the
    # other column is still held (pressing a second jump button has no
    # purpose but a double jump)
    new_col_press? = (x_now > 0 and x_prev == 0) or (y_now > 0 and y_prev == 0)
    any_col_release? = (x_prev > 0 and x_now == 0) or (y_prev > 0 and y_now == 0)

    cooldown = max((state.jump_cooldown || 0) - max(frame_delta, 0), 0)

    {buttons, cooldown, decision} =
      cond do
        # new AIRBORNE column press while cooling down OR while the other
        # jump button is already held -> suppress the newly pressed
        # column(s); a held column is never cut (full hops unaffected).
        # (Grounded presses always pass: OOS jump, drill restarts.)
        airborne? and new_col_press? and (cooldown > 0 or prev_jump?) ->
          buttons =
            if x_now > 0 and x_prev == 0,
              do: Nx.put_slice(buttons, [0, 2], Nx.broadcast(Nx.tensor(0, type: Nx.type(buttons)), {1, 1})),
              else: buttons

          buttons =
            if y_now > 0 and y_prev == 0,
              do: Nx.put_slice(buttons, [0, 3], Nx.broadcast(Nx.tensor(0, type: Nx.type(buttons)), {1, 1})),
              else: buttons

          # a same-frame alternation is also a release -> arm the window
          {buttons, (if any_col_release?, do: n, else: cooldown), :suppress}

        # any column release -> arm the cooldown window
        any_col_release? ->
          {buttons, n, :arm}

        true ->
          {buttons, cooldown, :pass}
      end

    # Decision trace for the instant-DJ hunt (r14: 1-2f DJs survive both
    # arms). EXPHIL_DEBOUNCE_TRACE=1 logs every jump-column event with the
    # full decision context; grep '[DBNC]' from the probe log.
    if System.get_env("EXPHIL_DEBOUNCE_TRACE") == "1" and
         (new_col_press? or any_col_release? or want_jump?) do
      Logger.info(
        "[DBNC] #{decision} air=#{airborne?} x=#{x_prev}->#{x_now} y=#{y_prev}->#{y_now} " <>
          "cooldown=#{state.jump_cooldown || 0}->#{cooldown} new_press=#{new_col_press?} release=#{any_col_release?}"
      )
    end

    {Map.put(action, :buttons, buttons), %{state | jump_cooldown: cooldown}}
  end

  def apply_jump_debounce(action, state, _airborne?, _frame_delta), do: {action, state}

  # Single-frame inference (original behavior)
  defp compute_single_frame_action(state, embedded, opts) do
    # Add batch dimension [1, embed_size]
    embedded_batch = Nx.reshape(embedded, {1, Nx.size(embedded)})

    # Fourth decode path (MLP / single-frame) — same builder (INVARIANTS.md
    # item 7); it previously omitted select_n/select_fn.
    action =
      Networks.Policy.sample(
        state.policy_params,
        state.predict_fn,
        embedded_batch,
        ExPhil.Agents.Decode.sample_opts(state, opts)
      )

    # Compute confidence from logits
    confidence = Networks.Policy.compute_confidence(action)

    {action, confidence, state}
  end

  # Temporal inference with frame buffering
  # INSTRUMENT PATH (get_action_samples/3): n independent AR joint samples
  # at one game state. Deliberately side-effect-free — no debounce
  # bookkeeping, no buffer/cache mutation — so a scorer can call it once per
  # decision frame after replaying history via get_controller without
  # perturbing the normal decision stream. Windowed temporal AR checkpoints
  # only: the stateful/incremental paths hold hidden state this must not
  # advance.
  defp compute_action_samples(state, game_state, opts) do
    n = Keyword.get(opts, :n, 16)

    cond do
      state.policy_params == nil ->
        {:error, AgentError.new(:no_policy_loaded, agent: state.name)}

      state.head != :autoregressive ->
        {:error, :not_autoregressive}

      not state.temporal or state.trunk_state != nil or state.mamba_cache != nil ->
        {:error, :windowed_temporal_only}

      true ->
        player_port = effective_port(game_state, opts)
        embedded = embed_game_state(game_state, player_port, state)

        # Same sequence construction as compute_temporal_action — the
        # decision frame is part of its own window — on a LOCAL copy of the
        # buffer that is then discarded.
        buffer = :queue.in(embedded, state.frame_buffer)
        {buffer, _dropped} = trim_buffer(buffer, state.window_size)

        sequence =
          if :queue.len(buffer) < state.window_size do
            pad_sequence(buffer, state.window_size)
          else
            buffer_to_tensor(buffer)
          end

        sequence_batch = Nx.reshape(sequence, {1, state.window_size, Nx.size(embedded)})

        samples =
          Networks.Policy.sample_autoregressive_n(
            state.policy_params,
            state.predict_fn,
            sequence_batch,
            n,
            temperature: Keyword.get(opts, :temperature, state.temperature),
            key: Keyword.get(opts, :key)
          )

        {:ok, samples}
    end
  end

  # Build the :select_n/:select_fn opts for the critic-selector decode.
  # AR head only (the tiled n>1 sampler is AR machinery); no-op otherwise.
  defp maybe_critic_opts(%{critic: nil}, _game_state, _port, opts), do: opts
  defp maybe_critic_opts(%{head: h}, _game_state, _port, opts) when h != :autoregressive, do: opts

  defp maybe_critic_opts(state, game_state, port, opts) do
    critic = state.critic
    k = state.critic_k
    # INVARIANTS.md item 5: the other OCCUPIED port, not a 1<->2 flip
    opp = ExPhil.Bridge.GameState.opponent_port(game_state, port)
    raw = ExPhil.Agents.CriticSelector.raw_features(game_state, port, opp)

    embed_opts = [
      axis_buckets: Map.get(state.embed_config || %{}, :axis_buckets, 16),
      shoulder_buckets: Map.get(state.embed_config || %{}, :shoulder_buckets, 4)
    ]

    select_fn = fn features, buttons, mx, my, cx, cy, sh ->
      ExPhil.Agents.CriticSelector.pick(
        critic,
        features,
        raw,
        {buttons, mx, my, cx, cy, sh},
        k,
        embed_opts
      )
    end

    opts |> Keyword.put(:select_n, k) |> Keyword.put(:select_fn, select_fn)
  end

  defp compute_temporal_action(state, embedded, opts) do
    # Add new frame to buffer
    buffer = :queue.in(embedded, state.frame_buffer)

    # Trim buffer if it exceeds window size
    {buffer, _dropped} = trim_buffer(buffer, state.window_size)

    # Get number of frames we have
    buffer_len = :queue.len(buffer)

    # Build sequence tensor
    sequence =
      if buffer_len < state.window_size do
        # Pad with first frame until we have enough
        # This allows inference to start immediately (warmup period)
        pad_sequence(buffer, state.window_size)
      else
        # Full window available
        buffer_to_tensor(buffer)
      end

    # Reshape to [1, window_size, embed_size]
    embed_size = Nx.size(embedded)
    sequence_batch = Nx.reshape(sequence, {1, state.window_size, embed_size})

    # ONE decode builder for every path (INVARIANTS.md item 7)
    sample_opts = ExPhil.Agents.Decode.sample_opts(state, opts)

    action =
      if state.head == :autoregressive do
        # predict_fn is the TRUNK fn for AR checkpoints (features out);
        # the head is replayed sequentially from the ar_* params.
        Networks.Policy.sample_autoregressive(
          state.policy_params,
          state.predict_fn,
          sequence_batch,
          sample_opts
        )
      else
        Networks.Policy.sample(state.policy_params, state.predict_fn, sequence_batch, sample_opts)
      end

    # Compute confidence from logits
    confidence = Networks.Policy.compute_confidence(action)

    # Update state with new buffer
    new_state = %{state | frame_buffer: buffer}

    {action, confidence, new_state}
  end

  # Edifice.Stateful step-path inference (O(1) per frame) for GRU/LSTM.
  #
  # The windowed path re-runs the whole 60-frame window every frame — O(window)
  # work for O(1) new information. Here we advance the recurrent trunk state
  # with just the current frame via Edifice.Recurrent.step/3 (JIT-compiled and
  # cached by Edifice.Stateful.jit_step), then run the six controller heads on
  # the resulting [1, hidden] features through a heads-only Axon subgraph that
  # shares layer names with the full policy, so the SAME exported params are
  # used unchanged. Sampling goes through the standard Sampling module, so all
  # knobs (deterministic, temperature, hysteresis, deterministic_buttons)
  # behave identically to the windowed path.
  #
  # Equivalence with the windowed forward is pinned by
  # test/exphil/networks/stateful_step_equivalence_test.exs.
  defp compute_stateful_step_action(state, embedded, opts) do
    # Current frame only: [1, embed_size]
    frame = Nx.reshape(embedded, {1, Nx.size(embedded)})

    # Cold-start warmup: the windowed path pads its buffer with copies of
    # the FIRST frame, so the trunk always sees a saturated window — a
    # regime the policy was trained in. A cold hidden state is
    # off-distribution and caused an opening-SD pathology in live probes
    # (stock lost at frame ~120 in every cold-start game). Replicate the
    # pad semantics: step the first frame window_size-1 extra times, once
    # per game (~13 ms total on the 5090 for window 60).
    # BPTT instead starts from zero carry and consumes each input once.
    trunk_state =
      if state.trunk_cold and not (state.bptt == true) do
        Enum.reduce(1..max(state.window_size - 1, 0)//1, state.trunk_state, fn _, st ->
          {_out, st} = trunk_step_fn().(state.trunk_step_params, st, frame)
          st
        end)
      else
        state.trunk_state
      end

    # Hybrid re-sync: rebuild the state as-if sliding-window (fresh init,
    # stepped through the buffered previous window_size-1 frames) every
    # :stateful_resync frames. Bounds carried-state drift to K frames;
    # costs window_size-1 extra steps every K (amortized ~nothing at
    # K >= 30). Buffer holds PREVIOUS frames newest-first; the current
    # frame is stepped normally below either way.
    buffer = Enum.take([frame | state.step_frame_buffer], max(state.window_size - 1, 1))

    resync? =
      state.stateful_resync != nil and not state.trunk_cold and
        state.steps_since_resync >= state.stateful_resync and
        length(state.step_frame_buffer) >= state.window_size - 1

    trunk_state =
      if resync? do
        fresh = init_trunk_state(state.trunk_step_params, state.embed_config, state.backbone)

        state.step_frame_buffer
        |> Enum.reverse()
        |> Enum.reduce(fresh, fn f, st ->
          {_out, st} = trunk_step_fn().(state.trunk_step_params, st, f)
          st
        end)
      else
        trunk_state
      end

    {features, new_trunk_state} =
      trunk_step_fn().(state.trunk_step_params, trunk_state, frame)

    # Steering hook (same seam as the windowed path's steer_project layer):
    # project alpha of the features' component along the steering direction
    # out BEFORE the heads. Tiny eager op on [1, hidden]; steer_v is
    # device-resident (copied at load).
    features =
      if state.steer_v do
        ExPhil.Interp.Steering.steer(features, state.steer_v, state.steer_alpha || 1.0)
      else
        features
      end

    # ONE decode builder for every path (INVARIANTS.md item 7)
    step_sample_opts = ExPhil.Agents.Decode.sample_opts(state, opts)

    action =
      if state.head == :autoregressive do
        Networks.Policy.sample_autoregressive_from_features(
          state.policy_params,
          features,
          step_sample_opts
        )
      else
        Networks.Policy.sample(
          state.policy_params,
          state.heads_predict_fn,
          features,
          step_sample_opts
        )
      end

    confidence = Networks.Policy.compute_confidence(action)

    {action, confidence,
     %{
       state
       | trunk_state: new_trunk_state,
         trunk_cold: false,
         step_frame_buffer: buffer,
         steps_since_resync: if(resync?, do: 0, else: state.steps_since_resync + 1)
     }}
  end

  # JIT-compiled Edifice.Recurrent.step/3 — cached in :persistent_term by
  # Edifice.Stateful.jit_step (same hygiene as Sampling.jitted/2). Falls back
  # to the eager step when EXLA isn't loaded (e.g. BinaryBackend tests).
  defp trunk_step_fn do
    if Code.ensure_loaded?(EXLA) do
      Edifice.Stateful.jit_step(
        Edifice.Recurrent,
        EXLA,
        xla_exec_cache("trunk_step", Edifice.Recurrent)
      )
    else
      &Edifice.Recurrent.step/3
    end
  end

  # Persistent XLA executable cache (JIT_WARMUP.md step 1) — see
  # ExPhil.Training.Utils.xla_exec_cache/2.
  defp xla_exec_cache(name, key_parts), do: Utils.xla_exec_cache(name, key_parts)

  # The trunk-only param subset for Edifice.Recurrent.step/init_state:
  # "input_ln" plus every "gru_*"/"lstm_*" layer (covers both the Axon layout
  # — gru_1, gru_1_ln, gru_1_h_hidden_state — and the fused-kernel layout —
  # gru_1_input_proj, gru_1_fused_scan). Passing only the trunk subset keeps
  # the head params out of the JIT trace.
  defp trunk_step_params(params, cell_type) do
    prefix = "#{cell_type}_"

    params
    |> raw_policy_params()
    |> Map.filter(fn {k, _v} ->
      is_binary(k) and (k == "input_ln" or String.starts_with?(k, prefix))
    end)
  end

  # Initial trunk state for the step path (see Edifice.Recurrent.init_state/2:
  # for the Axon layout this replicates Axon's key-derived initial hidden
  # state, NOT zeros — required for step/window equivalence from frame 1).
  defp validate_embed_canary!(config, full_embed_config) do
    case Map.get(config, :embed_canary) do
      stored when is_list(stored) ->
        default = ExPhil.Embeddings.Game.Config.default()

        live_config = %{
          default
          | queue_depth: Map.get(full_embed_config, :queue_depth) || 1,
            with_delay_id: Map.get(full_embed_config, :with_delay_id) || false,
            stage_internals: Map.get(full_embed_config, :stage_internals) || false,
            with_projectiles: Map.get(full_embed_config, :with_projectiles, true),
            player: %{
              default.player
              | action_frame_buckets: Map.get(full_embed_config, :action_frame_buckets) || 0
            }
        }

        live = ExPhil.Embeddings.Canary.fingerprint_live(live_config)

        case ExPhil.Embeddings.Canary.compare(stored, live) do
          :ok ->
            :ok

          {:error, report} ->
            raise ArgumentError, """
            EMBEDDING FINGERPRINT MISMATCH: the live embedding path diverges from \
            what this checkpoint was trained with — the policy would play on \
            scrambled or wrong-space features (the base-block-reversal / \
            stage-as-"other" bug class). Report: #{inspect(report)}. \
            If the embedding code changed intentionally since this checkpoint \
            was saved, retrain or re-export it.
            """
        end

      _ ->
        # Pre-canary checkpoint — nothing to check.
        :ok
    end
  end

  # Known trained set for the g15/g19 champion line (multi-delay {2,3}
  # recipe; 0 = the unconditioned local case) — the fallback when an
  # older checkpoint predates the :train_delays metadata key.
  @champion_line_train_delays [0, 2, 3]

  @doc """
  Pure guard decision (unit-tested): is deploying at `delay_id` an
  untrained-id violation? `train_delays` nil falls back to the champion
  line's known set #{inspect(@champion_line_train_delays)}.
  """
  def untrained_delay_id?(delay_id, train_delays, with_delay_id?, allow?) do
    with_delay_id? and not allow? and
      delay_id not in (train_delays || @champion_line_train_delays)
  end

  defp validate_delay_id!(state, config, full_embed_config) do
    trained = Map.get(config, :train_delays)

    if untrained_delay_id?(
         state.delay_id,
         trained,
         Map.get(full_embed_config, :with_delay_id, false),
         state.allow_untrained_delay_id || false
       ) do
      raise ArgumentError, """
      delay_id #{state.delay_id} is UNTRAINED for this delay-conditioned policy \
      (trained: #{inspect(trained || @champion_line_train_delays)}). Bare --frame-delay N \
      silently sets delay_id=N — that collapsed chaining for three netplay games on \
      2026-08-24. Netplay d4 deploys want --delay-id-override 3 \
      (docs/guides/DEPLOY_KNOBS.md); an explicit --delay-id-override also bypasses \
      this guard.
      """
    end

    :ok
  end

  defp init_trunk_state(trunk_params, embed_config, cell_type) do
    Edifice.Recurrent.init_state(trunk_params,
      batch_size: 1,
      hidden_size: embed_config[:hidden_size] || 256,
      num_layers: embed_config[:num_layers] || 2,
      cell_type: cell_type
    )
  end

  # Incremental GatedSSM inference with state caching (O(1) per frame)
  # This is 60x faster than compute_temporal_action for window_size=60
  defp compute_incremental_mamba_action(state, embedded, opts) do
    alias ExPhil.Networks.GatedSSM

    # This path indexes the raw params map directly (predict_fn is bypassed),
    # so unwrap %Axon.ModelState{} exports to their data map.
    params = raw_policy_params(state.policy_params)

    # Project embedding to hidden size (matching what the model does)
    # embedded: [embed_size] -> need [1, embed_size] for batch
    hidden_size = state.embed_config[:hidden_size] || 256
    embed_size = Nx.size(embedded)

    # Reshape to batch: [1, embed_size]
    x = Nx.reshape(embedded, {1, embed_size})

    # Project to hidden_size if needed (input projection layer)
    x =
      if embed_size != hidden_size do
        input_proj =
          params["input_projection"] ||
            params[:input_projection]

        if input_proj do
          kernel = input_proj["kernel"] || input_proj[:kernel]
          bias = input_proj["bias"] || input_proj[:bias]
          out = Nx.dot(x, kernel)
          if bias, do: Nx.add(out, bias), else: out
        else
          # No projection params found, pad or truncate
          if embed_size < hidden_size do
            Nx.pad(x, 0.0, [{0, 0, 0}, {0, hidden_size - embed_size, 0}])
          else
            Nx.slice_along_axis(x, 0, hidden_size, axis: 1)
          end
        end
      else
        x
      end

    # Single step through GatedSSM with cached state
    {backbone_output, new_cache} =
      GatedSSM.step(
        x,
        params,
        state.mamba_cache
      )

    # backbone_output: [1, hidden_size]
    # Now run through policy heads (dense layers after backbone). Decode
    # opts come from the SAME builder as the other two paths (INVARIANTS.md
    # item 7) — this path used to pass only deterministic + temperature,
    # silently dropping mode-of-N / critic selector / hysteresis.
    action =
      sample_from_backbone_output(
        backbone_output,
        params,
        ExPhil.Agents.Decode.sample_opts(state, opts) ++
          [
            axis_buckets: state.embed_config[:axis_buckets] || 16,
            shoulder_buckets: state.embed_config[:shoulder_buckets] || 4
          ]
      )

    confidence = Networks.Policy.compute_confidence(action)

    new_state = %{state | mamba_cache: new_cache}

    {action, confidence, new_state}
  end

  defp raw_policy_params(%Axon.ModelState{data: data}), do: data
  defp raw_policy_params(params), do: params

  # Move all param tensors to the default backend (EXLA device when
  # available). Checkpoint-loaded tensors live on Nx.BinaryBackend and would
  # otherwise be re-transferred host->device on EVERY inference call.
  defp copy_params_to_default_backend(%Axon.ModelState{} = ms) do
    %{ms | data: Nx.backend_copy(ms.data, Nx.default_backend())}
  end

  defp copy_params_to_default_backend(params) do
    Nx.backend_copy(params, Nx.default_backend())
  end

  # Sample action from backbone output (run through policy heads)
  defp sample_from_backbone_output(backbone_output, params, opts) do
    deterministic = Keyword.get(opts, :deterministic, false)
    temperature = Keyword.get(opts, :temperature, 1.0)
    axis_buckets = Keyword.get(opts, :axis_buckets, 16)
    shoulder_buckets = Keyword.get(opts, :shoulder_buckets, 4)

    # Get policy head parameters
    # These are the final dense layers that produce logits
    buttons_logits = dense_head(backbone_output, params, "buttons_head")
    main_x_logits = dense_head(backbone_output, params, "main_x_head")
    main_y_logits = dense_head(backbone_output, params, "main_y_head")
    c_x_logits = dense_head(backbone_output, params, "c_x_head")
    c_y_logits = dense_head(backbone_output, params, "c_y_head")
    shoulder_logits = dense_head(backbone_output, params, "shoulder_head")

    # Sample from each head
    buttons = sample_buttons(buttons_logits, deterministic, temperature)
    main_x = sample_categorical(main_x_logits, axis_buckets, deterministic, temperature)
    main_y = sample_categorical(main_y_logits, axis_buckets, deterministic, temperature)
    c_x = sample_categorical(c_x_logits, axis_buckets, deterministic, temperature)
    c_y = sample_categorical(c_y_logits, axis_buckets, deterministic, temperature)
    shoulder = sample_categorical(shoulder_logits, shoulder_buckets, deterministic, temperature)

    %{
      buttons: buttons,
      main_x: main_x,
      main_y: main_y,
      c_x: c_x,
      c_y: c_y,
      shoulder: shoulder,
      # Include logits for confidence computation
      buttons_logits: buttons_logits,
      main_x_logits: main_x_logits,
      main_y_logits: main_y_logits,
      c_x_logits: c_x_logits,
      c_y_logits: c_y_logits,
      shoulder_logits: shoulder_logits
    }
  end

  defp dense_head(x, params, head_name) do
    head_params = params[head_name] || params[String.to_atom(head_name)] || %{}
    kernel = head_params["kernel"] || head_params[:kernel]

    if kernel do
      bias = head_params["bias"] || head_params[:bias]
      out = Nx.dot(x, kernel)
      if bias, do: Nx.add(out, bias), else: out
    else
      # Fallback: head not found, return zeros (will produce uniform sampling)
      Logger.warning("[Agent] Policy head #{head_name} not found in params")
      # Default 8 outputs
      Nx.broadcast(0.0, {1, 8})
    end
  end

  defp sample_buttons(logits, deterministic, temperature) do
    # Buttons are independent Bernoulli (8 buttons)
    probs = Nx.sigmoid(Nx.divide(logits, temperature))

    if deterministic do
      Nx.greater(probs, 0.5) |> Nx.squeeze()
    else
      key = Nx.Random.key(System.system_time(:nanosecond))
      {rand, _} = Nx.Random.uniform(key, shape: Nx.shape(probs))
      Nx.greater(probs, rand) |> Nx.squeeze()
    end
  end

  defp sample_categorical(logits, _num_categories, deterministic, temperature) do
    # Apply temperature and sample
    scaled_logits = Nx.divide(logits, temperature)

    if deterministic do
      Nx.argmax(scaled_logits, axis: -1) |> Nx.squeeze()
    else
      # Gumbel-max trick for sampling
      key = Nx.Random.key(System.system_time(:nanosecond))
      {rand, _} = Nx.Random.uniform(key, shape: Nx.shape(scaled_logits))
      gumbel = Nx.negate(Nx.log(Nx.negate(Nx.log(Nx.add(rand, 1.0e-10)))))
      Nx.argmax(Nx.add(scaled_logits, gumbel), axis: -1) |> Nx.squeeze()
    end
  end

  # Initialize GatedSSM cache from state config
  defp init_mamba_cache(state) do
    alias ExPhil.Networks.GatedSSM

    hidden_size = state.embed_config[:hidden_size] || 256
    num_layers = state.embed_config[:num_layers] || 2

    GatedSSM.init_cache(
      batch_size: 1,
      hidden_size: hidden_size,
      num_layers: num_layers
    )
  end

  # Trim buffer to max size, dropping oldest frames
  defp trim_buffer(buffer, max_size) do
    len = :queue.len(buffer)

    if len > max_size do
      # Drop oldest frames
      to_drop = len - max_size

      {_dropped, trimmed} =
        Enum.reduce(1..to_drop, {[], buffer}, fn _, {dropped, buf} ->
          {{:value, frame}, new_buf} = :queue.out(buf)
          {[frame | dropped], new_buf}
        end)

      {trimmed, to_drop}
    else
      {buffer, 0}
    end
  end

  # Convert buffer queue to stacked tensor [seq_len, embed_size]
  defp buffer_to_tensor(buffer) do
    buffer
    |> :queue.to_list()
    |> Nx.stack()
  end

  # Pad sequence by repeating first frame
  defp pad_sequence(buffer, target_size) do
    frames = :queue.to_list(buffer)
    current_len = length(frames)

    if current_len == 0 do
      # No frames yet - this shouldn't happen but handle gracefully
      raise "Cannot pad empty buffer"
    end

    # Repeat first frame to pad the beginning
    first_frame = hd(frames)
    padding_count = target_size - current_len
    padded_frames = List.duplicate(first_frame, padding_count) ++ frames

    Nx.stack(padded_frames)
  end

  defp embed_game_state(game_state, player_port, state) do
    # Use default Game config for embedding
    # The embed_config we store is just for axis_buckets/shoulder_buckets, not the full Game struct
    #
    # Prev-action channel: policies trained with --prev-action get the
    # agent's own last emitted controller (matching training, where frame i
    # sees frame i-1's controller); older policies trained on a zeroed slot
    # get nil → zeros. Mixing regimes scrambles the input — the config flag
    # decides, not the caller.
    prev_controller = if state.use_prev_action, do: state.last_controller, else: nil
    opts = [name_id: state.style_id || 0]

    # af_convention: :live normalizes the bridge's action_frame into the
    # PARSED convention every checkpoint was trained on (GOTCHAS #81).
    # Default :parsed is an exact no-op, so this cannot perturb existing
    # behavior unless asked for.
    opts =
      if state.af_convention in [:live, :libmelee],
        do: [{:config, live_af_embed_config(state.af_convention)} | opts],
        else: opts

    # Queue-as-input: policies trained with queue_depth > 1 / with_delay_id
    # get a config override + their own ring buffer. The config the policy
    # trained with is authoritative (state.embed_config carries it).
    depth = queue_depth(state)
    delay_id? = Map.get(state.embed_config || %{}, :with_delay_id) || false
    stage_internals? = Map.get(state.embed_config || %{}, :stage_internals) || false
    # INVARIANTS.md item 4: the checkpoint says whether its embedding HAS a
    # projectile block; new checkpoints trained from Peppi say false and
    # the live embedder then has no projectile dims at all.
    proj? = Map.get(state.embed_config || %{}, :with_projectiles, true)
    # Bucketized action frame (player-level layout key, 2026-09-09)
    afb = Map.get(state.embed_config || %{}, :action_frame_buckets) || 0

    opts =
      if depth > 1 or delay_id? or stage_internals? or not proj? or afb > 0 do
        base = Keyword.get(opts, :config, ExPhil.Embeddings.Game.Config.default())

        cfg = %{
          base
          | queue_depth: depth,
            with_delay_id: delay_id?,
            stage_internals: stage_internals?,
            with_projectiles: proj?,
            player: %{base.player | action_frame_buckets: afb}
        }

        opts
        |> Keyword.put(:config, cfg)
        |> Keyword.put(:queue_controllers, state.controller_queue || [])
        |> Keyword.put(:delay_id, state.delay_id || 0)
      else
        opts
      end

    # EXPHIL_ZERO_PROJECTILES=1 (2026-09-08 A/B, FIXES.md P0): replay-trained
    # checkpoints saw a constant-ZERO projectile block (Peppi hardcodes
    # projectiles: []) while the live bridge populates real projectiles —
    # an off-distribution input on every frame that the embedding canary
    # cannot catch (layout matches, values don't). This zeroes the block at
    # the live boundary so the policy sees what it trained on. Opt-in env
    # so the A/B is explicit; if it wins, make it the default for
    # replay-trained configs.
    game_state =
      if zero_projectiles?(state.embed_config) do
        unless Process.get(:zero_projectiles_logged) do
          Process.put(:zero_projectiles_logged, true)

          Logger.warning(
            "[Agent] projectile block ZEROED at the live boundary: this checkpoint's " <>
              "embedding has projectile dims but its training source never provided " <>
              "projectiles (INVARIANTS item 4; EXPHIL_ZERO_PROJECTILES=0 forces populate)"
          )
        end

        %{game_state | projectiles: []}
      else
        game_state
      end

    Embeddings.Game.embed(game_state, prev_controller, player_port, opts)
  end

  @doc """
  INVARIANTS.md item 4 — should live projectiles be zeroed before embedding?
  Pure, so it is unit-tested. Rules, in order:
    * `EXPHIL_ZERO_PROJECTILES=1` forces zero, `=0` forces populate (A/B);
    * a checkpoint whose embedding has NO projectile block: nothing to zero;
    * a checkpoint whose training source is stamped as providing
      projectiles: populate;
    * otherwise (old replay-trained checkpoints, no stamp; or a stamp that
      lacks :projectiles): the block was constant-zero in training — zero it.
  """
  @spec zero_projectiles?(map() | nil, String.t() | nil) :: boolean()
  def zero_projectiles?(embed_config, env \\ System.get_env("EXPHIL_ZERO_PROJECTILES")) do
    ec = embed_config || %{}

    case env do
      "1" ->
        true

      "0" ->
        false

      _ ->
        has_block? = truthy?(Map.get(ec, :with_projectiles, true))
        provided = Map.get(ec, :provided_channels) || []
        provided? = Enum.any?(provided, &(to_string(&1) == "projectiles"))
        has_block? and not provided?
    end
  end

  defp truthy?(v), do: v in [true, "true"]

  # Under Slippi Online the bridge detects the bot's actual in-game port
  # via connect codes (GameState.own_port); offline it is nil and the
  # configured --port applies.
  defp effective_port(%{own_port: own_port}, _opts) when is_integer(own_port), do: own_port
  defp effective_port(_game_state, opts), do: Keyword.get(opts, :player_port, 1)

  @doc """
  Advance the queue-as-input ring buffer by one DECISION while keeping the
  training-parity invariant: slot k == the input the game applied k frames
  ago.

    * game reset (frame counter went backwards, new game): fresh ring —
      old-game actions must not leak across the boundary
    * frame_delta 0 (re-inference on the same game frame): REPLACE the
      head — the game applies only the last input sent for a frame
    * frame_delta d >= 1: push the new head; the previous head was HELD by
      the game through the d-1 undecided frames, so copies of it fill the
      gap slots

  Public for tests; runtime callers live in do_compute_action/3.
  """
  def update_controller_queue(queue, controller, frame_delta, game_reset?, depth) do
    cond do
      game_reset? or queue == [] ->
        [controller]

      frame_delta <= 0 ->
        Enum.take([controller | tl(queue)], depth)

      true ->
        held = List.duplicate(hd(queue), min(frame_delta - 1, depth))
        Enum.take([controller | held ++ queue], depth)
    end
  end

  defp queue_depth(state) do
    Map.get(state.embed_config || %{}, :queue_depth) || 1
  end

  defp live_af_embed_config(convention) do
    config = ExPhil.Embeddings.Game.Config.default()
    %{config | player: %{config.player | af_convention: convention}}
  end

  # Uncertainty logging (flywheel A4). Confidence is computed by sampling
  # regardless; when :uncertainty_log is set, buffer one compact entry per
  # frame and append-flush as JSONL every @uncertainty_flush frames (and on
  # terminate). One file line = %{"f" =>, "overall" =>, "buttons" =>,
  # "main" =>, "c" =>, "shoulder" =>}.
  @uncertainty_flush 600

  defp log_uncertainty(%{uncertainty_log: nil} = state, _gs, _conf), do: state

  defp log_uncertainty(state, game_state, conf) when is_map(conf) do
    entry = %{
      "f" => game_state.frame,
      "overall" => conf[:overall],
      "buttons" => conf[:buttons],
      "main" => conf[:main],
      "c" => conf[:c],
      "shoulder" => conf[:shoulder]
    }

    buf = [entry | state.uncertainty_buf]

    if length(buf) >= @uncertainty_flush do
      flush_uncertainty(%{state | uncertainty_buf: buf})
    else
      %{state | uncertainty_buf: buf}
    end
  end

  defp log_uncertainty(state, _gs, _conf), do: state

  defp flush_uncertainty(%{uncertainty_log: nil} = state), do: state
  defp flush_uncertainty(%{uncertainty_buf: []} = state), do: state

  defp flush_uncertainty(state) do
    lines =
      state.uncertainty_buf
      |> Enum.reverse()
      |> Enum.map_join("", fn e -> Jason.encode!(e) <> "\n" end)

    File.mkdir_p!(Path.dirname(state.uncertainty_log))
    File.write!(state.uncertainty_log, lines, [:append])
    %{state | uncertainty_buf: []}
  rescue
    e ->
      Logger.warning("[agent] uncertainty flush failed: #{Exception.message(e)}")
      %{state | uncertainty_buf: []}
  end

  defp action_to_controller(action, state) do
    Networks.to_controller_state(action, axis_buckets: state.embed_config[:axis_buckets] || 16)
  end

  defp load_policy_internal(state, path) when is_binary(path) do
    case Training.load_policy(path) do
      {:ok, policy} -> load_policy_internal(state, policy)
      error -> error
    end
  end

  defp load_policy_internal(state, %{params: params, config: config} = _policy) do
    execution =
      ExPhil.Networks.Policy.ExecutionContract.validate_inference!(config, state.stateful_step)

    if config[:bptt] == true and (state.stateful_resync != nil or is_binary(state.leace_eraser)),
      do: raise(ArgumentError, "BPTT stateful inference cannot use window resync or a LEACE eraser")

    # Extract config
    embed_config = Map.get(config, :embed_config, %{})
    # The canary's length IS the true input width (it's the embedded
    # canonical state) — prefer it over the scalar, which can be stale
    # (0825: a 288 default rode along in a 296-layout checkpoint and
    # the model built at the wrong width, dying at warmup).
    embed_size =
      case Map.get(config, :embed_canary) do
        canary when is_list(canary) and canary != [] -> length(canary)
        _ -> Map.get(config, :embed_size) || Map.get(embed_config, :embed_size, 1991)
      end
    axis_buckets = Map.get(config, :axis_buckets, 16)
    shoulder_buckets = Map.get(config, :shoulder_buckets, 4)

    # Temporal config
    temporal = Map.get(config, :temporal, false)
    backbone = Map.get(config, :backbone, :mlp)
    window_size = Map.get(config, :window_size, 60)

    # Controller head (AUTOREGRESSIVE_HEAD_PLAN): JSON round-trips turn the
    # atom into a string — accept both. :autoregressive means the checkpoint
    # has ar_* head params and sampling must run sequentially.
    head =
      case Map.get(config, :head, :independent) do
        h when h in [:independent, :autoregressive] -> h
        "independent" -> :independent
        "autoregressive" -> :autoregressive
        other -> raise ArgumentError, "unknown checkpoint head: #{inspect(other)}"
      end

    if head == :autoregressive do
      unless temporal do
        raise ArgumentError,
              "head: :autoregressive checkpoints require a temporal policy (no trunk seam in the MLP path)"
      end

      # warning level: the eval protocols run at Logger :warning (quiet) and
      # their knob assertions grep the run log for this banner
      Logger.warning("[Agent] Autoregressive controller head ACTIVE (sequential per-frame sampling)")
    end

    # MLP backbone config
    hidden_sizes = Map.get(config, :hidden_sizes, [512, 512])
    dropout = Map.get(config, :dropout, 0.1)

    # Build appropriate model based on temporal flag
    # Note: dropout is included to match training architecture, but Axon
    # disables dropout during inference mode by default
    # SSM-family shape params: omitting these rebuilt mamba/SSM exports
    # with DEFAULT shapes at inference — a silent architecture mismatch
    # (exports carry them since the backbone_defaults integration; GRU
    # ignores them harmlessly)
    trunk_opts = [
      # BPTT actually executes through Edifice.Stateful below. The companion
      # window graph must not introduce a random initial-state parameter.
      recurrent_state:
        if(execution.recurrent_state == :carried_zero,
          do: :zeros,
          else: execution.recurrent_state
        ),
      embed_size: embed_size,
      backbone: backbone,
      window_size: window_size,
      num_heads: Map.get(config, :num_heads, 4),
      head_dim: Map.get(config, :head_dim, 64),
      hidden_size: Map.get(config, :hidden_size, 256),
      num_layers: Map.get(config, :num_layers, 2),
      state_size: Map.get(config, :state_size, 16),
      expand_factor: Map.get(config, :expand_factor, 2),
      conv_size: Map.get(config, :conv_size, 4),
      dropout: dropout
    ]

    # Steering-vector hook (Tier-0 shield-lock A/B): load %{v: unit tensor}
    # once here; the windowed path gets it as an Axon.nx layer below, the
    # stateful step path applies it to the step features directly (see
    # compute_stateful_step_action) — same {hidden} feature space.
    steering =
      if is_binary(state.steer_vector) do
        s = ExPhil.Interp.Steering.load!(state.steer_vector)
        alpha = state.steer_alpha || 1.0

        Logger.warning(
          "[Agent] STEERING ACTIVE: #{state.steer_vector} " <>
            "(alpha=#{alpha}, dim #{Nx.size(s.v)})"
        )

        unless temporal do
          Logger.warning(
            "[Agent] --steer-vector only applies to temporal policies — ignored"
          )
        end

        %{v: s.v, alpha: alpha}
      else
        nil
      end

    model =
      cond do
        temporal and (is_binary(state.leace_eraser) or steering != nil) ->
          # Interp-surgical inference (P3/P6 + steering): frozen feature
          # transformations between trunk and heads — leave all layer names
          # intact so exported params load as-is.
          trunk = Networks.Policy.build_temporal_trunk(trunk_opts)

          trunk =
            if is_binary(state.leace_eraser) do
              # Fitted LEACE eraser: removes the concept subspace (e.g. the
              # prev-button copy signal).
              eraser = state.leace_eraser |> File.read!() |> :erlang.binary_to_term()

              Logger.warning(
                "[Agent] LEACE ERASER ACTIVE: #{state.leace_eraser} (rank #{eraser.rank})"
              )

              mu = eraser.mu
              at = Nx.transpose(eraser.a)

              Axon.nx(
                trunk,
                fn x ->
                  mu_c = Nx.as_type(mu, Nx.type(x))
                  at_c = Nx.as_type(at, Nx.type(x))
                  Nx.subtract(x, Nx.dot(Nx.subtract(x, mu_c), at_c))
                end,
                name: "leace_erase"
              )
            else
              trunk
            end

          trunk =
            if steering do
              %{v: v, alpha: alpha} = steering

              Axon.nx(
                trunk,
                fn x -> ExPhil.Interp.Steering.steer(x, v, alpha) end,
                name: "steer_project"
              )
            else
              trunk
            end

          # AR head: the sampler replays the head from params — the model
          # here stays the (possibly erased/steered) trunk, features out.
          if head == :autoregressive do
            trunk
          else
            Networks.Policy.Heads.build_controller_head(trunk, axis_buckets, shoulder_buckets)
          end

        temporal and head == :autoregressive ->
          Logger.info(
            "[Agent] Loading temporal policy TRUNK (backbone: #{backbone}, window: #{window_size}, AR head)"
          )

          # Trunk only: predict_fn -> [batch, hidden] features; the AR head
          # runs inside Policy.sample_autoregressive from the ar_* params.
          Networks.Policy.build_temporal_trunk(trunk_opts)

        temporal ->
          Logger.info(
            "[Agent] Loading temporal policy (backbone: #{backbone}, window: #{window_size})"
          )

          Networks.Policy.build_temporal(
            trunk_opts ++ [axis_buckets: axis_buckets, shoulder_buckets: shoulder_buckets]
          )

        true ->
          Networks.Policy.build(
            embed_size: embed_size,
            hidden_sizes: hidden_sizes,
            dropout: dropout,
            axis_buckets: axis_buckets,
            shoulder_buckets: shoulder_buckets
          )
      end

    {_init_fn, predict_fn} =
      Utils.build_compiled(
        model,
        xla_exec_cache(
          "predict",
          {backbone, embed_size, hidden_sizes, axis_buckets, shoulder_buckets, window_size}
        )
      )

    # Build embed_config with all needed fields
    full_embed_config =
      Map.merge(
        %{
          embed_size: embed_size,
          axis_buckets: axis_buckets,
          shoulder_buckets: shoulder_buckets,
          hidden_size: Map.get(config, :hidden_size, 256),
          num_layers: Map.get(config, :num_layers, 2),
          # Queue-as-input layout: flat keys on the exported config (the
          # embed_config map is a legacy flattened map that dropped them)
          queue_depth: Map.get(config, :queue_depth, 1),
          with_delay_id: Map.get(config, :with_delay_id, false),
          stage_internals: Map.get(config, :stage_internals, false),
          # Bucketized action frame (0 = the historical scalar-only layout)
          action_frame_buckets: Map.get(config, :action_frame_buckets, 0) || 0,
          # INVARIANTS.md item 4: old checkpoints (no stamp) trained with a
          # projectile block that was constant-zero; new ones say whether
          # the block exists and which channels the source provided.
          with_projectiles: truthy?(Map.get(config, :with_projectiles, true)),
          provided_channels: Map.get(config, :provided_channels)
        },
        embed_config
      )

    # Embedding fingerprint guard (GUARDS_BACKLOG #1): re-embed the
    # canary through the LIVE path with the reconstructed config and
    # compare against the save-time batched fingerprint. Divergence =
    # the policy would play on scrambled/wrong-space features — refuse.
    validate_embed_canary!(config, full_embed_config)

    # Untrained delay-id guard (2026-08-24 crown-decider lesson): a
    # delay-conditioned policy deployed at an id it never trained on
    # silently collapses behavior (bare --frame-delay 4 ran id4 —
    # untrained — for three netplay games). Newer checkpoints carry
    # :train_delays; older ones fall back to the champion line's known
    # set. `allow_untrained_delay_id: true` (set by an EXPLICIT
    # --delay-id-override) is the escape hatch.
    #
    # INVARIANTS.md item 1: the id is in the CHECKPOINT'S numbering. With
    # no explicit id, derive it from the live frame_delay through the
    # checkpoint's label convention (legacy: id N; causal: id N-1), so a
    # causal checkpoint deployed at its trained rung never trips the
    # guard and never runs an off-by-one id.
    alias ExPhil.Data.LabelConvention
    alias ExPhil.Eval.HarnessRung
    harness = state.harness || :async_runner
    knob = state.harness_knob || state.frame_delay || 0
    {id_offset, _} = HarnessRung.delay_id_reaction_offset(config)
    delay_conditioned? = Map.get(full_embed_config, :with_delay_id, false)

    # The physical reaction delay this agent plays at: given directly (THE
    # knob), else what the declared harness plays at its knob.
    played = state.reaction_delay || HarnessRung.reaction_delay(harness, knob)
    derived = HarnessRung.delay_id_for_reaction(played, config)

    describe =
      if state.reaction_delay,
        do: "reaction delay #{played} -> delay-id #{derived} (id reaction offset #{id_offset})",
        else: HarnessRung.describe(harness, knob, config)

    state =
      case state.delay_id do
        nil ->
          Logger.info("[Agent] delay_id #{derived} derived: #{describe}")
          %{state | delay_id: derived, delay_id_reaction_offset: id_offset, reaction_delay: played}

        explicit ->
          if delay_conditioned? and explicit != derived do
            Logger.warning(
              "[Agent] explicit delay_id #{explicit} but #{describe}; " <>
                "one frame FASTER than trained breaks tight loops, one slower degrades (GOTCHA #115)"
            )
          end

          %{state | delay_id_reaction_offset: id_offset, reaction_delay: played}
      end

    validate_delay_id!(state, config, full_embed_config)

    # GOTCHA #113: a legacy checkpoint trained at producing-delay 0 learned
    # leaked targets (state[t] already contains controller[t]) — it
    # continues states but cannot initiate them. Not fatal (it still
    # plays), but every live look of one must be read as leak-limited.
    if LabelConvention.leaky?(config) do
      Logger.warning(
        "[Agent] checkpoint trained on LEAKED labels (legacy delay 0, GOTCHA #113): " <>
          "expect reactive-but-never-initiating play (long WAIT dwell, no dash-outs, jab chains). " <>
          "Retrain (the parser now emits causal labels by construction)."
      )
    end

    # Non-conditioned checkpoints have ONE trained rung; say what this
    # harness actually plays it at (delay-conditioned ones are covered by
    # the id derivation + guard above).
    reaction = LabelConvention.reaction_delay(config)

    if not delay_conditioned? and played != reaction do
      aligned =
        case HarnessRung.deploy_knob(harness, config) do
          {:ok, k} -> "aligned knob #{k}"
          {:error, {:unreachable, min}} -> "unreachable on #{harness} (floor latency #{min}); knob 0 is the nearest, slower rung"
        end

      Logger.warning(
        "[Agent] #{harness} knob #{knob} plays reaction delay #{played}; this checkpoint " <>
          "trained at reaction delay #{reaction} (#{aligned}; INVARIANTS item 12)"
      )
    end

    # Initialize GatedSSM cache when using incremental inference.
    # :gated_ssm only — see compute_action dispatch; Mamba param names don't
    # match the hand-rolled GatedSSM.step extraction.
    mamba_cache =
      if temporal and backbone == :gated_ssm and state.use_incremental do
        Logger.info("[Agent] Initializing GatedSSM incremental inference cache")
        alias ExPhil.Networks.GatedSSM

        GatedSSM.init_cache(
          batch_size: 1,
          hidden_size: full_embed_config.hidden_size,
          num_layers: full_embed_config.num_layers
        )
      else
        nil
      end

    # Prev-action regime comes from the TRAINING config: policies trained
    # with --prev-action expect their own last controller in the embedding;
    # older policies expect zeros. Not caller-overridable — EXCEPT the
    # explicit :ablate_prev_action experiment flag (interp P3), which
    # deliberately feeds zeros to a prev-action policy to measure the
    # channel's causal contribution live.
    use_prev_action =
      if state.ablate_prev_action do
        Logger.warning("[Agent] ABLATION: prev-action channel forced to zeros (interp P3)")
        false
      else
        Map.get(config, :use_prev_action, false)
      end

    if use_prev_action do
      Logger.info("[Agent] Policy trained with prev-action conditioning — feeding own outputs back")
    end

    # Edifice.Stateful step path (opt-in via stateful_step / --stateful-step):
    # O(1) recurrent inference for GRU/LSTM temporal policies. Builds a
    # heads-only predict fn (same layer names as the full policy, so the
    # exported params slot in unchanged) plus the initial trunk state.
    {trunk_params, trunk_state, heads_predict_fn, params} =
      cond do
        not state.stateful_step ->
          {nil, nil, nil, params}

        not (temporal and backbone in [:gru, :lstm]) ->
          Logger.warning(
            "[Agent] stateful_step requested but backbone #{inspect(backbone)} " <>
              "doesn't support the Edifice.Stateful step path (GRU/LSTM only) — " <>
              "falling back to windowed inference"
          )

          {nil, nil, nil, params}

        is_binary(state.leace_eraser) ->
          Logger.warning(
            "[Agent] stateful_step is incompatible with --leace-eraser " <>
              "(eraser sits between trunk and heads in the full graph) — " <>
              "falling back to windowed inference"
          )

          {nil, nil, nil, params}

        true ->
          hidden_size = Map.get(config, :hidden_size, 256)

          Logger.info(
            "[Agent] Stateful step path ACTIVE (Edifice.Stateful, backbone: #{backbone}, " <>
              "O(1)/frame instead of O(#{window_size}))"
          )

          # Checkpoint tensors deserialize onto Nx.BinaryBackend; without
          # this copy every jitted step re-transfers all trunk weights
          # host->device (measured 12.4 ms/step vs 0.21 ms device-resident
          # on the 5090 for the r10 GRU). Copy once at load.
          params = copy_params_to_default_backend(params)

          # AR head: no heads-only Axon graph — the step path samples via
          # Policy.sample_autoregressive_from_features (state.head marks it;
          # heads_predict_fn stays nil).
          heads_predict_fn =
            if head == :autoregressive do
              nil
            else
              heads_input = Axon.input("features", shape: {nil, hidden_size})

              heads_model =
                Networks.Policy.Heads.build_controller_head(
                  heads_input,
                  axis_buckets,
                  shoulder_buckets
                )

              {_init_fn, fused_heads_fn} =
                Utils.build_compiled(
                  heads_model,
                  xla_exec_cache("heads", {hidden_size, axis_buckets, shoulder_buckets})
                )

              fused_heads_fn
            end

          trunk_params = trunk_step_params(params, backbone)

          trunk_state =
            init_trunk_state(
              trunk_params,
              %{
                hidden_size: hidden_size,
                num_layers: Map.get(config, :num_layers, 2)
              },
              backbone
            )

          {trunk_params, trunk_state, heads_predict_fn, params}
      end

    new_state = %{
      state
      | policy_params: params,
        predict_fn: predict_fn,
        embed_config: full_embed_config,
        # Retained for reconfigure-time delay-id revalidation (pool reuse)
        train_delays: Map.get(config, :train_delays),
        label_convention: LabelConvention.of(config),
        # Controller head dispatch (AR vs independent sampling)
        head: head,
        # Set temporal config
        temporal: temporal,
        bptt: config[:bptt] == true,
        backbone: backbone,
        window_size: window_size,
        use_prev_action: use_prev_action,
        last_controller: nil,
        controller_queue: [],
        # Reset frame buffer when loading new policy
        frame_buffer: :queue.new(),
        # Mamba cache for incremental inference
        mamba_cache: mamba_cache,
        # Edifice.Stateful step path (nil = windowed inference)
        trunk_step_params: trunk_params,
        trunk_state: trunk_state,
        heads_predict_fn: heads_predict_fn,
        trunk_cold: true,
        # Steering unit vector, copied to the default backend once at load —
        # the step path applies it eagerly every frame (host-resident copies
        # would re-transfer per frame; same rationale as
        # copy_params_to_default_backend above)
        steer_v: steering && Nx.backend_copy(steering.v, Nx.default_backend())
    }

    {:ok, new_state}
  end

  defp load_policy_internal(_state, invalid) do
    {:error, {:invalid_policy, invalid}}
  end

  defp maybe_update(state, key, opts) do
    if Keyword.has_key?(opts, key) do
      Map.put(state, key, Keyword.fetch!(opts, key))
    else
      state
    end
  end

  # Create a dummy game state for JIT warmup
  defp create_dummy_game_state do
    alias ExPhil.Bridge.{GameState, Player}

    dummy_player = %Player{
      # Mewtwo
      character: 25,
      x: 0.0,
      y: 0.0,
      percent: 0.0,
      stock: 4,
      facing: 1,
      action: 0,
      action_frame: 0,
      invulnerable: false,
      jumps_left: 2,
      on_ground: true,
      shield_strength: 60.0,
      hitstun_frames_left: 0,
      speed_air_x_self: 0.0,
      speed_ground_x_self: 0.0,
      speed_y_self: 0.0,
      speed_x_attack: 0.0,
      speed_y_attack: 0.0,
      nana: nil,
      controller_state: nil
    }

    %GameState{
      frame: 0,
      # Final Destination
      stage: 32,
      # In-game
      menu_state: 2,
      players: %{1 => dummy_player, 2 => dummy_player},
      projectiles: [],
      distance: 50.0
    }
  end
end
