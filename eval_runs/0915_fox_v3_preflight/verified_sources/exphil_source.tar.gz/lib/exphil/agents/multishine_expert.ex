defmodule ExPhil.Agents.MultishineExpert do
  @moduledoc """
  Scripted multishine expert for DAgger-style relabeling.

  Labels any Fox state with the controller input a perfect multishiner would
  ISSUE from that state (the input that lands on the next frame) — the
  causal convention `Peppi.to_training_frames/2` emits since 2026-09-09
  (INVARIANTS.md item 1), so labels compose with `Data.shift_actions/2`
  exactly like human replay data. Before the rebase the table held the
  input recorded ON the frame (the one that produced it); with the drill's
  `--action-delay` renumbered (old 2 == new 1) the composed labels are
  identical, and the recovery rules already answered "what to press from
  here".

  Two layers:

  1. **Table** — modal controller per `{action, action_frame, on_ground}` key,
     extracted from the canonical multishine fixture. Covers the happy path
     (the 9-frame loop: ground reflector → jump-cancel → jumpsquat → aerial
     shine → land) with the recorder's exact stick values.
  2. **Recovery rules** — hand-written fallbacks for states the fixture never
     visits (where a live policy drifts off-distribution): missed jump-cancel
     (grounded reflector af≥3 → press jump), empty hop (airborne non-reflector
     → aerial shine), grounded neutral (→ start shine), aerial reflector
     ride-down (→ neutral, land into the loop).

  Death/respawn states return `:skip` — they carry no learnable signal.

  ## Usage

      expert = MultishineExpert.from_fixture()
      case MultishineExpert.label(expert, player) do
        {:ok, controller} -> # DAgger target for this frame
        :skip -> # drop frame (dead/respawn)
      end
  """

  alias ExPhil.Bridge.ControllerState
  alias ExPhil.Constants

  # cycle: the canonical loop as an ordered list of state keys (one period);
  # phase: key -> index into cycle. Both derived from the fixture in
  # from_frames/2 (the modal period between successive ground-reflector f1
  # states), so the k-ahead label (label_ahead/4) comes from the EXPERT'S
  # future — the loop — never from whatever a recording did next.
  defstruct [:table, cycle: [], phase: %{}]

  @type key :: {integer(), integer(), boolean()}
  @type t :: %__MODULE__{
          table: %{optional(key()) => ControllerState.t()},
          cycle: [key()],
          phase: %{optional(key()) => non_neg_integer()}
        }

  @fixture_path "test/fixtures/replays/fox_multishine_closed.slp"

  # Fox action-state IDs, bound at compile time from ExPhil.Constants so the
  # per-frame checks below stay literals rather than remote calls.
  # (Constants.jumpsquat/0 is the module's other landmark state, but this
  # module keys its table on raw {action, af, grounded} and never tests it.)
  @reflector_ground Constants.reflector_ground()
  @reflector_air Constants.reflector_air()
  @first_actionable Constants.first_actionable()

  @doc """
  Build an expert from a multishine replay (defaults to the canonical fixture).

  Options:
    - `:player_port` - port of the multishining player (default 1)
    - `:min_count` - drop table keys seen fewer times (default 4; filters
      warm-up noise while keeping every state of the core loop)
  """
  @spec from_fixture(String.t(), keyword()) :: t()
  def from_fixture(path \\ @fixture_path, opts \\ []) do
    {:ok, replay} = ExPhil.Data.Peppi.parse(path)

    replay
    |> ExPhil.Data.Peppi.to_training_frames(
      player_port: Keyword.get(opts, :player_port, 1),
      opponent_port: Keyword.get(opts, :opponent_port, 2)
    )
    |> from_frames(opts)
  end

  @doc """
  Build an expert from training frames (as produced by `Peppi.to_training_frames/2`).
  """
  @spec from_frames([map()], keyword()) :: t()
  def from_frames(frames, opts \\ []) do
    port = Keyword.get(opts, :player_port, 1)
    min_count = Keyword.get(opts, :min_count, 4)

    table =
      frames
      |> Enum.reject(&(&1.game_state.frame < 0))
      |> Enum.reject(&sd_tail?(&1.controller))
      |> Enum.group_by(fn f ->
        p = f.game_state.players[port]
        {trunc(p.action), trunc(p.action_frame), p.on_ground}
      end)
      |> Enum.filter(fn {{action, _af, _g}, group} ->
        action >= @first_actionable and length(group) >= min_count
      end)
      |> Map.new(fn {key, group} -> {key, modal_controller(group)} end)

    cycle = canonical_cycle(frames, port, table)
    phase = cycle |> Enum.with_index() |> Map.new()

    %__MODULE__{table: table, cycle: cycle, phase: phase}
  end

  @doc """
  The input the expert would issue `k` frames AFTER this state, assuming the
  expert keeps executing (INVARIANTS.md item 14, 2026-09-12).

  For a state ON the loop (a key in the canonical cycle) that is the table's
  label at cycle phase `p + k` — the fixture's own future, not the
  recording's. `k = 0` is `label/4`.

  For any OTHER state (a recovery: reflector hold, landing, hitstun, ...)
  the expert ABSTAINS (`:skip`) when `k > 0`. It used to return the recovery
  input it commits to now, held at every k — and that projection is
  observably wrong: against the teacher's own executed futures in Dolphin,
  18/21 off-loop predictions at shift 4 disagreed while 0/327 on-loop ones
  did (RECOVERY_LABEL_CONFIRMATION 2026-09-13). The recoveries take 7+
  frames through lockout/startup before entering the loop, and the entry
  frame is not a function of the state alone, so there is no honest
  state-only k-ahead guess. Delayed recovery supervision must come from a
  recording of the teacher actually recovering (`--recorded-frames`, whose
  future is the recording), not from this table. `Labels.at_delay/3` with
  `off_loop: :hold` reproduces the old held rule for A/B comparisons only.

  This is what a delayed label MUST be for expert-labeled frames: shifting a
  per-state relabel along the recorded future borrows the student's broken
  future (RESULTS 09-12 §9: 10 of 11 loop states conflicted at the trained
  shift; 0 at shift 0).

  Returns `{:ok, %ControllerState{}}` or `:skip`.
  """
  @spec label_ahead(t(), map(), non_neg_integer(), ControllerState.t() | nil) ::
          {:ok, ControllerState.t()} | :skip
  def label_ahead(expert, player, k, prev \\ nil)
  def label_ahead(%__MODULE__{} = expert, player, 0, prev), do: label(expert, player, prev)

  def label_ahead(%__MODULE__{table: table, cycle: cycle, phase: phase}, player, k, _prev)
      when is_integer(k) and k > 0 do
    key = {trunc(player.action), trunc(player.action_frame), player.on_ground}

    case {phase[key], cycle} do
      {p, [_ | _]} when is_integer(p) ->
        target = Enum.at(cycle, rem(p + k, length(cycle)))

        case table[target] do
          # Every cycle key is table-backed by construction (canonical_cycle
          # filters on it); a miss here would be a corrupted struct.
          nil -> raise ArgumentError, "canonical cycle key #{inspect(target)} is not in the table"
          controller -> {:ok, controller}
        end

      {_, []} ->
        raise ArgumentError, "expert has no canonical cycle; it cannot project any label ahead"

      _ ->
        :skip
    end
  end

  @doc "True when the state is one of the canonical loop's keys."
  @spec on_loop?(t(), map()) :: boolean()
  def on_loop?(%__MODULE__{phase: phase}, player) do
    Map.has_key?(phase, {trunc(player.action), trunc(player.action_frame), player.on_ground})
  end

  # The canonical cycle: the MODAL sequence of state keys between two
  # successive ground-reflector af1 states in the fixture (length-capped so a
  # warm-up gap cannot pose as a period). Every key in it must be in the
  # table, so the k-ahead lookup always resolves.
  @cycle_start_af 1
  @max_period 24

  defp canonical_cycle(frames, port, table) do
    keys =
      frames
      |> Enum.reject(&(&1.game_state.frame < 0))
      |> Enum.map(fn f ->
        p = f.game_state.players[port]
        {trunc(p.action), trunc(p.action_frame), p.on_ground}
      end)

    start? = fn {action, af, grounded} -> action in @reflector_ground and af == @cycle_start_af and grounded end

    starts =
      keys
      |> Enum.with_index()
      |> Enum.filter(fn {k, _} -> start?.(k) end)
      |> Enum.map(&elem(&1, 1))

    periods =
      starts
      |> Enum.chunk_every(2, 1, :discard)
      |> Enum.map(fn [a, b] -> Enum.slice(keys, a, b - a) end)
      |> Enum.filter(fn seg -> length(seg) <= @max_period and Enum.all?(seg, &Map.has_key?(table, &1)) end)

    case periods do
      [] -> []
      _ -> periods |> Enum.frequencies() |> Enum.max_by(fn {_seg, n} -> n end) |> elem(0)
    end
  end

  @doc """
  Label a player state with the input the expert would issue from it (causal convention).

  `prev` is the input that actually landed on the previous frame (for DAgger
  rollouts: the policy's own press, the same value fed to the prev-action
  channel). Recovery taps key off it — press when the button was up, release
  when it was down — so the alternation is a function of inputs the model can
  observe. (Keying on action_frame parity failed: af freezes on repeated
  frames and its embedding saturates at af=120, making parity invisible —
  the labels looked like coin flips and training plateaued then diverged.)

  Returns `{:ok, %ControllerState{}}` or `:skip` for dead/respawn states.
  """
  @spec label(t(), map(), ControllerState.t() | nil) :: {:ok, ControllerState.t()} | :skip
  def label(%__MODULE__{table: table}, player, prev \\ nil, _opponent \\ nil) do
    action = trunc(player.action)
    af = trunc(player.action_frame)
    grounded = player.on_ground

    cond do
      action < @first_actionable ->
        :skip

      controller = table[{action, af, grounded}] ->
        {:ok, controller}

      true ->
        {:ok, recovery(action, grounded, prev)}
    end
  end

  @doc """
  Fraction of frames in a replay where the expert's label matches the recorded
  buttons exactly (diagnostic for table coverage on expert-quality data).
  """
  @spec button_agreement(t(), [map()], keyword()) :: float()
  def button_agreement(%__MODULE__{} = expert, frames, opts \\ []) do
    port = Keyword.get(opts, :player_port, 1)

    scored =
      frames
      |> Enum.reject(&(&1.game_state.frame < 0))
      |> Enum.reject(&sd_tail?(&1.controller))
      |> Enum.flat_map(fn f ->
        case label(expert, f.game_state.players[port]) do
          {:ok, c} -> [{c, f.controller}]
          :skip -> []
        end
      end)

    case scored do
      [] ->
        0.0

      pairs ->
        matches = Enum.count(pairs, fn {a, b} -> buttons(a) == buttons(b) end)
        matches / length(pairs)
    end
  end

  # -- Recovery rules (states the fixture never visits) ----------------------

  # Melee registers a jump or special only on a press EDGE: a policy taught
  # "button on, every frame" just holds it (observed live: 582 consecutive X
  # frames in reflector, zero jumps). Taps are keyed on the previously-landed
  # input: press when the button was up, release when it was down — a
  # feedback alternation the model can reproduce from its prev-action channel.
  defp recovery(action, grounded, prev) do
    cond do
      # Missed the jump-cancel window: ground reflector is JC-able on any
      # frame from 4 on — tap jump to re-enter the loop
      grounded and action in @reflector_ground ->
        if held?(prev, :button_x), do: stick_down(), else: jump_cancel()

      # Any other grounded state (wait, walk, dash, landing): start a shine
      grounded ->
        if held?(prev, :button_b), do: stick_down(), else: shine()

      # Aerial reflector: ride it down; landing transfers to ground reflector,
      # which the rule above jump-cancels
      action in @reflector_air ->
        neutral()

      # Airborne otherwise (empty hop, falling): aerial shine — lands into
      # ground reflector and the loop resumes
      true ->
        if held?(prev, :button_b), do: stick_down(), else: shine()
    end
  end

  defp held?(nil, _button), do: false
  defp held?(prev, button), do: Map.get(prev, button, false)

  # Jump-cancel keeps the stick down so the next shine input is already held
  defp jump_cancel, do: %{neutral() | button_x: true, main_stick: %{x: 0.5, y: 0.0}}
  defp shine, do: %{neutral() | button_b: true, main_stick: %{x: 0.5, y: 0.0}}
  defp stick_down, do: %{neutral() | main_stick: %{x: 0.5, y: 0.0}}
  defp neutral, do: ControllerState.neutral()

  # -- Table construction -----------------------------------------------------

  # The fixture recorder ends the game by holding pure left with no buttons
  # (SD off the ledge) — same signature filter as train_multishine_policy.exs
  defp sd_tail?(c) do
    c.main_stick.x < 0.25 and c.main_stick.y > 0.4 and
      not c.button_b and not c.button_x
  end

  # Most frequent controller signature in the group, returned as an actual
  # observed ControllerState (preserves the recorder's exact analog values)
  defp modal_controller(group) do
    modal_sig =
      group
      |> Enum.frequencies_by(&signature(&1.controller))
      |> Enum.max_by(fn {_sig, count} -> count end)
      |> elem(0)

    Enum.find(group, &(signature(&1.controller) == modal_sig)).controller
  end

  defp signature(c) do
    {buttons(c), grid(c.main_stick.x), grid(c.main_stick.y)}
  end

  defp buttons(c) do
    {c.button_a, c.button_b, c.button_x, c.button_y, c.button_z, c.button_l, c.button_r}
  end

  defp grid(v), do: round(v * 20)
end
