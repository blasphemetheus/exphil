defmodule ExPhil.Training.EmbeddingCache do
  @moduledoc """
  Disk caching for precomputed embeddings.

  Saves precomputed embeddings to disk so they can be reused across training runs
  without recomputing. Cache keys are based on:
  - Embedding config (action_mode, nana_mode, stage_mode, etc.)
  - Replay file list (sorted paths)
  - Window size (for temporal embeddings)

  ## Usage

      # Check for cached embeddings
      cache_key = EmbeddingCache.cache_key(embed_config, replay_files, opts)

      case EmbeddingCache.load(cache_key) do
        {:ok, embeddings} ->
          # Use cached embeddings
          embeddings

        {:error, %CacheError{reason: :not_found}} ->
          # Compute and cache
          embeddings = compute_embeddings(...)
          EmbeddingCache.save(cache_key, embeddings)
          embeddings
      end

  ## Cache Location

  Default: `cache/embeddings/`
  Override with `EXPHIL_CACHE_DIR` env var or `:cache_dir` option.
  """

  alias ExPhil.Error.CacheError

  require Logger

  @default_cache_dir "cache/embeddings"
  # Max bytes per chunk (~500MB) - well under Erlang's term_to_binary limit
  @max_chunk_bytes 500_000_000

  # Bump whenever the SEMANTICS of what gets cached change (e.g. the 2026-03
  # embed-split reorder), even if config/files are identical — stale entries
  # under an unchanged key silently corrupt training (GOTCHAS.md #51).
  # v2: added version + frame_count to the key (2026-07-02).
  # v3: facing-embedding fix (2026-07-08) — facing was always +1.0 (-1 is
  #     truthy through bool_embed); every pre-v3 embedding is facing-blind.
  @cache_format_version 3

  @doc """
  Generate a cache key from embedding config and replay files.

  The key is a hash of:
  - Sorted replay file paths
  - Embedding config (serialized)
  - Optional: window_size, stride for temporal
  - Optional: augmented, num_noisy_variants, noise_scale for augmented caches

  ## Options
    - `:temporal` - Whether this is temporal (sequence) data
    - `:window_size` - Window size for temporal data
    - `:stride` - Stride for temporal data
    - `:augmented` - Whether this is an augmented cache (default: false)
    - `:num_noisy_variants` - Number of noisy variants (for augmented)
    - `:noise_scale` - Noise scale (for augmented)
  """
  @spec cache_key(map(), [String.t()], keyword()) :: String.t()
  def cache_key(embed_config, replay_files, opts \\ []) do
    window_size = Keyword.get(opts, :window_size)
    stride = Keyword.get(opts, :stride, 1)
    temporal = Keyword.get(opts, :temporal, false)

    # Augmentation options
    augmented = Keyword.get(opts, :augmented, false)
    num_noisy_variants = Keyword.get(opts, :num_noisy_variants)
    noise_scale = Keyword.get(opts, :noise_scale)

    # Sort files for deterministic hashing
    sorted_files = Enum.sort(replay_files)

    # Serialize config to stable format
    config_data = serialize_config(embed_config)

    # Compute actual embedding size (includes padding logic)
    # This ensures cache invalidates if embedding_size() implementation changes
    actual_embed_size = ExPhil.Embeddings.Game.embedding_size(embed_config)

    # Build hash input
    hash_input = %{
      version: @cache_format_version,
      files: sorted_files,
      config: config_data,
      # Include computed embedding size to catch padding/alignment changes
      embedding_size: actual_embed_size,
      temporal: temporal,
      window_size: window_size,
      stride: stride,
      # Frame count of the dataset the tensor must cover (nil where the
      # caller doesn't know it) — a subset tensor can't hide under the
      # full dataset's key (GOTCHAS.md #51)
      frame_count: Keyword.get(opts, :frame_count),
      # Prev-action channel contents differ (real prev controllers vs
      # zeros) — same config, different tensor, must not share a key
      use_prev_action: Keyword.get(opts, :use_prev_action, false),
      # Include augmentation params so augmented caches have different keys
      augmented: augmented,
      num_noisy_variants: num_noisy_variants,
      noise_scale: noise_scale
    }

    # Prev-action dropout bakes a random mask into the tensor: masked and
    # clean embeddings must not collide. Added conditionally so dropout=0.0
    # keys are byte-identical to pre-dropout keys (existing caches stay
    # valid). NOTE: a cached entry pins its mask — rerunning with the same
    # dropout reuses the same masked frames (use --no-cache for a fresh mask).
    # Name/style conditioning changes the EMBEDDED BYTES (the 112-dim name
    # one-hot is filled from the registry instead of id 0), so the registry
    # mapping must be part of the key — otherwise a conditioned run silently
    # cache-hits unconditioned embeddings (the #109/#107 trap class).
    hash_input =
      case Keyword.get(opts, :player_registry) do
        %{tag_to_id: tag_to_id} -> Map.put(hash_input, :player_registry, Enum.sort(tag_to_id))
        _ -> hash_input
      end

    prev_action_dropout = Keyword.get(opts, :prev_action_dropout, 0.0)

    hash_input =
      if prev_action_dropout > 0.0 do
        Map.put(hash_input, :prev_action_dropout, prev_action_dropout)
      else
        hash_input
      end

    # Mixed drill frames change the tensor without changing replay_files —
    # keys must not collide (added conditionally: nil leaves existing keys
    # byte-identical)
    hash_input =
      case Keyword.get(opts, :mix_frames) do
        nil -> hash_input
        spec -> Map.put(hash_input, :mix_frames, spec)
      end

    # Generate SHA256 hash
    hash_input
    |> :erlang.term_to_binary()
    |> then(&:crypto.hash(:sha256, &1))
    |> Base.encode16(case: :lower)
    |> String.slice(0, 16)
  end

  @doc """
  Save embeddings to cache.

  For frame embeddings: saves an :array of tensors
  For sequence embeddings: saves a %Data{} struct with embedded_sequences

  Large tensors are automatically chunked to avoid Erlang's term_to_binary limits.
  """
  @spec save(String.t(), term(), keyword()) :: :ok | {:error, term()}
  def save(cache_key, embeddings, opts \\ []) do
    cache_dir = get_cache_dir(opts)
    File.mkdir_p!(cache_dir)

    # INVARIANTS.md item 10 — budget at the write, not in a comment. The
    # 2026-09-05 v2 launch inherited `cache_streaming: true` into the bptt
    # path and wrote 2.1GB/chunk until / hit 100%. A cache that refuses
    # the write that would exceed its budget cannot do that, whatever
    # defaults ride along. Budget: `:budget_bytes` opt, else
    # EXPHIL_CACHE_BUDGET_GB, else 50GB.
    case check_budget(cache_dir, embeddings, opts) do
      :ok ->
        # Check if we need chunked saving for large stacked tensors
        case embeddings do
          tensor when is_struct(tensor, Nx.Tensor) ->
            save_tensor(cache_key, tensor, cache_dir, opts)

          other ->
            save_single_file(cache_key, other, cache_dir)
        end

      {:error, :over_budget} = err ->
        err
    end
  end

  @default_budget_bytes 50 * 1024 * 1024 * 1024

  @doc "Bytes currently held in the cache dir (top level, files only)."
  @spec dir_bytes(Path.t()) :: non_neg_integer()
  def dir_bytes(cache_dir) do
    case File.ls(cache_dir) do
      {:ok, entries} ->
        entries
        |> Enum.map(&Path.join(cache_dir, &1))
        |> Enum.reduce(0, fn p, acc ->
          case File.stat(p) do
            {:ok, %{type: :regular, size: s}} -> acc + s
            _ -> acc
          end
        end)

      _ ->
        0
    end
  end

  @doc "Resolved write budget in bytes (opt > env > 50GB default)."
  @spec budget_bytes(keyword()) :: non_neg_integer()
  def budget_bytes(opts) do
    case Keyword.get(opts, :budget_bytes) do
      n when is_integer(n) and n >= 0 ->
        n

      _ ->
        case System.get_env("EXPHIL_CACHE_BUDGET_GB") do
          nil -> @default_budget_bytes
          gb -> trunc(String.to_float(gb <> if(String.contains?(gb, "."), do: "", else: ".0")) * 1024 * 1024 * 1024)
        end
    end
  end

  defp check_budget(cache_dir, embeddings, opts) do
    budget = budget_bytes(opts)
    incoming = estimate_bytes(embeddings)
    current = dir_bytes(cache_dir)

    if current + incoming > budget do
      unless Process.get({__MODULE__, :budget_warned}) do
        Process.put({__MODULE__, :budget_warned}, true)

        require Logger

        Logger.warning(
          "[EmbeddingCache] write REFUSED: #{div(current, 1_000_000)}MB held + " <>
            "#{div(incoming, 1_000_000)}MB incoming > budget #{div(budget, 1_000_000)}MB " <>
            "(#{cache_dir}). Raise :budget_bytes / EXPHIL_CACHE_BUDGET_GB deliberately, or " <>
            "prune the cache. Training continues without caching."
        )
      end

      {:error, :over_budget}
    else
      :ok
    end
  end

  defp estimate_bytes(%Nx.Tensor{} = t), do: Nx.byte_size(t)
  defp estimate_bytes(other), do: :erlang.external_size(other)

  # Save a tensor, chunking if necessary
  defp save_tensor(cache_key, tensor, cache_dir, _opts) do
    {num_frames, _rest} = shape_head_rest(Nx.shape(tensor))
    bytes_per_frame = Nx.byte_size(tensor) / num_frames
    frames_per_chunk = max(1, floor(@max_chunk_bytes / bytes_per_frame))

    if num_frames <= frames_per_chunk do
      # Small enough for single file
      save_single_file(cache_key, tensor, cache_dir)
    else
      # Need to chunk
      save_chunked(cache_key, tensor, cache_dir, frames_per_chunk)
    end
  end

  defp shape_head_rest(shape) do
    [head | rest] = Tuple.to_list(shape)
    {head, List.to_tuple(rest)}
  end

  # Save as single file (original behavior)
  defp save_single_file(cache_key, embeddings, cache_dir) do
    path = cache_path(cache_key, cache_dir)
    data = prepare_for_save(embeddings)

    case File.write(path, :erlang.term_to_binary(data, [:compressed])) do
      :ok ->
        size_mb = File.stat!(path).size / 1_000_000
        Logger.info("[EmbeddingCache] Saved #{cache_key} (#{Float.round(size_mb, 1)} MB)")
        :ok

      {:error, reason} ->
        {:error, reason}
    end
  end

  # Save large tensor in chunks
  defp save_chunked(cache_key, tensor, cache_dir, frames_per_chunk) do
    {num_frames, _} = shape_head_rest(Nx.shape(tensor))
    num_chunks = ceil(num_frames / frames_per_chunk)
    shape = Nx.shape(tensor)
    type = Nx.type(tensor)

    Logger.info("[EmbeddingCache] Saving #{cache_key} in #{num_chunks} chunks...")

    # Save each chunk
    chunk_info =
      for chunk_idx <- 0..(num_chunks - 1) do
        start_idx = chunk_idx * frames_per_chunk
        end_idx = min((chunk_idx + 1) * frames_per_chunk, num_frames)
        chunk_frames = end_idx - start_idx

        # Slice the tensor
        chunk_tensor = Nx.slice_along_axis(tensor, start_idx, chunk_frames, axis: 0)
        chunk_binary = Nx.to_binary(chunk_tensor)

        # Save chunk file
        chunk_path = chunk_path(cache_key, chunk_idx, cache_dir)
        File.write!(chunk_path, chunk_binary)

        %{
          index: chunk_idx,
          start: start_idx,
          frames: chunk_frames,
          size_bytes: byte_size(chunk_binary)
        }
      end

    # Save manifest
    manifest = %{
      type: :chunked_stacked_embeddings,
      shape: Tuple.to_list(shape),
      dtype: type,
      num_frames: num_frames,
      num_chunks: num_chunks,
      frames_per_chunk: frames_per_chunk,
      chunks: chunk_info
    }

    manifest_path = manifest_path(cache_key, cache_dir)
    File.write!(manifest_path, :erlang.term_to_binary(manifest, [:compressed]))

    total_mb =
      chunk_info
      |> Enum.map(& &1.size_bytes)
      |> Enum.sum()
      |> Kernel./(1_000_000)

    Logger.info(
      "[EmbeddingCache] Saved #{cache_key} (#{Float.round(total_mb, 1)} MB in #{num_chunks} chunks)"
    )

    :ok
  end

  @doc """
  Load embeddings from cache.

  Automatically handles both single-file and chunked formats.

  ## Options
    * `:cache_dir` - cache directory
    * `:expected_frames` - if given and the loaded value is a tensor, its
      axis-0 size must match or the entry is rejected as `:stale`. Guards
      against entries cached under the same key but covering a different
      subset of the dataset (GOTCHAS.md #51) — callers should treat the
      `:stale` error like a miss and recompute.
  """
  @spec load(String.t(), keyword()) :: {:ok, term()} | {:error, :not_found | term()}
  def load(cache_key, opts \\ []) do
    cache_dir = get_cache_dir(opts)
    path = cache_path(cache_key, cache_dir)
    manifest = manifest_path(cache_key, cache_dir)

    result =
      cond do
        # Check for chunked format first (manifest file)
        File.exists?(manifest) ->
          load_chunked(cache_key, cache_dir)

        # Fall back to single file
        File.exists?(path) ->
          load_single_file(cache_key, cache_dir)

        true ->
          {:error, CacheError.new(:not_found, context: %{details: "cache key #{cache_key}"})}
      end

    validate_expected_frames(result, cache_key, Keyword.get(opts, :expected_frames))
  end

  defp validate_expected_frames(result, _cache_key, nil), do: result

  defp validate_expected_frames({:ok, %Nx.Tensor{} = tensor} = ok, cache_key, expected) do
    rows = Nx.axis_size(tensor, 0)

    if rows == expected do
      ok
    else
      Logger.warning(
        "[EmbeddingCache] Entry #{cache_key} has #{rows} rows but #{expected} were " <>
          "expected — stale entry (covers a different dataset subset), rejecting"
      )

      {:error,
       CacheError.new(:stale,
         context: %{details: "#{cache_key}: #{rows} rows cached, #{expected} expected"}
       )}
    end
  end

  defp validate_expected_frames(result, _cache_key, _expected), do: result

  defp load_single_file(cache_key, cache_dir) do
    path = cache_path(cache_key, cache_dir)

    case File.read(path) do
      {:ok, binary} ->
        data = :erlang.binary_to_term(binary, [:safe])
        embeddings = restore_from_load(data)
        size_mb = byte_size(binary) / 1_000_000
        Logger.info("[EmbeddingCache] Loaded #{cache_key} (#{Float.round(size_mb, 1)} MB)")
        {:ok, embeddings}

      {:error, reason} ->
        {:error, reason}
    end
  end

  defp load_chunked(cache_key, cache_dir) do
    manifest_file = manifest_path(cache_key, cache_dir)

    with {:ok, manifest_binary} <- File.read(manifest_file),
         manifest <- :erlang.binary_to_term(manifest_binary, [:safe]) do
      %{
        shape: shape_list,
        dtype: dtype,
        num_chunks: num_chunks,
        chunks: chunks
      } = manifest

      Logger.info("[EmbeddingCache] Loading #{cache_key} from #{num_chunks} chunks...")

      total_mb =
        chunks
        |> Enum.map(& &1.size_bytes)
        |> Enum.sum()
        |> Kernel./(1_000_000)

      # For large chunked data, keep on CPU and let training transfer batches
      # GPU concatenation of 10GB+ data causes OOM during the concat operation
      # (needs 2x memory: accumulated + new chunk + result)
      Logger.info("[EmbeddingCache] Loading to CPU (GPU transfer happens per-batch during training)")

      sorted_chunks = Enum.sort_by(chunks, & &1.index)

      # Force all operations to use CPU (BinaryBackend) to avoid GPU OOM
      # EXLA may be the default backend which would try to allocate 10GB+ on GPU
      tensor = Nx.with_default_backend(Nx.BinaryBackend, fn ->
        # Load all chunks to CPU first (fast), then concatenate on CPU
        chunk_tensors =
          sorted_chunks
          |> Enum.with_index()
          |> Enum.map(fn {chunk_info, idx} ->
            if rem(idx, 5) == 0 do
              Logger.info("[EmbeddingCache] Loading chunk #{idx + 1}/#{num_chunks}...")
            end

            chunk_file = chunk_path(cache_key, chunk_info.index, cache_dir)
            {:ok, binary} = File.read(chunk_file)

            # Reconstruct chunk shape: {chunk_frames, ...rest}
            [_total_frames | rest] = shape_list
            chunk_shape = List.to_tuple([chunk_info.frames | rest])

            Nx.from_binary(binary, dtype) |> Nx.reshape(chunk_shape)
          end)

        Logger.info("[EmbeddingCache] Concatenating #{num_chunks} chunks on CPU...")
        Nx.concatenate(chunk_tensors, axis: 0)
      end)

      Logger.info(
        "[EmbeddingCache] Loaded #{cache_key} (#{Float.round(total_mb, 1)} MB from #{num_chunks} chunks)"
      )

      {:ok, tensor}
    end
  end

  @doc """
  Check if cache exists for a key.

  Checks for both single-file and chunked formats.
  """
  @spec exists?(String.t(), keyword()) :: boolean()
  def exists?(cache_key, opts \\ []) do
    cache_dir = get_cache_dir(opts)
    path = cache_path(cache_key, cache_dir)
    manifest = manifest_path(cache_key, cache_dir)

    File.exists?(path) or File.exists?(manifest)
  end

  @doc """
  Delete a cached embedding.

  Handles both single-file and chunked formats.
  """
  @spec invalidate(String.t(), keyword()) :: :ok | {:error, term()}
  def invalidate(cache_key, opts \\ []) do
    cache_dir = get_cache_dir(opts)

    # Delete single file if exists
    path = cache_path(cache_key, cache_dir)
    File.rm(path)

    # Delete chunked files if exist
    manifest_file = manifest_path(cache_key, cache_dir)

    if File.exists?(manifest_file) do
      case File.read(manifest_file) do
        {:ok, binary} ->
          manifest = :erlang.binary_to_term(binary, [:safe])

          # Delete all chunk files
          for chunk <- manifest.chunks do
            File.rm(chunk_path(cache_key, chunk.index, cache_dir))
          end

          # Delete manifest
          File.rm(manifest_file)

        _ ->
          :ok
      end
    end

    :ok
  end

  @doc """
  List all cached embeddings.

  Shows both single-file and chunked caches with total size.
  """
  @spec list(keyword()) :: [%{key: String.t(), size_mb: float(), mtime: NaiveDateTime.t(), chunked: boolean()}]
  def list(opts \\ []) do
    cache_dir = get_cache_dir(opts)

    if File.exists?(cache_dir) do
      files = File.ls!(cache_dir)

      # Find single-file caches (.emb files without corresponding .manifest)
      single_file_caches =
        files
        |> Enum.filter(&String.ends_with?(&1, ".emb"))
        |> Enum.map(fn filename ->
          key = String.replace_suffix(filename, ".emb", "")
          manifest_exists = "#{key}.manifest" in files

          unless manifest_exists do
            path = Path.join(cache_dir, filename)
            stat = File.stat!(path)

            %{
              key: key,
              size_mb: Float.round(stat.size / 1_000_000, 1),
              mtime: NaiveDateTime.from_erl!(stat.mtime),
              chunked: false
            }
          end
        end)
        |> Enum.reject(&is_nil/1)

      # Find chunked caches (.manifest files)
      chunked_caches =
        files
        |> Enum.filter(&String.ends_with?(&1, ".manifest"))
        |> Enum.map(fn filename ->
          key = String.replace_suffix(filename, ".manifest", "")
          manifest_file = Path.join(cache_dir, filename)
          stat = File.stat!(manifest_file)

          # Calculate total size from chunks
          total_size =
            case File.read(manifest_file) do
              {:ok, binary} ->
                manifest = :erlang.binary_to_term(binary, [:safe])

                manifest.chunks
                |> Enum.map(& &1.size_bytes)
                |> Enum.sum()

              _ ->
                0
            end

          %{
            key: key,
            size_mb: Float.round(total_size / 1_000_000, 1),
            mtime: NaiveDateTime.from_erl!(stat.mtime),
            chunked: true
          }
        end)

      (single_file_caches ++ chunked_caches)
      |> Enum.sort_by(& &1.mtime, {:desc, NaiveDateTime})
    else
      []
    end
  end

  @doc """
  Clear all cached embeddings.

  Removes both single-file (.emb) and chunked (.manifest + _chunk_*.bin) formats.
  """
  @spec clear(keyword()) :: :ok
  def clear(opts \\ []) do
    cache_dir = get_cache_dir(opts)

    if File.exists?(cache_dir) do
      cache_dir
      |> File.ls!()
      |> Enum.filter(fn filename ->
        String.ends_with?(filename, ".emb") or
          String.ends_with?(filename, ".manifest") or
          String.contains?(filename, "_chunk_")
      end)
      |> Enum.each(fn filename ->
        File.rm!(Path.join(cache_dir, filename))
      end)
    end

    :ok
  end

  # Private helpers

  defp cache_path(cache_key, cache_dir) do
    Path.join(cache_dir, "#{cache_key}.emb")
  end

  defp manifest_path(cache_key, cache_dir) do
    Path.join(cache_dir, "#{cache_key}.manifest")
  end

  defp chunk_path(cache_key, chunk_index, cache_dir) do
    Path.join(cache_dir, "#{cache_key}_chunk_#{chunk_index}.bin")
  end

  defp get_cache_dir(opts) do
    Keyword.get(opts, :cache_dir) ||
      System.get_env("EXPHIL_CACHE_DIR") ||
      @default_cache_dir
  end

  # Serialize embed config to a stable, hashable format
  defp serialize_config(config) when is_struct(config) do
    config
    |> Map.from_struct()
    |> serialize_config()
  end

  defp serialize_config(config) when is_map(config) do
    config
    |> Enum.sort_by(fn {k, _} -> to_string(k) end)
    |> Enum.map(fn {k, v} -> {to_string(k), serialize_value(v)} end)
  end

  defp serialize_value(v) when is_struct(v), do: serialize_config(v)
  defp serialize_value(v) when is_map(v), do: serialize_config(v)
  defp serialize_value(v), do: v

  # Prepare embeddings for disk storage
  # Convert Nx tensors to binary format

  # NEW: Stacked tensor format {num_frames, embed_size} - much more efficient
  defp prepare_for_save(embeddings) when is_struct(embeddings, Nx.Tensor) do
    shape = Nx.shape(embeddings)
    type = Nx.type(embeddings)
    binary = Nx.to_binary(embeddings)

    {:stacked_frame_embeddings, %{binary: binary, shape: shape, type: type}}
  end

  # LEGACY: :array of individual tensors (for backwards compatibility)
  defp prepare_for_save(embeddings) when is_tuple(embeddings) and elem(embeddings, 0) == :array do
    # :array of tensors - convert each to binary
    size = :array.size(embeddings)

    tensors =
      for i <- 0..(size - 1) do
        tensor = :array.get(i, embeddings)
        Nx.to_binary(tensor)
      end

    # Get shape from first tensor
    first = :array.get(0, embeddings)
    shape = Nx.shape(first)
    type = Nx.type(first)

    {:frame_embeddings, %{tensors: tensors, shape: shape, type: type, size: size}}
  end

  defp prepare_for_save(%{embedded_sequences: seqs} = dataset) when seqs != nil do
    # Dataset with embedded sequences
    size = :array.size(seqs)

    tensors =
      for i <- 0..(size - 1) do
        tensor = :array.get(i, seqs)
        Nx.to_binary(tensor)
      end

    first = :array.get(0, seqs)
    shape = Nx.shape(first)
    type = Nx.type(first)

    # Also save the frames and metadata needed to reconstruct
    {:sequence_embeddings,
     %{
       tensors: tensors,
       shape: shape,
       type: type,
       size: size,
       frames: dataset.frames,
       metadata: dataset.metadata,
       embed_config: dataset.embed_config,
       dataset_size: dataset.size
     }}
  end

  defp prepare_for_save(other), do: {:raw, other}

  # Restore embeddings from loaded data

  # NEW: Stacked tensor format - direct restore
  defp restore_from_load({:stacked_frame_embeddings, %{binary: binary, shape: shape, type: type}}) do
    Nx.from_binary(binary, type) |> Nx.reshape(shape)
  end

  # LEGACY: Convert old array format to stacked tensor for consistency
  # This ensures all cached data works with the new fast batching code
  defp restore_from_load({:frame_embeddings, %{tensors: tensors, shape: shape, type: type}}) do
    # Restore individual tensors and stack them
    restored_tensors =
      Enum.map(tensors, fn binary ->
        Nx.from_binary(binary, type) |> Nx.reshape(shape)
      end)

    # Stack into single tensor {num_frames, embed_size}
    Nx.stack(restored_tensors)
  end

  defp restore_from_load(
         {:sequence_embeddings,
          %{
            tensors: tensors,
            shape: shape,
            type: type,
            frames: frames,
            metadata: metadata,
            embed_config: embed_config,
            dataset_size: dataset_size
          }}
       ) do
    array =
      tensors
      |> Enum.with_index()
      |> Enum.reduce(:array.new(), fn {binary, i}, arr ->
        tensor = Nx.from_binary(binary, type) |> Nx.reshape(shape)
        :array.set(i, tensor, arr)
      end)

    %ExPhil.Training.Data{
      frames: frames,
      metadata: metadata,
      embed_config: embed_config,
      size: dataset_size,
      embedded_sequences: array
    }
  end

  defp restore_from_load({:raw, data}), do: data
end
