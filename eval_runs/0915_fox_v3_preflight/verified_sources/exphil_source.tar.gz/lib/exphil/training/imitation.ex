defmodule ExPhil.Training.Imitation do
  @moduledoc """
  Imitation learning (behavioral cloning) from Melee replays.

  Behavioral cloning trains a policy to mimic expert actions by minimizing
  the cross-entropy loss between the policy's action distribution and the
  actions taken in replay data.

  ## Training Pipeline

  ```
  Replays (.slp) ──> Parser ──> Dataset ──> Batches ──> Training
                                              │
                                              ▼
                                    ┌─────────────────┐
                                    │   Embed State   │
                                    │        +        │
                                    │  Compute Loss   │
                                    │        +        │
                                    │ Update Weights  │
                                    └─────────────────┘
  ```

  ## Usage

      # Create trainer
      trainer = Imitation.new(
        embed_size: 1024,
        hidden_sizes: [512, 512],
        learning_rate: 1.0e-4
      )

      # Train on dataset
      {:ok, trained} = Imitation.train(trainer, dataset, epochs: 10)

      # Save checkpoint
      Imitation.save_checkpoint(trained, "checkpoints/imitation_v1.axon")

  ## Frame Unrolling

  Melee has inherent frame delay (reaction time + network latency). During
  training, we can optionally unroll multiple frames to help the model learn
  to predict actions that will be executed several frames in the future.

  ## Module Organization

  This module orchestrates imitation learning, delegating to submodules:

  - `Imitation.Optimizer` - Optimizer creation and LR schedules
  - `Imitation.Loss` - Loss function builders
  - `Imitation.TrainLoop` - Training loop and gradient handling
  - `Imitation.Validation` - Evaluation functions
  - `Imitation.Checkpointing` - Save/load/export functions

  ## See Also

  - `ExPhil.Training.Config` - Configuration parsing and presets
  - `ExPhil.Training.Data` - Data loading and preprocessing
  - `ExPhil.Networks.Policy` - The policy network architecture
  - `ExPhil.Embeddings.Game` - Game state embedding
  """

  alias ExPhil.Networks.Policy
  alias ExPhil.Embeddings
  alias ExPhil.Training.{MixedPrecision, ProbeRegularizer, ScheduledSampling, Utils}
  alias ExPhil.Training.Imitation.{Checkpointing, Loss, Optimizer, TrainLoop, Validation}

  require Logger

  defstruct [
    :policy_model,
    :policy_params,
    :optimizer,
    :optimizer_state,
    :embed_config,
    :config,
    :step,
    :metrics,
    # Cached functions for performance (built once, reused every step)
    :predict_fn,
    :apply_updates_fn,
    # Compiled loss+grad function - avoids closure creation and deep_backend_copy every batch
    :loss_and_grad_fn,
    # Compiled eval loss function - for validation without gradient computation
    :eval_loss_fn,
    # Mixed precision state (FP32 master weights + BF16 compute params)
    :mixed_precision_state,
    # Scheduled sampling (exposure bias): jitted splice fn that swaps the
    # last window position's prev-action slice for the model's own decoded
    # prediction. nil unless config.scheduled_sampling > 0. A function, so
    # it lives on the struct, NOT in config (checkpoint serialization must
    # never see a function — same rule as probe_trunk_fn).
    :ss_fn,
    # Probe-as-regularizer (r15): trunk-only forward sharing the policy's
    # param names, and the online-refit direction it penalizes. Both nil
    # unless config.probe_reg_weight > 0; probe_direction starts as a zero
    # vector (penalty exactly 0) until ProbeRegularizer.refit/4 fits it.
    :trunk_predict_fn,
    :probe_direction
  ]

  @type t :: %__MODULE__{
          policy_model: Axon.t(),
          policy_params: map(),
          optimizer: term(),
          optimizer_state: map(),
          embed_config: map(),
          config: map(),
          step: non_neg_integer(),
          metrics: map(),
          predict_fn: function() | nil,
          apply_updates_fn: function() | nil,
          eval_loss_fn: function() | nil,
          loss_and_grad_fn: function() | nil,
          mixed_precision_state: MixedPrecision.t() | nil,
          trunk_predict_fn: function() | nil,
          probe_direction: Nx.Tensor.t() | nil
        }

  # Default training configuration
  @default_config %{
    learning_rate: 1.0e-4,
    batch_size: 64,
    max_grad_norm: 1.0,
    weight_decay: 1.0e-5,
    warmup_steps: 1000,
    # Number of frames to stack
    frame_stack: 1,
    # Frames between state and action
    frame_delay: 0,
    log_interval: 100,
    checkpoint_interval: 1000,
    axis_buckets: 16,
    shoulder_buckets: 4,
    # MLP architecture
    # MLP hidden layer sizes
    hidden_sizes: [512, 512],
    # Dropout rate
    dropout: 0.1,
    # Precision (bf16 = ~2x faster, minimal accuracy loss)
    precision: :bf16,
    # Mixed precision training (FP32 master weights + BF16 compute)
    # More numerically stable than pure BF16 - preserves small gradients
    mixed_precision: false,
    # Temporal training options
    # Enable temporal/sequence training
    temporal: false,
    # :sliding_window, :hybrid, :lstm, :mlp
    backbone: :sliding_window,
    # Frames in attention window
    window_size: 60,
    # Attention heads
    num_heads: 4,
    # Dimension per head
    head_dim: 64,
    # LSTM/hybrid hidden size
    hidden_size: 256,
    # Attention/recurrent layers
    num_layers: 2,
    # nil = full BPTT, integer = truncate to last N steps
    truncate_bptt: nil,
    # Mamba-specific options
    # Mamba SSM state dimension
    state_size: 16,
    # Mamba expansion factor
    expand_factor: 2,
    # Mamba conv kernel size
    conv_size: 4,
    # Jamba-specific (Mamba + Attention hybrid)
    # Insert attention layer every N layers
    attention_every: 3,
    # Gradient checkpointing (trade compute for memory)
    # Enable gradient checkpointing for memory efficiency
    gradient_checkpoint: false,
    # Checkpoint every N layers (1 = every layer)
    checkpoint_every: 1,
    # Layer normalization for MLP backbone
    # Add layer norm after each dense layer
    layer_norm: false,
    # Gradient accumulation
    # 1 = no accumulation, N = effective batch = batch_size * N
    accumulation_steps: 1,
    # Label smoothing
    # 0.0 = no smoothing, 0.1 = typical value
    label_smoothing: 0.0,
    # Loss options (overridden by CLI flags via trainer_opts)
    focal_loss: true,
    focal_gamma: 2.0,
    button_weight: 2.0,
    button_pos_weight: :auto,
    stick_edge_weight: nil,
    # Entropy regularization
    # Prevents mode collapse by penalizing collapsed output distributions
    entropy_weight: 0.0,
    # Probe-as-regularizer (r15): weight on mean((trunk . v)^2) where v is
    # the online-refit shield-lock direction. 0.0 = off (temporal only)
    probe_reg_weight: 0.0,
    # Optimizer selection
    # :adam, :adamw, :lamb, :radam, :sgd, :rmsprop
    optimizer: :adamw,
    # K-means stick discretization
    # Path or tensor of K-means centers (nil = uniform buckets)
    kmeans_centers: nil
  }

  @doc """
  Create a new imitation learning trainer.

  ## Options
    - `:embed_size` - Size of state embedding (required, or provide :embed_config)
    - `:embed_config` - Embedding configuration (alternative to embed_size)
    - `:hidden_sizes` - Policy network hidden layer sizes (for MLP backbone)
    - `:learning_rate` - Initial learning rate
    - `:batch_size` - Training batch size
    - `:max_grad_norm` - Gradient clipping threshold
    - `:precision` - Tensor precision: :bf16 (default, ~2x faster) or :f32
    - `:temporal` - Enable temporal/sequence training (default: false)
    - `:backbone` - Temporal backbone type: :sliding_window, :hybrid, :lstm, :mlp
    - `:window_size` - Attention window size for temporal (default: 60)
    - Other options merged into config
  """
  @spec new(keyword()) :: t()
  def new(opts \\ []) do
    # Get embedding configuration
    embed_config =
      Keyword.get_lazy(opts, :embed_config, fn ->
        # INVARIANTS.md item 4: only channels the parser provides get dims.
        Embeddings.config_for_source(
          Keyword.take(opts, [:with_speeds, :with_nana, :with_projectiles, :stage_internals, :action_frame_buckets]),
          ExPhil.Data.Peppi.provides()
        )
      end)

    embed_size = Keyword.get(opts, :embed_size, Embeddings.embedding_size(embed_config))

    # Build config — merge ALL opts into defaults (don't whitelist)
    # Previously used Keyword.take which silently dropped unknown keys,
    # causing entropy_weight and other new options to never reach the loss function
    opts = ExPhil.Training.LabelDelay.resolve!(opts)

    config =
      @default_config
      |> Map.merge(Map.new(opts))
      |> Map.put(:embed_size, embed_size)
      |> Map.put(:label_convention, ExPhil.Data.LabelConvention.current())

    # Load K-means centers if path provided
    config = load_kmeans_centers(config)
    ExPhil.Networks.Policy.ExecutionContract.training(config)

    # True autoregressive head (AUTOREGRESSIVE_HEAD_PLAN §3): temporal only
    # for the trainer path — the non-temporal builder has no trunk seam.
    head = Map.get(config, :head, :independent)

    if head == :autoregressive and not config.temporal do
      raise ArgumentError, "head: :autoregressive requires temporal: true"
    end

    # Contiguous-BPTT mode guards (BPTT_LOADER_DESIGN.md): the carry path
    # supports exactly the fox_gen-class recipe — temporal GRU, plain or AR
    # head, full precision, no self-sampling/probe variants.
    if config[:bptt] do
      unless config.temporal, do: raise(ArgumentError, "bptt requires temporal: true")

      if config.backbone != :gru,
        do: raise(ArgumentError, "bptt supports backbone: :gru only (got #{inspect(config.backbone)})")

      if config[:mixed_precision],
        do: raise(ArgumentError, "bptt does not support mixed_precision")

      if (config[:scheduled_sampling] || 0.0) > 0.0,
        do: raise(ArgumentError, "bptt does not support scheduled_sampling")

      if (config[:probe_reg_weight] || 0.0) > 0.0,
        do: raise(ArgumentError, "bptt does not support probe_reg_weight")

      if (config[:accumulation_steps] || 1) != 1,
        do: raise(ArgumentError, "bptt does not support gradient accumulation; use accumulation_steps: 1")
    end

    # Build policy model - bptt, temporal, or regular
    policy_model =
      if config[:bptt] do
        Policy.build_temporal_bptt(
          head: head,
          embed_size: embed_size,
          backbone: config.backbone,
          window_size: config[:unroll] || 80,
          seed: config[:seed],
          hidden_size: config.hidden_size,
          num_layers: config.num_layers,
          dropout: config.dropout,
          axis_buckets: config.axis_buckets,
          shoulder_buckets: config.shoulder_buckets
        )
      else
      if config.temporal do
        Policy.build_temporal(
          recurrent_state: Map.get(config, :recurrent_state, :legacy_random),
          head: head,
          embed_size: embed_size,
          backbone: config.backbone,
          window_size: config.window_size,
          num_heads: config.num_heads,
          head_dim: config.head_dim,
          hidden_size: config.hidden_size,
          num_layers: config.num_layers,
          hidden_sizes: config.hidden_sizes,
          dropout: config.dropout,
          axis_buckets: config.axis_buckets,
          shoulder_buckets: config.shoulder_buckets,
          truncate_bptt: config.truncate_bptt,
          layer_norm: config.layer_norm,
          # Jamba-specific
          attention_every: config.attention_every,
          # Jamba stability options (Pre-LN + QK LayerNorm prevent NaN)
          pre_norm: Map.get(config, :pre_norm, true),
          qk_layernorm: Map.get(config, :qk_layernorm, true),
          # Gradient checkpointing for memory efficiency
          gradient_checkpoint: Map.get(config, :gradient_checkpoint, false),
          checkpoint_every: Map.get(config, :checkpoint_every, 1),
          # Mamba-family shape/scan options (nil entries are skipped by
          # the backbone builders' Keyword.get defaults)
          state_size: config.state_size,
          expand_factor: config.expand_factor,
          conv_size: config.conv_size,
          chunk_size: Map.get(config, :chunk_size),
          training_mode: Map.get(config, :training_mode)
        )
      else
        Policy.build(
          embed_size: embed_size,
          hidden_sizes: config.hidden_sizes,
          dropout: config.dropout,
          axis_buckets: config.axis_buckets,
          shoulder_buckets: config.shoulder_buckets,
          layer_norm: config.layer_norm
        )
      end
      end

    # Apply mixed precision policy if precision is bf16
    # Uses Axon.MixedPrecision: params stay f32, compute in bf16, output f32
    # Conv layers are handled separately — build_depthwise_conv1d casts to f32
    # internally to avoid XLA's depthwise conv gradient SIGBUS with bf16
    policy_model =
      if config.precision == :bf16 do
        mp_policy = Axon.MixedPrecision.create_policy(
          params: {:f, 32},
          compute: {:bf, 16},
          output: {:f, 32}
        )
        Axon.MixedPrecision.apply_policy(policy_model, mp_policy,
          except: [:batch_norm, :layer_norm, :group_norm]
        )
      else
        policy_model
      end

    # Initialize parameters using newer Axon API
    # Use mode: :train to ensure all parameters (including dropout state) are initialized
    # Axon has its own explicit initialization seed. Seeding Erlang's RNG
    # later in Trainer.fit does not seed initial weights or dropout state.
    init_opts =
      if is_integer(config[:seed]),
        do: [mode: :train, seed: config[:seed]],
        else: [mode: :train]

    {init_fn, _predict_fn} = Utils.build_compiled(policy_model, init_opts)

    # Input shape depends on temporal mode
    input_shape =
      if config.temporal do
        {1, config.window_size, embed_size}
      else
        {1, embed_size}
      end

    # When using mixed precision, initialize params in FP32 (master weights)
    # Otherwise use configured precision
    init_precision = if config.mixed_precision, do: :f32, else: config.precision

    # AR head: the model has teacher-forced component inputs too
    init_template =
      cond do
        config[:bptt] ->
          unroll = config[:unroll] || 80

          base = %{
            "state_sequence" => Nx.template({1, unroll, embed_size}, init_precision),
            "initial_hidden" => Nx.template({1, config.num_layers, config.hidden_size}, :f32)
          }

          if head == :autoregressive do
            Map.merge(base, %{
              "tf_buttons" => Nx.template({1, unroll, 8}, :f32),
              "tf_main_x" => Nx.template({1, unroll}, :s64),
              "tf_main_y" => Nx.template({1, unroll}, :s64),
              "tf_c_x" => Nx.template({1, unroll}, :s64),
              "tf_c_y" => Nx.template({1, unroll}, :s64)
            })
          else
            base
          end

        head == :autoregressive ->
          Map.merge(
            %{"state_sequence" => Nx.template(input_shape, init_precision)},
            ExPhil.Networks.Policy.Heads.tf_templates(1)
          )

        true ->
          Nx.template(input_shape, init_precision)
      end

    policy_params = init_fn.(init_template, Axon.ModelState.empty())

    # Initialize mixed precision state if enabled
    # This maintains FP32 master weights while computing in BF16
    mixed_precision_state =
      if config.mixed_precision do
        compute_precision = config.precision || :bf16
        MixedPrecision.init(get_params_data(policy_params), precision: compute_precision)
      else
        nil
      end

    # Create optimizer with gradient clipping
    {optimizer_init, optimizer_update} = Optimizer.create_optimizer(config)

    # Initialize optimizer state with just the parameter data (not full ModelState)
    # For mixed precision, use FP32 master weights; otherwise use policy_params
    params_data =
      if mixed_precision_state do
        MixedPrecision.get_master_params(mixed_precision_state)
      else
        get_params_data(policy_params)
      end

    optimizer_state = optimizer_init.(params_data)

    # Pre-build cached functions for performance
    # These are reused every training step instead of being rebuilt
    {_init_fn, predict_fn} = Utils.build_compiled(policy_model, mode: :inference)

    # JIT compile optimizer and update functions with EXLA for GPU execution
    # Without compiler: EXLA, these default to CPU which causes 0% GPU utilization
    optimizer_fn = Nx.Defn.jit(optimizer_update, compiler: EXLA, on_conflict: :reuse)
    apply_updates_fn = Nx.Defn.jit(&Polaris.Updates.apply_updates/2, compiler: EXLA, on_conflict: :reuse)

    # Probe-as-regularizer (r15): build the trunk-only forward once; the
    # trunk fn rides into the loss builder via a TRANSIENT config key (not
    # stored on trainer.config, so checkpoint serialization never sees a
    # function). Requires temporal — the direction lives in trunk space.
    {trunk_predict_fn, probe_direction} =
      if (config[:probe_reg_weight] || 0.0) > 0 do
        unless config.temporal do
          raise ArgumentError, "probe_reg_weight requires temporal: true (trunk-space direction)"
        end

        {ProbeRegularizer.build_trunk_fn(config),
         Nx.broadcast(Nx.tensor(0.0, type: :f32), {config.hidden_size})}
      else
        {nil, nil}
      end

    # Scheduled sampling (exposure bias, EXPOSURE_BIAS.md item 5): locate
    # the prev-action slice empirically unless the caller supplied it, then
    # build the jitted splice fn once. Discovery probes the ACTUAL embed
    # config, so non-default layouts (queue-as-input, delay-id) resolve to
    # the queue block's first slot; pass :ss_prev_dims explicitly only to
    # override. Queue depth flows from the embed config: all K slots are
    # self-sampled (ScheduledSampling moduledoc has the alignment argument).
    config =
      if (config[:scheduled_sampling] || 0.0) > 0.0 do
        config
        |> then(fn c ->
          if c[:ss_prev_dims] == nil do
            Map.put(
              c,
              :ss_prev_dims,
              ExPhil.Interp.Attribution.prev_action_dim_range(config: embed_config)
            )
          else
            c
          end
        end)
        |> then(fn c ->
          if c[:ss_queue_depth] == nil do
            Map.put(c, :ss_queue_depth, Map.get(embed_config, :queue_depth) || 1)
          else
            c
          end
        end)
      else
        config
      end

    if (config[:scheduled_sampling] || 0.0) > 0.0 and
         (config[:ss_queue_depth] || 1) >= config[:window_size] do
      raise ArgumentError,
            "scheduled_sampling with ss_queue_depth #{config[:ss_queue_depth]} needs " <>
              "window_size > #{config[:ss_queue_depth]} (got #{config[:window_size]})"
    end

    ss_fn =
      if (config[:scheduled_sampling] || 0.0) > 0.0 do
        unless config.temporal do
          raise ArgumentError, "scheduled_sampling requires temporal: true (windowed states)"
        end

        unless config[:use_prev_action] do
          raise ArgumentError,
                "scheduled_sampling requires use_prev_action: true — with the channel " <>
                  "zeroed there is no conditioning to self-sample"
        end

        ScheduledSampling.build(predict_fn, config)
      end

    loss_config =
      if trunk_predict_fn,
        do: Map.put(config, :probe_trunk_fn, trunk_predict_fn),
        else: config

    # Build compiled loss+grad function (avoids deep_backend_copy every batch)
    # This function is JITted once and reused for all training steps
    loss_and_grad_fn =
      if config[:bptt] do
        {_init, train_predict_fn} = Utils.build_compiled(policy_model, mode: :train)
        Loss.build_bptt_loss_and_grad_fn(train_predict_fn, loss_config)
      else
        Loss.build_loss_and_grad_fn(predict_fn, loss_config)
      end

    # Build compiled eval loss function (for validation - no gradients needed)
    # JITted once and reused for all validation batches. bptt uses the
    # carry-threaded twin (see Validation.evaluate_bptt/3 for the protocol).
    eval_loss_fn =
      if config[:bptt],
        do: Loss.build_bptt_eval_loss_fn(predict_fn, config),
        else: Loss.build_eval_loss_fn(predict_fn, config)

    %__MODULE__{
      policy_model: policy_model,
      policy_params: policy_params,
      optimizer: optimizer_fn,
      optimizer_state: optimizer_state,
      embed_config: embed_config,
      config: config,
      step: 0,
      metrics: %{
        loss: [],
        button_loss: [],
        stick_loss: [],
        learning_rate: []
      },
      predict_fn: predict_fn,
      apply_updates_fn: apply_updates_fn,
      loss_and_grad_fn: loss_and_grad_fn,
      eval_loss_fn: eval_loss_fn,
      mixed_precision_state: mixed_precision_state,
      ss_fn: ss_fn,
      trunk_predict_fn: trunk_predict_fn,
      probe_direction: probe_direction
    }
  end

  @doc """
  Warm up JIT-compiled functions to avoid latency during training/inference.

  EXLA/XLA compiles functions lazily on first use with specific tensor shapes.
  This can cause 5-15 second delays during training when a new code path is hit.
  Calling warmup/2 before training triggers all JIT compilations upfront.

  ## What gets warmed up

  - `:all` (default) - All functions below
  - `:training` - loss_and_grad_fn (forward + backward pass)
  - `:validation` - eval_loss_fn via evaluate() (forward pass + accumulation)
  - `:inference` - predict_fn (forward pass only)

  ## Example

      trainer = Imitation.new(opts)
      sample_batch = Enum.take(dataset, 1) |> hd()

      # Warm up everything before training
      {:ok, warmup_times} = Imitation.warmup(trainer, sample_batch)
      # => {:ok, %{training: 8500, validation: 5200, inference: 1200}}

      # Or warm up specific functions
      {:ok, _} = Imitation.warmup(trainer, sample_batch, only: [:validation])

  ## Returns

  `{:ok, timing_map}` where timing_map has milliseconds for each warmed function.
  """
  @spec warmup(t(), map(), keyword()) :: {:ok, map()} | {:error, term()}
  def warmup(trainer, sample_batch, opts \\ []) do
    only = Keyword.get(opts, :only, [:all])
    show_progress = Keyword.get(opts, :show_progress, true)

    targets =
      if :all in only do
        [:training, :validation, :inference]
      else
        only
      end

    timings =
      Enum.reduce(targets, %{}, fn target, acc ->
        {time_ms, _result} = :timer.tc(fn -> warmup_target(trainer, sample_batch, target) end, :millisecond)

        if show_progress do
          IO.write(:stderr, "    ✓ #{target} JIT compiled (#{Float.round(time_ms / 1000, 1)}s)\n")
        end

        Map.put(acc, target, time_ms)
      end)

    {:ok, timings}
  rescue
    e -> {:error, Exception.message(e)}
  end

  @doc """
  Quick warmup with just validation (most common use case).

  Equivalent to `warmup(trainer, sample_batch, only: [:validation])`.
  """
  @spec warmup_validation(t(), list(), keyword()) :: {:ok, map()} | {:error, term()}
  def warmup_validation(trainer, validation_batches, opts \\ []) when is_list(validation_batches) do
    # Use same max_concurrency as actual validation to warm up the right code path
    # Default to 4 which matches evaluate/3 default
    max_concurrency = Keyword.get(opts, :max_concurrency, 4)

    # full: true processes ALL validation batches, which warms up not just JIT but also
    # whatever GPU state/memory effects occur after training JIT compilation.
    # This moves the ~3.5s overhead from first validation to warmup phase.
    full = Keyword.get(opts, :full, false)

    warmup_batches =
      if full do
        validation_batches
      else
        # Take enough batches to exercise the parallel path (at least max_concurrency batches)
        Enum.take(validation_batches, max(2, max_concurrency))
      end

    {time_ms, _result} = :timer.tc(fn ->
      evaluate(trainer, warmup_batches, show_progress: false, max_concurrency: max_concurrency)
    end, :millisecond)

    {:ok, %{validation: time_ms}}
  end

  # Private warmup implementations for each target
  defp warmup_target(trainer, batch, :training) do
    %{states: states, actions: actions} = batch
    batch_size = elem(Nx.shape(states), 0)
    frame_weights = Map.get(batch, :frame_weights) || Nx.broadcast(Nx.tensor(1.0, type: :f32), {batch_size})

    if trainer.loss_and_grad_fn do
      policy_type = trainer.config[:policy_type] || :autoregressive

      case policy_type do
        pt when pt in [:autoregressive, :act] ->
          # 5-arg variant when probe-as-regularizer is active (r15)
          {_loss, _grads} =
            if trainer.probe_direction do
              trainer.loss_and_grad_fn.(
                trainer.policy_params,
                states,
                actions,
                frame_weights,
                trainer.probe_direction
              )
            else
              trainer.loss_and_grad_fn.(trainer.policy_params, states, actions, frame_weights)
            end

        _generative ->
          # Diffusion/flow_matching need noise+timestep, skip warmup of loss_and_grad_fn
          :ok
      end
    end

    :ok
  end

  defp warmup_target(trainer, batch, :validation) do
    # Run through evaluate() with 1 batch to warm up entire validation path
    # including closure wrapper, Nx.add accumulation, Nx.to_number
    evaluate(trainer, [batch], show_progress: false, max_concurrency: 1)
    :ok
  end

  defp warmup_target(trainer, batch, :inference) do
    %{states: states} = batch

    if trainer.predict_fn do
      # Run one forward pass (AR head models take a states+tf-inputs map)
      inputs =
        Loss.policy_forward_inputs(
          trainer.config[:head] || :independent,
          trainer.config[:temporal] || false,
          states,
          batch.actions
        )

      _predictions = trainer.predict_fn.(trainer.policy_params, inputs)
    end

    :ok
  end

  # Delegate optimizer creation to Optimizer submodule
  defdelegate create_optimizer(config), to: Optimizer

  # Delegate training functions to TrainLoop submodule
  defdelegate train(trainer, dataset, opts \\ []), to: TrainLoop
  defdelegate train_epoch(trainer, dataset, epoch, callback), to: TrainLoop

  defdelegate train_step(trainer, batch, loss_fn), to: TrainLoop
  defdelegate compute_grad_norms(trainer, batch), to: TrainLoop

  # Delegate loss function builders to Loss submodule
  # Note: build_loss_fn has optional opts argument
  def build_loss_fn(policy_model, opts \\ []), do: Loss.build_loss_fn(policy_model, opts)
  defdelegate build_loss_and_grad_fn(predict_fn, config), to: Loss
  defdelegate build_eval_loss_fn(predict_fn, config), to: Loss

  # Delegate evaluation functions to Validation submodule
  def evaluate(trainer, dataset, opts \\ []), do: Validation.evaluate(trainer, dataset, opts)
  defdelegate evaluate_batch(trainer, batch), to: Validation

  # ============================================================================
  # Checkpointing - delegated to Checkpointing submodule
  # ============================================================================

  defdelegate save_checkpoint(trainer, path, opts \\ []), to: Checkpointing
  def save_checkpoint_async(trainer, path, opts \\ []),
    do: Checkpointing.save_checkpoint_async(trainer, path, opts)
  defdelegate get_optimizer_step(optimizer_state), to: Checkpointing
  defdelegate load_checkpoint(trainer, path, opts \\ []), to: Checkpointing
  defdelegate export_policy(trainer, path), to: Checkpointing

  # ============================================================================
  # Inference
  # ============================================================================

  @doc """
  Get action from the trained policy.
  """
  @spec get_action(t(), Nx.Tensor.t(), keyword()) :: map()
  def get_action(trainer, state, opts \\ []) do
    {_init_fn, predict_fn} = Utils.build_compiled(trainer.policy_model)

    Policy.sample(
      trainer.policy_params,
      predict_fn,
      state,
      Keyword.merge(
        [
          axis_buckets: trainer.config.axis_buckets,
          shoulder_buckets: trainer.config.shoulder_buckets
        ],
        opts
      )
    )
  end

  @doc """
  Get action as ControllerState for game input.
  """
  @spec get_controller_action(t(), Nx.Tensor.t(), keyword()) :: ExPhil.Bridge.ControllerState.t()
  def get_controller_action(trainer, state, opts \\ []) do
    samples = get_action(trainer, state, opts)

    Policy.to_controller_state(samples,
      axis_buckets: trainer.config.axis_buckets,
      shoulder_buckets: trainer.config.shoulder_buckets,
      kmeans_centers: trainer.config[:kmeans_centers_tensor]
    )
  end

  # ============================================================================
  # Metrics
  # ============================================================================

  @doc """
  Get current training metrics summary.
  """
  @spec metrics_summary(t()) :: map()
  def metrics_summary(trainer) do
    recent_losses = Enum.take(trainer.metrics.loss, 100)

    %{
      step: trainer.step,
      avg_loss: safe_mean(recent_losses),
      min_loss: safe_min(recent_losses),
      max_loss: safe_max(recent_losses)
    }
  end

  defp safe_mean([]), do: 0.0
  defp safe_mean(list), do: Enum.sum(list) / length(list)

  defp safe_min([]), do: 0.0
  defp safe_min(list), do: Enum.min(list)

  defp safe_max([]), do: 0.0
  defp safe_max(list), do: Enum.max(list)

  # Helper for handling Axon.ModelState
  defp get_params_data(%Axon.ModelState{data: data}), do: data
  defp get_params_data(params) when is_map(params), do: params

  # Load K-means centers from file path and update config with tensor and axis_size
  defp load_kmeans_centers(%{kmeans_centers: nil} = config), do: config

  defp load_kmeans_centers(%{kmeans_centers: path} = config) when is_binary(path) do
    alias ExPhil.Embeddings.KMeans

    case KMeans.load(path) do
      {:ok, centers} ->
        k = Nx.axis_size(centers, 0)
        # K-means gives us k clusters directly (no +1 like buckets)
        config
        |> Map.put(:kmeans_centers_tensor, centers)
        |> Map.put(:axis_size, k)
        # For compatibility with existing code
        |> Map.put(:axis_buckets, k - 1)

      {:error, reason} ->
        raise "Failed to load K-means centers from #{path}: #{inspect(reason)}"
    end
  end

  defp load_kmeans_centers(%{kmeans_centers: %Nx.Tensor{} = centers} = config) do
    k = Nx.axis_size(centers, 0)

    config
    |> Map.put(:kmeans_centers_tensor, centers)
    |> Map.put(:axis_size, k)
    |> Map.put(:axis_buckets, k - 1)
  end

  defp load_kmeans_centers(config), do: config
end
