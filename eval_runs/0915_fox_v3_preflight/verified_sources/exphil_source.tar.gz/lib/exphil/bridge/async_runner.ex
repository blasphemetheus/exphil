defmodule ExPhil.Bridge.AsyncRunner do
  @moduledoc """
  Async game runner that decouples frame reading from inference.

  Architecture:
  ```
  ┌─────────────────┐     ┌──────────────────┐     ┌─────────────────┐
  │   FrameLoop     │────▶│   SharedState    │◀────│   Inference     │
  │   (fast, 60fps) │     │   (ETS table)    │     │   (slow, async) │
  └─────────────────┘     └──────────────────┘     └─────────────────┘
         │                        │
         │                        ▼
         │                 ┌─────────────────┐
         └────────────────▶│ ControllerSend  │
                           │ (uses last act) │
                           └─────────────────┘
  ```

  The FrameLoop reads frames as fast as possible (targeting 60fps).
  The Inference process runs async and updates the action when ready.
  FrameLoop always sends the most recent action, even if inference is slow.

  **Post-game behavior (configurable via `on_game_end` option):**
  - `:restart` (default) - Automatically start a new game after each match
  - `:stop` - Exit after a single game completes

  ## Usage

      # Start the async runner
      {:ok, runner} = AsyncRunner.start_link(
        agent: agent_pid,
        bridge: bridge_pid,
        player_port: 1
      )

      # Runner handles everything automatically, restarting games
      # Call stop when done
      AsyncRunner.stop(runner)
  """

  use GenServer

  # LRAS (L+R+A+Start instant quit) — ENABLED now that the bridge polls
  # (console_timeout, 2026-07-29). The old deadlock: Start pauses the
  # game, a paused game stops producing frames, and libmelee only flushes
  # controller state inside console.step() — so a blocking bridge stalled
  # inside step() and the quit-completing Start edge could never be
  # delivered (measured 2026-07-28). With polling, step() returns
  # :no_frame after ~100ms and the frame loop keeps the send→step cycle
  # alive through the pause (see the :no_frame branch in frame_loop/5).
  # 120 ticks ≈ 2s of in-game attempts or ~12s of paused 10Hz polls
  # before falling back to the hold-left walk-off.
  @lras_frames 120

  # Consecutive :no_frame polls before the loop declares the console hung
  # (~60s at the default 100ms console_timeout). Pauses and load screens
  # are far shorter; a dead Dolphin never comes back.
  @no_frame_fatal_streak 600
  require Logger

  alias ExPhil.Agents.Agent
  alias ExPhil.Bridge.MeleePort

  # ============================================================================
  # Types
  # ============================================================================

  @typedoc "Behavior when a game ends"
  @type on_game_end :: :restart | :stop

  @typedoc "Start link options"
  @type start_option ::
          {:agent, pid()}
          | {:bridge, pid()}
          | {:player_port, pos_integer()}
          | {:auto_menu, boolean()}
          | {:on_game_end, on_game_end()}

  @typedoc "Statistics returned by get_stats/1"
  @type stats :: %{
          frames_read: non_neg_integer(),
          inferences_run: non_neg_integer(),
          games_played: non_neg_integer(),
          elapsed_ms: non_neg_integer(),
          fps: float(),
          target_fps: pos_integer(),
          fps_ratio: float(),
          inference_rate: float(),
          latest_confidence: map() | nil,
          avg_confidence: float()
        }

  @typedoc "Stop result with final counts"
  @type stop_result :: %{
          frames: non_neg_integer(),
          inferences: non_neg_integer(),
          games: non_neg_integer()
        }

  defstruct [
    :agent,
    :bridge,
    :player_port,
    # ETS table for shared state
    :state_table,
    :frame_loop_pid,
    :inference_pid,
    :running,
    # :restart or :stop
    :on_game_end,
    :stats
  ]

  # ============================================================================
  # Client API
  # ============================================================================

  @doc """
  Starts the async runner process.

  ## Options

    * `:agent` - PID of the ExPhil.Agents.Agent process (required)
    * `:bridge` - PID of the MeleePort process (required)
    * `:player_port` - Controller port for the agent (default: 1)
    * `:auto_menu` - Whether to auto-navigate menus (default: true)
    * `:on_game_end` - `:restart` to play another game, `:stop` to exit (default: `:restart`)

  ## Examples

      {:ok, runner} = AsyncRunner.start_link(
        agent: agent_pid,
        bridge: bridge_pid,
        player_port: 1
      )

  """
  @spec start_link([start_option()]) :: GenServer.on_start()
  def start_link(opts) do
    GenServer.start_link(__MODULE__, opts)
  end

  @doc """
  Stops the async runner and returns final statistics.

  Returns `{:ok, stats}` where stats contains the total frames read,
  inferences run, and games played.
  """
  @spec stop(GenServer.server()) :: {:ok, stop_result()}
  def stop(runner) do
    GenServer.call(runner, :stop)
  end

  @doc """
  Switch the frame loop to SD mode: hold full left until the game ends.

  Use this instead of `stop/1` when you need the replay finalized. Slippi only
  writes a complete `.slp` on game end, and `stop/1` tears down the bridge (it
  exits the frame loop process, which kills the Python side), so any attempt to
  drive the game AFTER stopping races the teardown and usually loses the
  recording.

  Poll `sd_complete?/1` for the game to end, then call `stop/1` as normal.
  """
  @spec begin_sd(GenServer.server()) :: :ok
  def begin_sd(runner) do
    GenServer.call(runner, :begin_sd)
  end

  @doc """
  Whether the SD started by `begin_sd/1` has reached a game end.
  """
  @spec sd_complete?(GenServer.server()) :: boolean()
  def sd_complete?(runner) do
    GenServer.call(runner, :sd_complete?)
  end

  @doc """
  Gets current runtime statistics.

  Returns a map with performance metrics including FPS, inference rate,
  and confidence statistics.
  """
  @spec get_stats(GenServer.server()) :: stats()
  def get_stats(runner) do
    GenServer.call(runner, :get_stats)
  end

  # ============================================================================
  # GenServer Callbacks
  # ============================================================================

  @impl true
  def init(opts) do
    agent = Keyword.fetch!(opts, :agent)
    bridge = Keyword.fetch!(opts, :bridge)
    player_port = Keyword.get(opts, :player_port, 1)
    auto_menu = Keyword.get(opts, :auto_menu, true)
    on_game_end = Keyword.get(opts, :on_game_end, :restart)
    # Elixir-driven opponent-port dummy (reactive drills): a module with
    # new/0 + step/3 returning {input, state}. Requires the bridge started
    # with dummy_mode: "external" so the port-2 controller exists.
    # `{module, init_arg}` passes config to new/1 — used by PolicyOpponent
    # (checkpoint ladder) which also implements the RICH contract
    # step_game/3 (full game state in, ACTION out).
    dummy_module = Keyword.get(opts, :dummy)

    # Create ETS table for shared state
    table = :ets.new(:async_runner_state, [:set, :public])

    case dummy_module do
      nil -> :ok
      {mod, init_arg} -> :ets.insert(table, {:elixir_dummy, mod, mod.new(init_arg)})
      mod -> :ets.insert(table, {:elixir_dummy, mod, mod.new()})
    end

    # Initialize shared state
    :ets.insert(table, {:latest_game_state, nil})
    :ets.insert(table, {:latest_action, nil})
    :ets.insert(table, {:in_game, false})
    # INVARIANTS item 12: the latency this session is counting on (reaction
    # delay + 1); a LatencyProbe measures it during every game's countdown.
    :ets.insert(table, {:latency_expected, Keyword.get(opts, :expected_latency)})
    :ets.insert(table, {:latency_allow_mismatch, Keyword.get(opts, :allow_latency_mismatch, false)})
    :ets.insert(table, {:latency_probe, nil})
    :ets.insert(table, {:latency_probe_pending, nil})
    :ets.insert(table, {:latency_measured, nil})
    # Only true when stop() called or fatal error
    :ets.insert(table, {:should_stop, false})
    :ets.insert(table, {:sd_mode, false})
    # LRAS requires the polling-mode console: if the chord PAUSES instead of
    # instant-quitting, only the no_frame send->step cycle can deliver the
    # quit-completing Start edge. With polling disabled the pause deadlocks
    # step() until the GenServer call timeout (reproduced 2026-07-28,
    # polling_ab r1). Callers that init the bridge with console_timeout: 0
    # MUST pass lras: false so SD goes straight to the hold-left walk-off.
    :ets.insert(table, {:lras_enabled, Keyword.get(opts, :lras, true)})
    # Direction #3: explicit local action delay (frames). Policy actions are
    # tagged so the bridge's ActionQueue applies them exactly N frames after
    # the state they answered. SD/dummy sends stay immediate.
    :ets.insert(table, {:local_delay, Keyword.get(opts, :local_delay, 0)})

    # Frame pacing (pace_hz opt): with blocking pipe input the game only
    # advances when we feed it, so the RUNNER is the throttle. The ExiAI
    # headless build has no internal throttle (audio-backend-tied on this
    # base, GOTCHA #56; emulation_speed config is a no-op) and unthrottled
    # policy-driven games quantize inputs to the act-cycle (~3.6 game
    # frames at 450fps) — SH presses mistimed, knockdowns collapse
    # (2026-07-17). pace_hz: 60 restores real-time input granularity for
    # probes; 0/absent = unpaced (scenario-style frame-locked replay
    # drives MeleePort directly and doesn't come through here).
    pace_hz = Keyword.get(opts, :pace_hz, 0)

    if is_integer(pace_hz) and pace_hz > 0 do
      :ets.insert(table, {:pace_ns, div(1_000_000_000, pace_hz)})
    end

    # Netplay searching/connecting screens legitimately emit no frames for
    # minutes — the default ~60s hung-console watchdog killed the bot mid
    # Direct search (2026-07-31 loopback test). Callers set this high (or
    # effectively infinite) when a connect_code session is in flight.
    :ets.insert(
      table,
      {:no_frame_fatal, Keyword.get(opts, :no_frame_fatal_streak, @no_frame_fatal_streak)}
    )
    # :restart or :stop
    :ets.insert(table, {:on_game_end, on_game_end})
    :ets.insert(table, {:frame_count, 0})
    :ets.insert(table, {:inference_count, 0})
    :ets.insert(table, {:games_played, 0})
    :ets.insert(table, {:start_time, nil})
    :ets.insert(table, {:latest_confidence, nil})
    # For running average
    :ets.insert(table, {:confidence_sum, 0.0})

    state = %__MODULE__{
      agent: agent,
      bridge: bridge,
      player_port: player_port,
      state_table: table,
      running: true,
      on_game_end: on_game_end,
      stats: %{
        frames_read: 0,
        inferences_run: 0,
        actions_sent: 0,
        start_time: nil
      }
    }

    # Start the frame loop process
    frame_loop_pid =
      spawn_link(fn ->
        frame_loop(bridge, table, auto_menu, player_port, agent)
      end)

    # Start the inference process
    inference_pid =
      spawn_link(fn ->
        inference_loop(agent, table, player_port)
      end)

    state = %{state | frame_loop_pid: frame_loop_pid, inference_pid: inference_pid}

    Logger.info(
      "[AsyncRunner] Started with frame_loop=#{inspect(frame_loop_pid)}, inference=#{inspect(inference_pid)}"
    )

    {:ok, state}
  end

  @impl true
  def handle_call(:begin_sd, _from, state) do
    :ets.insert(state.state_table, {:sd_mode, true})
    Logger.info("[AsyncRunner] SD mode — holding left until the game ends")
    {:reply, :ok, state}
  end

  def handle_call(:sd_complete?, _from, state) do
    # games_played increments on game end (handle_postgame), which is exactly
    # the event that makes Slippi finalize the .slp.
    done? =
      case :ets.lookup(state.state_table, :games_played) do
        [{:games_played, n}] when n > 0 -> true
        _ -> false
      end

    {:reply, done?, state}
  end

  def handle_call(:stop, _from, state) do
    Logger.info("[AsyncRunner] Stopping...")

    # Signal processes to stop
    :ets.insert(state.state_table, {:should_stop, true})

    # Give them a moment to clean up
    Process.sleep(100)

    # Kill if still alive
    if Process.alive?(state.frame_loop_pid), do: Process.exit(state.frame_loop_pid, :shutdown)
    if Process.alive?(state.inference_pid), do: Process.exit(state.inference_pid, :shutdown)

    # Get final stats
    [{:frame_count, frames}] = :ets.lookup(state.state_table, :frame_count)
    [{:inference_count, inferences}] = :ets.lookup(state.state_table, :inference_count)
    [{:games_played, games}] = :ets.lookup(state.state_table, :games_played)

    lookup_or_zero = fn key ->
      case :ets.lookup(state.state_table, key) do
        [{^key, v}] -> v
        [] -> 0
      end
    end

    stale_sends = lookup_or_zero.(:stale_sends)
    max_stale_run = lookup_or_zero.(:max_stale_run)

    :ets.delete(state.state_table)

    {:reply,
     {:ok,
      %{
        frames: frames,
        inferences: inferences,
        games: games,
        stale_sends: stale_sends,
        max_stale_run: max_stale_run
      }}, %{state | running: false}}
  end

  @impl true
  def handle_call(:get_stats, _from, state) do
    [{:frame_count, frames}] = :ets.lookup(state.state_table, :frame_count)
    [{:inference_count, inferences}] = :ets.lookup(state.state_table, :inference_count)
    [{:games_played, games}] = :ets.lookup(state.state_table, :games_played)
    [{:start_time, start_time}] = :ets.lookup(state.state_table, :start_time)
    [{:latest_confidence, latest_conf}] = :ets.lookup(state.state_table, :latest_confidence)
    [{:confidence_sum, conf_sum}] = :ets.lookup(state.state_table, :confidence_sum)

    elapsed = if start_time, do: System.monotonic_time(:millisecond) - start_time, else: 0
    fps = if(elapsed > 0, do: frames * 1000 / elapsed, else: 0)
    avg_confidence = if(inferences > 0, do: conf_sum / inferences, else: 0)

    stats = %{
      frames_read: frames,
      inferences_run: inferences,
      games_played: games,
      elapsed_ms: elapsed,
      fps: fps,
      target_fps: 60,
      # 1.0 = hitting target, <1.0 = falling behind
      fps_ratio: fps / 60,
      inference_rate: if(elapsed > 0, do: inferences * 1000 / elapsed, else: 0),
      # Confidence stats
      latest_confidence: latest_conf,
      avg_confidence: avg_confidence
    }

    {:reply, stats, state}
  end

  @impl true
  def handle_info({:DOWN, _ref, :process, pid, reason}, state) do
    cond do
      pid == state.frame_loop_pid ->
        Logger.warning("[AsyncRunner] Frame loop died: #{inspect(reason)}")

      pid == state.inference_pid ->
        Logger.warning("[AsyncRunner] Inference loop died: #{inspect(reason)}")

      true ->
        :ok
    end

    {:noreply, state}
  end

  # ============================================================================
  # Frame Loop (runs in separate process, fast)
  # ============================================================================

  # Hold the frame cadence set by :pace_ns (see init). Uses the frame
  # process's own dictionary for last-frame time — the loop is a single
  # process, no coordination needed.
  #
  # Only in-game frames pace (the frame_loop calls this solely on the
  # {:ok, game_state} branch — menu frames never sleep). That is what lets
  # --emulation-speed 0 + blocking input rip through the CSS/CPU-slider/
  # stage-select at max fps while gameplay stays 60Hz: the frame loop is
  # then the game's ONLY clock (single-clock pacing, headless trust
  # experiments 2026-07-28).
  defp pace(table) do
    case :ets.lookup(table, :pace_ns) do
      [{:pace_ns, ns}] when ns > 0 ->
        now = System.monotonic_time(:nanosecond)
        # Drift-free schedule: the next deadline advances from the PREVIOUS
        # deadline, not from "now" — sleep overshoot never accumulates. If
        # we're more than one period behind (menu exit, GC pause), resync
        # to now instead of sprinting to catch up.
        last = Process.get(:last_frame_ns, now - ns)
        deadline = if now - last > 2 * ns, do: now, else: last + ns

        # Hybrid sleep+spin: Process.sleep has ~ms granularity and jitter —
        # fatal for a 16.67ms cadence feeding 1-frame-tolerance tech
        # (measured 2026-07-28: software-paced headless chains 7-10 vs
        # emulator-throttle 10-16 vs video-throttle 15-30). Sleep to ~2ms
        # short of the deadline, then spin the remainder.
        coarse_ms = div(deadline - now, 1_000_000) - 2
        if coarse_ms > 0, do: Process.sleep(coarse_ms)
        spin_until(deadline)
        Process.put(:last_frame_ns, deadline)

      _ ->
        :ok
    end
  end

  defp spin_until(deadline) do
    if System.monotonic_time(:nanosecond) < deadline, do: spin_until(deadline)
  end

  defp frame_loop(bridge, table, auto_menu, player_port, agent) do
    case should_stop?(table) do
      true ->
        # User requested stop
        send_neutral_controller(bridge)
        Logger.info("[AsyncRunner:FrameLoop] Stop requested, exiting")
        :ok

      false ->
        # Read next frame
        step_result = MeleePort.step(bridge, auto_menu: auto_menu, poll: true)
        if step_result != :no_frame, do: Process.put(:no_frame_streak, 0)

        case step_result do
          :no_frame ->
            handle_no_frame(bridge, table, auto_menu, player_port, agent)

          {:ok, game_state} ->
            # Pace BEFORE acting: sleep to just shy of the next frame
            # deadline, THEN snapshot the latest action and send — the
            # flush (top of the next console.step) follows immediately, so
            # the freshest inference result rides each frame. The old
            # send-then-sleep order let the queued action go stale for a
            # full period; with a drift-free pacer that phase-locked into
            # a consistent one-frame-late application and collapsed chains
            # to 2-4 (the async+1 brittleness signature, 2026-07-28).
            pace(table)
            handle_game_frame(bridge, table, game_state, player_port, agent)
            frame_loop(bridge, table, auto_menu, player_port, agent)

          {:postgame, game_state} ->
            handle_postgame(bridge, table, game_state, agent)
            frame_loop(bridge, table, auto_menu, player_port, agent)

          {:menu, game_state} ->
            # Falling out of a game into ANY menu is the game end: this
            # Slippi setup never reports POSTGAME_SCORES (verified from
            # bridge logs — a full game→restart cycle showed IN_GAME →
            # CHARACTER_SELECT directly), so waiting for a :postgame event
            # meant on_game_end was never honored and :stop sessions ran
            # (and held the GPU) forever.
            if in_game?(table), do: handle_postgame(bridge, table, game_state, agent)

            # Otherwise just continue (auto_menu handles navigation)
            frame_loop(bridge, table, auto_menu, player_port, agent)

          {:game_ended, reason} ->
            # Fatal disconnect - always stop
            Logger.info("[AsyncRunner:FrameLoop] Fatal: #{reason}")
            send_neutral_controller(bridge)
            :ets.insert(table, {:should_stop, true})
            :ok

          {:error, reason} ->
            # Fatal error - always stop
            Logger.error("[AsyncRunner:FrameLoop] Error: #{inspect(reason)}")
            send_neutral_controller(bridge)
            :ets.insert(table, {:should_stop, true})
            :ok
        end
    end
  end

  # Polling timeout: the console produced no frame within console_timeout.
  # Expected while the game is PAUSED (the first LRAS Start press) or on
  # load screens. Controllers only flush inside console.step(), so during a
  # pause each no-frame tick must both advance the SD input schedule (the
  # Start pulse needs fresh edges) and immediately re-poll — that send→step
  # cycle at ~10Hz is what delivers the quit-completing Start edge to the
  # pause screen. Outside SD mode a no-frame tick is just a quiet re-poll.
  defp handle_no_frame(bridge, table, auto_menu, player_port, agent) do
    streak = Process.get(:no_frame_streak, 0) + 1
    Process.put(:no_frame_streak, streak)

    fatal_streak =
      case :ets.lookup(table, :no_frame_fatal) do
        [{:no_frame_fatal, v}] -> v
        _ -> @no_frame_fatal_streak
      end

    cond do
      streak > fatal_streak ->
        Logger.error(
          "[AsyncRunner:FrameLoop] #{streak} consecutive no-frame polls — " <>
            "console hung or disconnected, stopping"
        )

        send_neutral_controller(bridge)
        :ets.insert(table, {:should_stop, true})
        :ok

      sd_mode?(table) ->
        n = :ets.update_counter(table, :sd_frames, 1, {:sd_frames, 0})

        if rem(n, 20) == 1 do
          IO.puts("[SD] no-frame tick #{n} (game paused?) — pulsing LRAS/Start")
        end

        MeleePort.send_controller(bridge, sd_no_frame_input(player_port, n, lras_frames(table)))
        frame_loop(bridge, table, auto_menu, player_port, agent)

      true ->
        frame_loop(bridge, table, auto_menu, player_port, agent)
    end
  end

  defp handle_game_frame(bridge, table, game_state, player_port, agent) do
    # Update latest game state, then WAKE the inference process exactly once
    # per new frame (INVARIANTS.md item 6): decisions are frame-driven, not
    # polled. The inference loop coalesces any backlog to the newest frame.
    :ets.insert(table, {:latest_game_state, game_state})

    case :ets.lookup(table, :inference_pid) do
      [{:inference_pid, pid}] when is_pid(pid) -> send(pid, :new_frame)
      _ -> :ok
    end

    # Check if this is game start
    case :ets.lookup(table, :in_game) do
      [{:in_game, false}] ->
        [{:games_played, games}] = :ets.lookup(table, :games_played)

        Logger.info(
          "[AsyncRunner:FrameLoop] GAME #{games + 1} START at frame #{game_state.frame}"
        )

        :ets.insert(table, {:in_game, true})
        :ets.insert(table, {:start_time, System.monotonic_time(:millisecond)})

        [{:latency_expected, expected}] = :ets.lookup(table, :latency_expected)
        :ets.insert(table, {:latency_probe, ExPhil.Bridge.LatencyProbe.new(expected: expected)})

      _ ->
        :ok
    end

    # Increment frame count
    :ets.update_counter(table, :frame_count, 1)

    # SD mode overrides the policy: hold full left, no buttons, so the player
    # walks off and burns stocks until the game ENDS and Slippi finalizes the
    # replay. This MUST happen inside the frame loop.
    #
    # The obvious alternative — stop the runner, then drive the bridge from the
    # caller — is broken: stop/1 does Process.exit(frame_loop_pid, :shutdown),
    # which tears down the Python bridge ("Parent process died — force
    # exiting", Dolphin exits code 9), so the caller then talks to a corpse.
    # It won that race ~70% of the time, which is worse than failing outright:
    # the other ~30% produced a TRUNCATED .slp that peppi rejects, silently
    # costing an entire recording.
    if sd_mode?(table) do
      n = :ets.update_counter(table, :sd_frames, 1, {:sd_frames, 0})

      # SD-flake observability: is the input stream landing? x moving /
      # stocks dropping = yes; frozen = the stream is desynced and the game
      # never sees the quit inputs.
      lf = lras_frames(table)

      if rem(n, 60) == 1 do
        # INVARIANTS.md item 5: the subject is resolved at the boundary (the
        # stamped own_port under Slippi Online), never the static config port.
        p = ExPhil.Bridge.GameState.subject(game_state, player_port)

        IO.puts(
          "[SD] f#{n} phase=#{if(n <= lf, do: "LRAS", else: "hold-left")} " <>
            "stocks=#{p && p.stock} x=#{p && Float.round((p.x || 0.0) * 1.0, 1)} action=#{p && p.action}"
        )
      end

      MeleePort.send_controller(bridge, sd_input(player_port, n, lf))
    else
      # The probe must measure the POLICY path: a decision made on frame f
      # is sent while handling frame f+1 (the inference process wakes on
      # :new_frame and the frame loop sends whatever latest_action holds).
      # So a probe input decided on this frame is SENT on the next tick —
      # exactly the hop a real decision takes (verified 09-12 vs Slippi's
      # recording: the synchronous send landed one frame earlier than the
      # policy's rung).
      pending =
        case :ets.lookup(table, :latency_probe_pending) do
          [{:latency_probe_pending, input}] when is_map(input) -> input
          _ -> nil
        end

      case step_latency_probe(table, game_state, player_port) do
        {:send, input} -> :ets.insert(table, {:latency_probe_pending, input})
        _ -> :ets.insert(table, {:latency_probe_pending, nil})
      end

      case pending do
        %{} = input ->
          # Countdown frame owned by the latency probe (marker / neutral),
          # through the same local-delay tagging as a policy send so the
          # measurement includes every stage of this harness's pipeline.
          MeleePort.send_controller(bridge, maybe_tag_local_delay(input, table))

        _ ->
          case :ets.lookup(table, :latest_action) do
            [{:latest_action, nil}] ->
              # No action yet, send neutral
              :ok

            [{:latest_action, action}] ->
              # Send the action
              input =
                action
                |> action_to_input(player_port)
                |> maybe_tag_local_delay(table)

              MeleePort.send_controller(bridge, input)
              track_staleness(table)
          end
      end
    end

    drive_elixir_dummy(bridge, table, game_state, player_port)

    # Check for game end via stocks
    check_stocks_for_game_end(bridge, table, game_state, player_port, agent)
  end

  # INVARIANTS item 12 (structural form): measure this harness's decision->
  # application latency during the countdown of every game. The async
  # runner keeps playing on a mismatch (it may be mid-netplay) but says so
  # at error level and records it for get_stats.
  defp step_latency_probe(table, game_state, player_port) do
    alias ExPhil.Bridge.LatencyProbe

    case :ets.lookup(table, :latency_probe) do
      [{:latency_probe, %LatencyProbe{} = probe}] ->
        {action, probe} = LatencyProbe.step(probe, game_state, player_port)
        :ets.insert(table, {:latency_probe, probe})

        case action do
          {:done, {:ok, l}} ->
            :ets.insert(table, {:latency_measured, l})
            # Output, not Logger.info: the play scripts run the Logger at
            # :warning, and the measurement must be visible in every log.
            ExPhil.Training.Output.success("[AsyncRunner] ⏱️  #{LatencyProbe.describe(probe)}")

          {:done, {:mismatch, l}} ->
            :ets.insert(table, {:latency_measured, l})
            [{:latency_allow_mismatch, allow?}] = :ets.lookup(table, :latency_allow_mismatch)

            Logger.error(
              "[AsyncRunner] #{LatencyProbe.describe(probe)} (INVARIANTS item 12, GOTCHA #115)" <>
                if(allow?, do: " — continuing (--allow-latency-mismatch)", else: " — every chain number from this game is off-rung")
            )

          {:done, :unmeasured} ->
            Logger.warning("[AsyncRunner] #{LatencyProbe.describe(probe)}")

          _ ->
            :ok
        end

        action

      _ ->
        :pass
    end
  end

  # Staleness telemetry. The frame loop always sends the most recent action,
  # so when inference runs slower than the frame cadence the SAME action is
  # re-sent with no new inference in between. For frame-precise sequences (a
  # 9-frame multishine cycle) ONE stale send is a timing slip, so the
  # distribution — stale sends and the longest stale run — is the
  # harness-health number a live eval needs; the aggregate inference rate
  # (1.2x on an idle laptop, 2026-07-27) hides it. Read AFTER the send, so a
  # same-frame inference completion can count as fresh — approximate by one
  # frame either way, fine for a health metric. Counters surface in stop/1's
  # final stats.
  defp track_staleness(table) do
    [{:inference_count, inf}] = :ets.lookup(table, :inference_count)

    last =
      case :ets.lookup(table, :inf_at_last_send) do
        [{:inf_at_last_send, v}] -> v
        [] -> -1
      end

    :ets.insert(table, {:inf_at_last_send, inf})

    if last == inf do
      :ets.update_counter(table, :stale_sends, 1, {:stale_sends, 0})
      run = :ets.update_counter(table, :stale_run, 1, {:stale_run, 0})

      case :ets.lookup(table, :max_stale_run) do
        [{:max_stale_run, m}] when m >= run -> :ok
        _ -> :ets.insert(table, {:max_stale_run, run})
      end
    else
      :ets.insert(table, {:stale_run, 0})
    end
  end

  defp handle_postgame(bridge, table, game_state, agent) do
    # Only log if we were in a game
    case :ets.lookup(table, :in_game) do
      [{:in_game, true}] ->
        :ets.update_counter(table, :games_played, 1)
        [{:games_played, games}] = :ets.lookup(table, :games_played)

        Logger.info(
          "[AsyncRunner:FrameLoop] POSTGAME (game #{games}) at frame #{game_state.frame}"
        )

        # Check on_game_end setting
        case :ets.lookup(table, :on_game_end) do
          [{:on_game_end, :stop}] ->
            Logger.info("[AsyncRunner:FrameLoop] on_game_end=:stop, finishing")
            :ets.insert(table, {:should_stop, true})

          [{:on_game_end, :restart}] ->
            Logger.info("[AsyncRunner:FrameLoop] on_game_end=:restart, continuing to next game")
        end

        # Reset for next game
        reset_between_games(table, agent)

      _ ->
        :ok
    end

    send_neutral_controller(bridge)
  end

  defp check_stocks_for_game_end(bridge, _table, game_state, player_port, _agent) do
    # INVARIANTS.md item 5: subject/opponent resolved at the boundary. Before
    # this, a bot seated on port 2 under Slippi Online had its stock-based
    # game-end read off the HUMAN's player.
    agent_player = ExPhil.Bridge.GameState.subject(game_state, player_port)
    opponent = ExPhil.Bridge.GameState.opponent(game_state, player_port)

    agent_stocks = agent_player && agent_player.stock
    opponent_stocks = opponent && opponent.stock

    if agent_stocks == 0 or opponent_stocks == 0 do
      result = if agent_stocks == 0, do: "LOSS", else: "WIN"

      Logger.info(
        "[AsyncRunner:FrameLoop] Game over - #{result} (agent=#{agent_stocks}, opponent=#{opponent_stocks})"
      )

      # Send neutral immediately when game ends
      send_neutral_controller(bridge)

      # The postgame handler will deal with restart vs stop
      # We just mark that we detected the game end via stocks
      # (postgame event from libmelee will follow shortly)
    end
  end

  defp reset_between_games(table, agent) do
    # Clear action (fresh start for next game)
    :ets.insert(table, {:latest_action, nil})
    :ets.insert(table, {:in_game, false})
    :ets.insert(table, {:start_time, nil})

    # Reset agent's temporal buffer for fresh game context
    Agent.reset_buffer(agent)
  end

  defp should_stop?(table) do
    case :ets.lookup(table, :should_stop) do
      [{:should_stop, true}] -> true
      _ -> false
    end
  end

  defp sd_mode?(table) do
    case :ets.lookup(table, :sd_mode) do
      [{:sd_mode, true}] -> true
      _ -> false
    end
  end

  # End-game input schedule: LRAS (L+R+A+Start — instant match quit with a
  # proper Slippi game-end event) for the first @lras_frames, then the
  # legacy hold-left walk-off as fallback. L+R+A are HELD; Start is PULSED
  # (toggled every tick): if the first chord frame pauses instead of
  # quitting, the pause screen needs a FRESH Start edge to complete the
  # quit — a continuous hold never re-edges (measured 2026-07-28). Each
  # toggle lands on its own console.step() flush, so edges arrive every
  # other tick whether ticks come from real frames (60Hz) or paused
  # no-frame polls (~10Hz). Start is send-only in the bridge protocol
  # (melee_bridge.py button_map; deliberately absent from
  # serialize_controller_state to preserve the 13-dim prev-action contract).
  #
  # Training-data filterability: hold-left keeps the pure-left-no-buttons
  # signature; LRAS frames are filtered by A+L+R held with neutral stick
  # (see train_multishine_policy.exs reject clause).
  # Direction #3: tag policy actions with the explicit local delay so the
  # bridge's frame-keyed queue applies them exactly N frames after the
  # state they answered (0/absent = immediate, the pre-queue path).
  defp maybe_tag_local_delay(input, table) do
    case :ets.lookup(table, :local_delay) do
      [{:local_delay, d}] when is_integer(d) and d > 0 -> Map.put(input, :delay, d)
      _ -> input
    end
  end

  # Runtime LRAS window: 0 when the runner was started with lras: false
  # (bridge in blocking dispatch — see the :lras_enabled init comment).
  defp lras_frames(table) do
    case :ets.lookup(table, :lras_enabled) do
      [{:lras_enabled, false}] -> 0
      _ -> @lras_frames
    end
  end

  defp sd_input(player_port, n, lras_frames) when n <= lras_frames do
    %{
      port: player_port,
      main_stick: %{x: 0.5, y: 0.5},
      c_stick: %{x: 0.5, y: 0.5},
      shoulder: 0.0,
      buttons: %{
        a: true,
        b: false,
        x: false,
        y: false,
        z: false,
        l: true,
        r: true,
        d_up: false,
        start: rem(n, 2) == 1
      }
    }
  end

  defp sd_input(player_port, _n, _lras_frames) do
    %{
      port: player_port,
      main_stick: %{x: 0.0, y: 0.5},
      c_stick: %{x: 0.5, y: 0.5},
      shoulder: 0.0,
      buttons: %{a: false, b: false, x: false, y: false, z: false, l: false, r: false, d_up: false}
    }
  end

  # No-frame (paused) variant: past the LRAS window sd_input/3's fallback is
  # hold-left — useless on a PAUSED game (walk-off needs gameplay frames).
  # Pulse Start alone to unpause so the walk-off can act once frames
  # resume. Within the LRAS window the schedule is identical to sd_input/3.
  defp sd_no_frame_input(player_port, n, lras_frames) when n > lras_frames do
    %{
      port: player_port,
      main_stick: %{x: 0.5, y: 0.5},
      c_stick: %{x: 0.5, y: 0.5},
      shoulder: 0.0,
      buttons: %{
        a: false,
        b: false,
        x: false,
        y: false,
        z: false,
        l: false,
        r: false,
        d_up: false,
        start: rem(n, 2) == 1
      }
    }
  end

  defp sd_no_frame_input(player_port, n, lras_frames), do: sd_input(player_port, n, lras_frames)

  # Elixir-driven opponent dummy: read the opponent's state, step the dummy
  # module, route its input to the opponent port. Synchronous with the frame
  # loop, same as the agent's own send.
  defp drive_elixir_dummy(bridge, table, game_state, player_port) do
    case :ets.lookup(table, :elixir_dummy) do
      [{:elixir_dummy, mod, dummy_state}] ->
        # INVARIANTS.md item 5: resolved at the boundary, not flipped.
        opponent_port = ExPhil.Bridge.GameState.opponent_port(game_state, player_port)

        cond do
          # Rich contract (PolicyOpponent, checkpoint ladder): full game
          # state in, decoded %ControllerState{} out — converted by the
          # SAME action_to_input path as the port-1 policy, tagged with
          # the opponent port like the classic dummy send. nil = skip
          # this frame (inference error).
          function_exported?(mod, :step_game, 3) ->
            {controller, dummy_state} = mod.step_game(game_state, opponent_port, dummy_state)

            if controller do
              input = controller |> action_to_input(opponent_port) |> Map.put(:port, opponent_port)
              MeleePort.send_controller(bridge, input)
            end

            :ets.insert(table, {:elixir_dummy, mod, dummy_state})

          true ->
            opponent = game_state.players && game_state.players[opponent_port]
            bot = ExPhil.Bridge.GameState.subject(game_state, player_port)

            {input, dummy_state} = mod.step(opponent, bot, dummy_state)
            MeleePort.send_controller(bridge, Map.put(input, :port, opponent_port))
            :ets.insert(table, {:elixir_dummy, mod, dummy_state})
        end

      _ ->
        :ok
    end
  end

  defp in_game?(table) do
    case :ets.lookup(table, :in_game) do
      [{:in_game, true}] -> true
      _ -> false
    end
  end

  # ============================================================================
  # Inference Loop (runs in separate process, slow is OK)
  # ============================================================================

  # INVARIANTS.md item 6 (2026-09-09): FRAME-DRIVEN. The loop registers its
  # pid, then blocks until the frame loop sends :new_frame; a backlog of
  # wakeups is coalesced so at most ONE decision runs per new frame. Before
  # this it spin-polled the ETS table (~2 calls/frame live, 31 headless),
  # relying on the agent's same-frame cache to re-send the last action and
  # diluting the confidence stats 30x with cached returns.
  defp inference_loop(agent, table, player_port) do
    :ets.insert(table, {:inference_pid, self()})
    inference_loop_wait(agent, table, player_port)
  end

  defp inference_loop_wait(agent, table, player_port) do
    receive do
      :new_frame ->
        flush_new_frames()
        inference_step(agent, table, player_port)
        inference_loop_wait(agent, table, player_port)
    after
      250 ->
        # No frame in 250ms: check for shutdown, otherwise keep waiting.
        if should_stop?(table) do
          Logger.info("[AsyncRunner:Inference] Stop requested, exiting")
          :ok
        else
          inference_loop_wait(agent, table, player_port)
        end
    end
  end

  # Coalesce: if several frames arrived while we were deciding, decide once
  # on the NEWEST state (the ETS row), never once per stale wakeup.
  defp flush_new_frames do
    receive do
      :new_frame -> flush_new_frames()
    after
      0 -> :ok
    end
  end

  defp inference_step(agent, table, player_port) do
    case should_stop?(table) do
      true ->
        :ok

      false ->
        # Get latest game state
        case :ets.lookup(table, :latest_game_state) do
          [{:latest_game_state, nil}] ->
            :ok

          [{:latest_game_state, game_state}] ->
            # Check if we're in game
            case :ets.lookup(table, :in_game) do
              [{:in_game, true}] ->
                # Run inference with confidence. Must use the controller API:
                # the raw action map holds bucket INDICES (0..axis_buckets),
                # not analog values — sending those to libmelee clamps the
                # sticks to full deflection (the "drifts right forever" bug).
                case Agent.get_controller_with_confidence(agent, game_state,
                       player_port: player_port,
                       # Long timeout: the first call can queue behind a
                       # backgrounded JIT warmup (~20s idle GPU, minutes
                       # loaded). The frame reader is a separate process, so
                       # a slow inference degrades to stale-action stats —
                       # never crash the session over it.
                       timeout: 120_000
                     ) do
                  {:ok, controller, confidence} ->
                    :ets.insert(table, {:latest_action, controller})
                    :ets.insert(table, {:latest_confidence, confidence})
                    :ets.update_counter(table, :inference_count, 1)
                    # Update running sum for average
                    overall_conf = Map.get(confidence, :overall, 0)
                    [{:confidence_sum, old_sum}] = :ets.lookup(table, :confidence_sum)
                    :ets.insert(table, {:confidence_sum, old_sum + overall_conf})

                  {:error, reason} ->
                    Logger.warning("[AsyncRunner:Inference] Error: #{inspect(reason)}")
                end

              _ ->
                # Not in game: nothing to decide for this frame.
                :ok
            end
        end
    end
  end

  # ============================================================================
  # Helpers
  # ============================================================================

  # Convert a fully-decoded ControllerState (sticks/shoulder undiscretized to
  # 0..1, buttons boolean — see Networks.Policy.to_controller_state/2) into
  # the bridge input map. Intentionally accepts ONLY %ControllerState{}: raw
  # action maps carry bucket indices and must never reach the bridge.
  defp action_to_input(%ExPhil.Bridge.ControllerState{} = cs, _player_port) do
    %{
      main_stick: %{x: cs.main_stick.x, y: cs.main_stick.y},
      c_stick: %{x: cs.c_stick.x, y: cs.c_stick.y},
      shoulder: cs.l_shoulder + cs.r_shoulder,
      buttons: %{
        a: cs.button_a,
        b: cs.button_b,
        x: cs.button_x,
        y: cs.button_y,
        z: cs.button_z,
        l: cs.button_l,
        r: cs.button_r,
        d_up: cs.button_d_up
      }
    }
  end

  # Send neutral controller state (all centered, no buttons)
  defp send_neutral_controller(bridge) do
    neutral = %{
      main_stick: %{x: 0.5, y: 0.5},
      c_stick: %{x: 0.5, y: 0.5},
      shoulder: 0.0,
      buttons: %{
        a: false,
        b: false,
        x: false,
        y: false,
        z: false,
        l: false,
        r: false,
        d_up: false
      }
    }

    MeleePort.send_controller(bridge, neutral)
  end
end
