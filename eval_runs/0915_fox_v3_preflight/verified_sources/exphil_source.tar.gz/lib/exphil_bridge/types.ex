defmodule ExPhil.Bridge.GameState do
  @moduledoc """
  Represents the full game state from libmelee.

  This struct mirrors the data from `melee.GameState` in Python.
  """

  @type t :: %__MODULE__{
          frame: integer(),
          stage: integer(),
          menu_state: integer(),
          players: %{integer() => ExPhil.Bridge.Player.t()},
          # Netplay only (nil offline): the bot's ACTUAL in-game port,
          # detected bridge-side via connect codes. Slippi assigns ports
          # per session, so the configured --port is only a guess there.
          own_port: integer() | nil,
          projectiles: [ExPhil.Bridge.Projectile.t()],
          items: [ExPhil.Bridge.Item.t()],
          distance: float(),
          fod_platform_left: float() | nil,
          fod_platform_right: float() | nil,
          stadium_event: integer() | nil,
          stadium_type: integer() | nil
        }

  defstruct [
    :frame,
    :stage,
    :menu_state,
    :players,
    :own_port,
    :projectiles,
    :items,
    :distance,
    # Stage events (Slippi spec >= 3.18, task #3; nil on older replays
    # and on the live bridge until it forwards them): FoD side-platform
    # heights (persist between events) and the PS transformation state
    :fod_platform_left,
    :fod_platform_right,
    :stadium_event,
    :stadium_type,
    :whispy_direction
  ]

  @doc """
  Check if the game is in an active game state (not in menus).
  """
  def in_game?(%__MODULE__{menu_state: menu_state}) do
    # Menu.IN_GAME = 2, Menu.SUDDEN_DEATH = 3
    menu_state in [2, 3]
  end

  @doc """
  Get player by port number.
  """
  def get_player(%__MODULE__{players: players}, port) when is_integer(port) do
    Map.get(players, port)
  end

  @doc """
  Get both players as {p1, p2} tuple.
  """
  def get_players(%__MODULE__{players: players}) do
    {Map.get(players, 1), Map.get(players, 2)}
  end

  # ---------------------------------------------------------------------------
  # INVARIANTS.md item 5: ports exist only at the parse/bridge boundary.
  # Downstream code asks for the SUBJECT and the OPPONENT; the port numbers
  # behind them are resolved HERE, once: the bridge stamps `own_port` under
  # Slippi Online (connect-code detection), the training path remaps the
  # subject to port 1, and the opponent is "the other occupied port" — never
  # `if port == 1, do: 2, else: 1`, which silently zeroes the opponent on
  # ports 2+3 / 1+4 seats.
  # ---------------------------------------------------------------------------

  @doc "The subject's port: the stamped `own_port`, else `fallback` (the configured/remapped port)."
  @spec subject_port(t(), pos_integer()) :: pos_integer()
  def subject_port(%__MODULE__{} = gs, fallback \\ 1) do
    case Map.get(gs, :own_port) do
      p when is_integer(p) and p > 0 -> p
      _ -> fallback
    end
  end

  @doc """
  The opponent's port: the other OCCUPIED port. With exactly one other
  player that is unambiguous; with none (single-player replay) or several
  (teams) it falls back to the 1<->2 flip, the historical convention for
  those edge cases.
  """
  @spec opponent_port(t(), pos_integer()) :: pos_integer()
  def opponent_port(%__MODULE__{players: players} = gs, fallback \\ 1) do
    subject = subject_port(gs, fallback)

    case (players || %{}) |> Map.keys() |> Enum.reject(&(&1 == subject)) do
      [other] -> other
      _ -> if subject == 1, do: 2, else: 1
    end
  end

  @doc "The subject player (nil if absent)."
  @spec subject(t(), pos_integer()) :: map() | nil
  def subject(%__MODULE__{} = gs, fallback \\ 1), do: get_player(gs, subject_port(gs, fallback))

  @doc "The opponent player (nil if absent)."
  @spec opponent(t(), pos_integer()) :: map() | nil
  def opponent(%__MODULE__{} = gs, fallback \\ 1), do: get_player(gs, opponent_port(gs, fallback))
end

defmodule ExPhil.Bridge.Player do
  @moduledoc """
  Represents a player's state from libmelee.

  Mirrors `melee.PlayerState` from Python.
  """

  @type t :: %__MODULE__{
          character: integer(),
          x: float(),
          y: float(),
          percent: float(),
          stock: integer(),
          facing: integer(),
          action: integer(),
          action_frame: integer(),
          invulnerable: boolean(),
          jumps_left: integer(),
          on_ground: boolean(),
          shield_strength: float(),
          hitstun_frames_left: integer(),
          speed_air_x_self: float(),
          speed_ground_x_self: float(),
          speed_y_self: float(),
          speed_x_attack: float(),
          speed_y_attack: float(),
          nana: ExPhil.Bridge.Nana.t() | nil,
          controller_state: ExPhil.Bridge.ControllerState.t() | nil,
          # Slippi Online connect code ("EXPH#288"); "" or nil offline
          connect_code: String.t() | nil,
          # In-game Melee nametag (e.g. "EXPH"), recorded in the replay's
          # GAME_START. "" when no tag is selected. Netplay games are
          # identified by connect_code instead.
          nametag: String.t()
        }

  defstruct [
    :character,
    :x,
    :y,
    :percent,
    :stock,
    :facing,
    :action,
    :action_frame,
    :invulnerable,
    :jumps_left,
    :on_ground,
    :shield_strength,
    :hitstun_frames_left,
    :speed_air_x_self,
    :speed_ground_x_self,
    :speed_y_self,
    :speed_x_attack,
    :speed_y_attack,
    :nana,
    :controller_state,
    :connect_code,
    :nametag
  ]

  @doc """
  Check if player is currently dying.
  """
  def dying?(%__MODULE__{action: action}) when is_integer(action) do
    action <= 0x0A
  end

  def dying?(_), do: false

  @doc """
  Check if player is offstage.
  """
  def offstage?(%__MODULE__{x: x, y: y}, stage_edge_x \\ 85.0) do
    abs(x) > stage_edge_x or y < 0
  end

  @doc """
  Check if player is in hitstun.
  """
  def in_hitstun?(%__MODULE__{hitstun_frames_left: frames}) when is_integer(frames) do
    frames > 0
  end

  def in_hitstun?(_), do: false

  @doc """
  Check if player is shielding.
  """
  def shielding?(%__MODULE__{action: action}) when is_integer(action) do
    # Action.SHIELD_START = 178, SHIELD = 179, SHIELD_RELEASE = 180
    action in [178, 179, 180]
  end

  def shielding?(_), do: false
end

defmodule ExPhil.Bridge.Nana do
  @moduledoc """
  Represents Nana (Ice Climbers partner) state.
  """

  @type t :: %__MODULE__{
          x: float(),
          y: float(),
          percent: float(),
          stock: integer(),
          action: integer(),
          facing: integer()
        }

  defstruct [:x, :y, :percent, :stock, :action, :facing]
end

defmodule ExPhil.Bridge.ControllerState do
  @moduledoc """
  Represents the controller state for a player.

  Used for imitation learning - captures what buttons/sticks
  a player is pressing at a given frame.
  """

  @type t :: %__MODULE__{
          main_stick: %{x: float(), y: float()},
          c_stick: %{x: float(), y: float()},
          l_shoulder: float(),
          r_shoulder: float(),
          button_a: boolean(),
          button_b: boolean(),
          button_x: boolean(),
          button_y: boolean(),
          button_z: boolean(),
          button_l: boolean(),
          button_r: boolean(),
          button_d_up: boolean()
        }

  defstruct [
    :main_stick,
    :c_stick,
    :l_shoulder,
    :r_shoulder,
    :button_a,
    :button_b,
    :button_x,
    :button_y,
    :button_z,
    :button_l,
    :button_r,
    :button_d_up
  ]

  @doc """
  Create a neutral controller state (no buttons pressed, sticks centered).
  """
  def neutral do
    %__MODULE__{
      main_stick: %{x: 0.5, y: 0.5},
      c_stick: %{x: 0.5, y: 0.5},
      l_shoulder: 0.0,
      r_shoulder: 0.0,
      button_a: false,
      button_b: false,
      button_x: false,
      button_y: false,
      button_z: false,
      button_l: false,
      button_r: false,
      button_d_up: false
    }
  end

  @doc """
  Convert to input format expected by MeleePort.send_controller/2.
  """
  def to_input(%__MODULE__{} = cs) do
    %{
      main_stick: cs.main_stick,
      c_stick: cs.c_stick,
      shoulder: cs.l_shoulder,
      buttons: %{
        a: cs.button_a,
        b: cs.button_b,
        x: cs.button_x,
        y: cs.button_y,
        z: cs.button_z,
        l: cs.button_l,
        r: cs.button_r,
        d_up: cs.button_d_up
      }
    }
  end

  @doc """
  Inverse of `to_input/1`: build a ControllerState from a bridge input map
  (the shape `MeleePort.send_controller/2` accepts, and the shape replay
  prefixes are recorded in). Missing buttons read as released; the single
  `shoulder` value lands on the L trigger. Used by observe-only warm-ups
  that feed a RECORDED input back into an Agent as if it had issued it
  (closed-loop correction validation, 2026-09-12).
  """
  def from_input(%{} = input) do
    buttons = Map.get(input, :buttons) || %{}
    ms = Map.get(input, :main_stick) || %{x: 0.5, y: 0.5}
    cs = Map.get(input, :c_stick) || %{x: 0.5, y: 0.5}

    %__MODULE__{
      main_stick: %{x: ms.x * 1.0, y: ms.y * 1.0},
      c_stick: %{x: cs.x * 1.0, y: cs.y * 1.0},
      l_shoulder: (Map.get(input, :shoulder) || 0.0) * 1.0,
      r_shoulder: 0.0,
      button_a: Map.get(buttons, :a) == true,
      button_b: Map.get(buttons, :b) == true,
      button_x: Map.get(buttons, :x) == true,
      button_y: Map.get(buttons, :y) == true,
      button_z: Map.get(buttons, :z) == true,
      button_l: Map.get(buttons, :l) == true,
      button_r: Map.get(buttons, :r) == true,
      button_d_up: Map.get(buttons, :d_up) == true
    }
  end
end

defmodule ExPhil.Bridge.Projectile do
  @moduledoc """
  Represents a projectile in the game (fireballs, arrows, bombs, etc.).
  """

  @type t :: %__MODULE__{
          owner: integer(),
          x: float(),
          y: float(),
          type: integer(),
          subtype: integer(),
          speed_x: float(),
          speed_y: float()
        }

  defstruct [:owner, :x, :y, :type, :subtype, :speed_x, :speed_y]
end

defmodule ExPhil.Bridge.Item do
  @moduledoc """
  Represents an item in the game (bombs, capsules, barrels, etc.).

  Items differ from projectiles:
  - Items can be held, thrown, or on the ground
  - Items have a spawn timer and lifetime
  - Items can damage their owner (e.g., Link's bombs)

  ## Item Types (common ones for target characters)

  Link-specific:
  - Bomb: Can be pulled, held, thrown, and deals self-damage

  Common items:
  - Capsule, Barrel, Crate: Container items
  - Beam Sword, Bat, Fan: Melee weapons
  - Ray Gun, Super Scope: Projectile weapons
  """

  @type t :: %__MODULE__{
          x: float(),
          y: float(),
          type: integer(),
          facing: integer(),
          owner: integer() | nil,
          held_by: integer() | nil,
          spawn_id: integer(),
          timer: integer()
        }

  defstruct [
    :x,
    :y,
    :type,
    :facing,
    :owner,
    :held_by,
    :spawn_id,
    :timer
  ]

  # Common item type constants (from libmelee)
  @item_types %{
    # Explosives/Bombs
    # Link's bomb
    link_bomb: 0x2C,
    # Young Link's bomb
    young_link_bomb: 0x2D,
    # Bob-omb
    bob_omb: 0x13,

    # Character-specific thrown items
    # Peach's turnip (50)
    peach_turnip: 0x32,
    # Mr. Saturn (21)
    mr_saturn: 0x15,

    # Melee weapons
    # Beam Sword
    beam_sword: 0x04,
    # Home Run Bat
    home_run_bat: 0x05,
    # Fan
    fan: 0x06,

    # Ranged weapons
    # Ray Gun
    ray_gun: 0x08,
    # Super Scope
    super_scope: 0x09,

    # Containers
    # Capsule
    capsule: 0x00,
    # Crate
    crate: 0x01,
    # Barrel
    barrel: 0x02
  }

  @doc """
  Check if item is a bomb (Link/Young Link).
  """
  def bomb?(%__MODULE__{type: type}) do
    type in [@item_types.link_bomb, @item_types.young_link_bomb, @item_types.bob_omb]
  end

  def bomb?(_), do: false

  @doc """
  Check if item is a Peach turnip.
  """
  def turnip?(%__MODULE__{type: type}), do: type == @item_types.peach_turnip
  def turnip?(_), do: false

  @doc """
  Check if item is Mr. Saturn.
  """
  def mr_saturn?(%__MODULE__{type: type}), do: type == @item_types.mr_saturn
  def mr_saturn?(_), do: false

  @doc """
  Check if item is currently held by a player.
  """
  def held?(%__MODULE__{held_by: held_by}) when is_integer(held_by) and held_by > 0, do: true
  def held?(_), do: false

  @doc """
  Check if item belongs to given player.
  """
  def owned_by?(%__MODULE__{owner: owner}, player_port) when is_integer(player_port) do
    owner == player_port
  end

  def owned_by?(_, _), do: false

  @doc """
  Get normalized item type for embedding.

  Returns a simplified category:
  - 0: None/unknown
  - 1: Bomb (Link, Young Link, Bob-omb)
  - 2: Melee weapon (Beam Sword, Bat, Fan)
  - 3: Ranged weapon (Ray Gun, Super Scope)
  - 4: Container (Capsule, Crate, Barrel)
  - 5: Thrown/Character-specific (Peach turnip, Mr. Saturn, etc.)
  """
  def item_category(%__MODULE__{type: type}) do
    cond do
      type in [@item_types.link_bomb, @item_types.young_link_bomb, @item_types.bob_omb] -> 1
      type in [@item_types.beam_sword, @item_types.home_run_bat, @item_types.fan] -> 2
      type in [@item_types.ray_gun, @item_types.super_scope] -> 3
      type in [@item_types.capsule, @item_types.crate, @item_types.barrel] -> 4
      type in [@item_types.peach_turnip, @item_types.mr_saturn] -> 5
      # Unknown items fall into "other/thrown" category
      true -> 5
    end
  end

  def item_category(_), do: 0
end

defmodule ExPhil.Bridge.ControllerInput do
  @moduledoc """
  Helper module for creating controller inputs to send to the game.
  """

  @doc """
  Create a neutral input (no buttons, sticks centered).
  """
  def neutral do
    %{
      main_stick: %{x: 0.5, y: 0.5},
      c_stick: %{x: 0.5, y: 0.5},
      shoulder: 0.0,
      buttons: %{}
    }
  end

  @doc """
  Create input with main stick direction.
  """
  def main_stick(x, y) when is_number(x) and is_number(y) do
    %{neutral() | main_stick: %{x: clamp(x), y: clamp(y)}}
  end

  @doc """
  Create input with a button press.
  """
  def button(button) when button in [:a, :b, :x, :y, :z, :l, :r, :d_up] do
    %{neutral() | buttons: %{button => true}}
  end

  @doc """
  Combine multiple inputs (later inputs override earlier ones).
  """
  def combine(inputs) when is_list(inputs) do
    Enum.reduce(inputs, neutral(), fn input, acc ->
      acc
      |> Map.merge(input, fn
        :buttons, b1, b2 -> Map.merge(b1, b2)
        _key, _v1, v2 -> v2
      end)
    end)
  end

  # Common moves

  @doc "Jump (X button)"
  def jump, do: button(:x)

  @doc "Short hop (tap Y quickly)"
  def short_hop, do: button(:y)

  @doc "A attack"
  def a, do: button(:a)

  @doc "B special"
  def b, do: button(:b)

  @doc "Shield (L button)"
  def shield, do: %{neutral() | shoulder: 1.0, buttons: %{l: true}}

  @doc "Grab (Z button)"
  def grab, do: button(:z)

  @doc "Move left"
  def left, do: main_stick(0.0, 0.5)

  @doc "Move right"
  def right, do: main_stick(1.0, 0.5)

  @doc "Crouch"
  def crouch, do: main_stick(0.5, 0.0)

  @doc "Up tilt"
  def up_tilt, do: combine([main_stick(0.5, 0.7), button(:a)])

  @doc "Down tilt"
  def down_tilt, do: combine([main_stick(0.5, 0.3), button(:a)])

  @doc "Forward tilt (right)"
  def forward_tilt_right, do: combine([main_stick(0.7, 0.5), button(:a)])

  @doc "Forward tilt (left)"
  def forward_tilt_left, do: combine([main_stick(0.3, 0.5), button(:a)])

  @doc "Up smash"
  def up_smash, do: %{neutral() | c_stick: %{x: 0.5, y: 1.0}}

  @doc "Down smash"
  def down_smash, do: %{neutral() | c_stick: %{x: 0.5, y: 0.0}}

  @doc "Forward smash (right)"
  def forward_smash_right, do: %{neutral() | c_stick: %{x: 1.0, y: 0.5}}

  @doc "Forward smash (left)"
  def forward_smash_left, do: %{neutral() | c_stick: %{x: 0.0, y: 0.5}}

  defp clamp(v), do: max(0.0, min(1.0, v))
end
