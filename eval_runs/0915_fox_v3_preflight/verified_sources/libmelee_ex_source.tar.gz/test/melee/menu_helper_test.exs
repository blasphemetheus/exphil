defmodule Melee.MenuHelperTest do
  use ExUnit.Case, async: true

  alias Melee.{Controller, GameState, MenuHelper, PlayerState, Position}

  doctest Melee.MenuHelper

  @scratch System.tmp_dir!()

  # Menu wire values
  @character_select 0
  @stage_select 1
  @in_game 2
  @postgame_scores 4
  @main_menu 5
  @slippi_online_css 6
  @press_start 7

  @fox 0x01
  @fd 0x19

  @release_all "RELEASE A\nRELEASE B\nRELEASE X\nRELEASE Y\nRELEASE Z\n" <>
                 "RELEASE L\nRELEASE R\nRELEASE START\nRELEASE D_UP\n" <>
                 "RELEASE D_DOWN\nRELEASE D_LEFT\nRELEASE D_RIGHT\n" <>
                 "SET MAIN .5 .5\nSET C .5 .5\nSET L 0\nSET R 0\n"

  # A controller writing to a regular file: same code path as the fifo,
  # but the written command stream can be read back deterministically.
  defp file_controller(ctx) do
    path = Path.join(@scratch, "melee_menu_#{:erlang.phash2(ctx.test)}")
    File.rm(path)
    {:ok, pid} = Controller.start_link(pipe_path: path)
    :ok = Controller.connect(pid)
    {pid, path}
  end

  # Run one step and return {new_state, commands written this frame}.
  # Flushing (a GenServer call) serializes all the step's casts first.
  defp step_frame(state, gs, pid, path, opts) do
    before = byte_size(File.read!(path))
    state = MenuHelper.step(state, gs, pid, opts)
    :ok = Controller.flush(pid)
    content = File.read!(path)

    wrote =
      content
      |> binary_part(before, byte_size(content) - before)
      |> String.replace_suffix("FLUSH\n", "")

    {state, wrote}
  end

  defp set_main(x, y) do
    "SET MAIN #{Float.to_string(Controller.fix_analog_stick(x))} " <>
      "#{Float.to_string(Controller.fix_analog_stick(y))}\n"
  end

  # Mirrors MenuHelper's proportional steering (steer_toward/6): the
  # expected SET MAIN write for a hand at (cx, cy) heading straight for
  # (tx, ty). An axis already inside `tolerance` contributes nothing;
  # magnitude eases to the fine tilt inside 3 units.
  defp steer_main(cx, cy, tx, ty, opts \\ []) do
    tolerance = Keyword.get(opts, :tolerance, 1.5)
    max_tilt = Keyword.get(opts, :max_tilt, 0.5)

    dx = if abs(tx - cx) <= tolerance, do: 0.0, else: tx - cx
    dy = if abs(ty - cy) <= tolerance, do: 0.0, else: ty - cy
    dist = :math.sqrt(dx * dx + dy * dy)
    scale = max(abs(dx), abs(dy))
    mag = min(if(dist > 3.0, do: 0.5, else: 0.22), max_tilt)

    set_main(0.5 + mag * dx / scale, 0.5 + mag * dy / scale)
  end

  # The (scaled) components of the last SET MAIN in `wrote`, for
  # directional assertions against `stick_center()`.
  defp main_dir(wrote) do
    [x, y] =
      ~r/SET MAIN ([\d.]+) ([\d.]+)/
      |> Regex.scan(wrote)
      |> List.last()
      |> tl()
      |> Enum.map(&String.to_float/1)

    {x, y}
  end

  defp stick_center, do: Controller.fix_analog_stick(0.5)

  defp gs(attrs), do: struct!(GameState, attrs)
  defp player(attrs), do: struct!(PlayerState, attrs)
  defp cursor(x, y), do: %Position{x: x * 1.0, y: y * 1.0}

  defp base_opts(extra \\ []), do: Keyword.merge([character: @fox, stage: @fd], extra)

  describe "press start scene" do
    test "START pulses on odd frames, release_all on even", ctx do
      {pid, path} = file_controller(ctx)
      state = MenuHelper.new()

      {state, wrote} =
        step_frame(state, gs(menu_state: @press_start, frame: 1), pid, path, base_opts())

      assert wrote == "PRESS START\n"

      {_state, wrote} =
        step_frame(state, gs(menu_state: @press_start, frame: 2), pid, path, base_opts())

      assert wrote == @release_all
    end

    test "with a connect code, still pulses START", ctx do
      {pid, path} = file_controller(ctx)

      {_state, wrote} =
        step_frame(
          MenuHelper.new(),
          gs(menu_state: @press_start, frame: 3),
          pid,
          path,
          base_opts(connect_code: "FOX#123")
        )

      assert wrote == "PRESS START\n"
    end
  end

  describe "character select" do
    # Fox external id 0x0A: row 1, column 1 -> target (-22.0, 11.5)

    test "cursor moves down toward Fox when too high", ctx do
      {pid, path} = file_controller(ctx)
      players = %{1 => player(cursor: cursor(-22, 25))}
      gamestate = gs(menu_state: @character_select, frame: 1, players: players)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == "RELEASE START\nRELEASE A\n" <> set_main(0.5, 0.0)
    end

    test "cursor moves right toward Fox when too left", ctx do
      {pid, path} = file_controller(ctx)
      players = %{1 => player(cursor: cursor(-40, 11.5))}
      gamestate = gs(menu_state: @character_select, frame: 1, players: players)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == "RELEASE START\nRELEASE A\n" <> set_main(1.0, 0.5)
    end

    test "presses A when over the target AND the game's hover confirms it", ctx do
      {pid, path} = file_controller(ctx)
      # The hover byte (`character`) must read the target: pressing A on
      # position alone ping-ponged live (portrait hitboxes don't fill
      # the grid cell — Roy's corner read as LINK).
      players = %{1 => player(cursor: cursor(-22, 11.5), character: @fox)}
      gamestate = gs(menu_state: @character_select, frame: 1, players: players)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == "RELEASE START\n" <> set_main(0.5, 0.5) <> "PRESS A\n"
    end

    test "in-band but hover elsewhere: tightens to center instead of pressing A", ctx do
      {pid, path} = file_controller(ctx)
      # In wiggleroom of Fox's portrait (-22, 11.5) but the game reads
      # the hand as hovering nothing (0xFF) — no A press; steer closer.
      players = %{1 => player(cursor: cursor(-21.0, 12.4), character: 0xFF)}
      gamestate = gs(menu_state: @character_select, frame: 1, players: players)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      refute wrote =~ "PRESS A"
      assert wrote =~ "SET MAIN"
    end

    test "releases all when our port has no player", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = gs(menu_state: @character_select, frame: 1, players: %{})

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == @release_all
    end
  end

  describe "ready to start" do
    defp selected_fox_gs(attrs) do
      players = %{1 => player(character: @fox, coin_down: true, cursor: cursor(-22, 11.5))}

      gs(Keyword.merge([menu_state: @character_select, players: players], attrs))
    end

    test "autostart presses START on odd frames once ready", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = selected_fox_gs(frame: 1, ready_to_start: true)

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(autostart: true))

      assert wrote == "PRESS START\n"
    end

    test "autostart releases all on even frames", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = selected_fox_gs(frame: 2, ready_to_start: true)

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(autostart: true))

      assert wrote == @release_all
    end

    test "no START without autostart", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = selected_fox_gs(frame: 1, ready_to_start: true)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == @release_all
      refute wrote =~ "PRESS START"
    end
  end

  describe "stage select" do
    defp stage_gs(attrs) do
      cursor = Keyword.get(attrs, :cursor, cursor(0, 0))
      players = %{1 => player(cursor: cursor)}

      gs(
        Keyword.merge(
          [menu_state: @stage_select, players: players],
          Keyword.delete(attrs, :cursor)
        )
      )
    end

    test "cursor moves toward Final Destination's coordinates", ctx do
      {pid, path} = file_controller(ctx)
      # FD target is (6.7, -9); from (0, 0) the hand takes the direct
      # diagonal (down-right), not the old y-then-x L
      gamestate = stage_gs(frame: 25, cursor: cursor(0, 0))

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(autostart: true))

      assert wrote == steer_main(0, 0, 6.7, -9) <> "RELEASE A\n"
    end

    test "pick press is debounced: no second A while the readback settles", ctx do
      {pid, path} = file_controller(ctx)
      # Hovering fox (correct_character), coin not yet down: first
      # frame presses A...
      players = %{1 => player(cursor: cursor(-22.3, 11.5), character: @fox)}
      gamestate = gs(menu_state: 0, frame: 1, players: players)

      {state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())
      assert wrote =~ "PRESS A\n"
      assert state.css_press_cooldown > 0

      # ...and with coin_down STILL false (readback settling), the next
      # press frames do NOT re-press — the metastable
      # select/deselect loop (2026-08-23 live, both ports).
      {state, wrote} = step_frame(state, gs(menu_state: 0, frame: 3, players: players), pid, path, base_opts())
      refute wrote =~ "PRESS A\n"

      # Cooldown expired and coin still not down: allowed to try again.
      state = %{state | css_press_cooldown: 0}
      {_state, wrote} = step_frame(state, gs(menu_state: 0, frame: 5, players: players), pid, path, base_opts())
      assert wrote =~ "PRESS A\n"
    end

    test "frozen cursor in the fine zone triggers a full-tilt unstick burst", ctx do
      {pid, path} = file_controller(ctx)
      # Just outside FD's 1.5 tolerance (dy = -2.2): fine-tilt zone,
      # the 2026-08-23 live wedge position ("below Battlefield").
      gamestate = stage_gs(frame: 25, cursor: cursor(6.7, -6.8))
      opts = base_opts(autostart: true)

      # Wire y value of the SET MAIN line (post fix_analog_stick).
      wire_y = fn wrote ->
        [_, y] = Regex.run(~r/SET MAIN [\d.]+ ([\d.]+)/, wrote)
        String.to_float(y)
      end

      # Same cursor two frames running: stall counts up, tilt stays
      # FINE (0.22 raw — wire y well above the full-tilt value).
      {state, _} = step_frame(MenuHelper.new(), gamestate, pid, path, opts)
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert state.sss_stall_frames == 1
      fine_y = wire_y.(wrote)

      # Stall budget reached: burst arms...
      state = %{state | sss_stall_frames: 45}
      {state, _} = step_frame(state, gamestate, pid, path, opts)
      assert state.sss_burst_frames == 12
      assert state.sss_stall_frames == 0

      # ...and the next frame steers at FULL tilt: wire y strictly
      # below the fine-tilt wire value (more downward deflection).
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert state.sss_burst_frames == 11
      assert wire_y.(wrote) < fine_y - 0.1

      # Movement resets the stall counter.
      moved = stage_gs(frame: 25, cursor: cursor(6.7, -7.4))
      {state, _} = step_frame(state, moved, pid, path, opts)
      assert state.sss_stall_frames == 0
    end

    test "cursor moves right when left of the stage", ctx do
      {pid, path} = file_controller(ctx)
      # y already inside tolerance -> pure rightward tilt
      gamestate = stage_gs(frame: 25, cursor: cursor(0, -9))

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(autostart: true))

      assert wrote == steer_main(0, -9, 6.7, -9) <> "RELEASE A\n"
      assert steer_main(0, -9, 6.7, -9) == set_main(1.0, 0.5)
    end

    test "presses A over the stage and records selection", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = stage_gs(frame: 25, cursor: cursor(6.7, -9))
      opts = base_opts(autostart: true, frozen_stadium: false)

      {state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, opts)

      assert wrote == set_main(0.5, 0.5) <> "PRESS A\n"
      assert state.stage_selected

      # After selection, subsequent frames just release
      {_state, wrote} = step_frame(state, stage_gs(frame: 26), pid, path, opts)
      assert wrote == @release_all
    end

    test "without autostart, does not navigate", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = stage_gs(frame: 25, cursor: cursor(0, 0))

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == @release_all
    end

    test "frame 0 resets stage_selected", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | stage_selected: true}
      gamestate = stage_gs(frame: 0, cursor: cursor(0, 0))

      {state, _wrote} =
        step_frame(state, gamestate, pid, path, base_opts(autostart: true))

      refute state.stage_selected
    end

    # @fd is not Stadium, so frozen_stadium: true must NOT trigger the
    # toggle wait — the hand presses A immediately on arrival (the
    # 60-frame idle on every stage was the 2026-08-09 waste).
    test "non-Stadium stage selects immediately even with frozen_stadium on", ctx do
      {pid, path} = file_controller(ctx)
      # FD target (6.7, -9); arrive there, frozen_stadium defaults true.
      gamestate = stage_gs(frame: 25, cursor: cursor(6.7, -9))

      {state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(autostart: true))

      assert wrote == set_main(0.5, 0.5) <> "PRESS A\n"
      assert state.stage_selected
    end

    test "Stadium runs a brief Z-toggle then selects (no 60-frame wait)", ctx do
      {pid, path} = file_controller(ctx)
      # Pokémon Stadium internal id 0x12, cursor target (15, 3.5).
      opts = base_opts(autostart: true, stage: 0x12, frozen_stadium: true)
      at_stadium = fn frame -> stage_gs(frame: frame, cursor: cursor(15, 3.5)) end

      # Drive from arrival; frames_on_stage increments each step.
      {state, _} = step_frame(MenuHelper.new(), at_stadium.(20), pid, path, opts)
      # frame 2 on the stage: Z press edge
      state =
        Enum.reduce(21..21, state, fn f, s ->
          {s, wrote} = step_frame(s, at_stadium.(f), pid, path, opts)
          assert wrote =~ "PRESS Z"
          s
        end)

      # Runs out the short settle, then selects with A — well under 60f.
      {state, wrote} =
        Enum.reduce(22..30, {state, ""}, fn f, {s, _} ->
          step_frame(s, at_stadium.(f), pid, path, opts)
        end)

      assert state.stage_selected
      assert wrote =~ "PRESS A" or state.frozen_stadium_selected
    end
  end

  describe "CPU level configuration" do
    # The state machine: walk to the HMN/CPU box, press A, walk to the
    # slider, grab it, drag to the wanted level, release. We simulate the
    # gamestate changes each press would cause.
    defp cpu_gs(frame, player_attrs) do
      base = [character: @fox, coin_down: true]

      gs(
        menu_state: @character_select,
        frame: frame,
        players: %{1 => player(Keyword.merge(base, player_attrs))}
      )
    end

    test "full flip-to-CPU and slider-drag sequence", ctx do
      {pid, path} = file_controller(ctx)
      opts = base_opts(cpu_level: 3)
      state = MenuHelper.new()

      # 1. Human status, wrong cpu_level: walk down to the HMN/CPU box
      gamestate = cpu_gs(2, controller_status: 0, cpu_level: 0, cursor: cursor(-32.2, 10))
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == "RELEASE A\n" <> set_main(0.5, 0.0)

      # 2. Over the box, even frame: press A (flips HMN -> CPU).
      # steer_toward centers the stick the frame it arrives.
      gamestate = cpu_gs(2, controller_status: 0, cpu_level: 0, cursor: cursor(-32.2, -2.2))
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == "RELEASE A\n" <> set_main(0.5, 0.5) <> "PRESS A\n"

      # 3. Over the box, odd frame: let go (the alternating press)
      gamestate = cpu_gs(3, controller_status: 0, cpu_level: 0, cursor: cursor(-32.2, -2.2))
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == "RELEASE A\n" <> set_main(0.5, 0.5) <> @release_all

      # 4. Now CPU status but wrong level: walk toward the slider along
      # the diagonal, capped at the gentle 0.3 approach tilt
      gamestate = cpu_gs(2, controller_status: 1, cpu_level: 1, cursor: cursor(-32.2, -2.2))
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == steer_main(-32.2, -2.2, -30.9, -15.12, tolerance: 1, max_tilt: 0.3)

      # 5. Over the slider, even frame: press A to grab it
      gamestate = cpu_gs(2, controller_status: 1, cpu_level: 1, cursor: cursor(-30.9, -15.12))
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == set_main(0.5, 0.5) <> "PRESS A\n"

      # 6. Holding the slider below the target level: drag right
      gamestate =
        cpu_gs(2,
          controller_status: 1,
          cpu_level: 1,
          is_holding_cpu_slider: true,
          cursor: cursor(-30.9, -15.12)
        )

      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      # two levels out on an even frame: the gentle, deadzone-safe nudge
      assert wrote == set_main(0.8, 0.5)

      # 7. Holding at the right level, even frame: press A to release it
      gamestate =
        cpu_gs(2,
          controller_status: 1,
          cpu_level: 3,
          is_holding_cpu_slider: true,
          cursor: cursor(-30.9, -15.12)
        )

      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == "PRESS A\n"
      # (holding-the-slider branches don't steer, so no SET MAIN here)

      # 8. Configured: CPU status, right level, slider released. The CPU
      # branch no longer triggers; with the character selected and coin
      # down we idle (no autostart) — the exact gate upstream code checks.
      gamestate =
        cpu_gs(3,
          controller_status: 1,
          cpu_level: 3,
          is_holding_cpu_slider: false,
          cursor: cursor(-30.9, -15.12)
        )

      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == @release_all

      # 9. ...and with autostart + ready banner, START is pressed
      gamestate =
        cpu_gs(3,
          controller_status: 1,
          cpu_level: 3,
          is_holding_cpu_slider: false,
          cursor: cursor(-30.9, -15.12)
        )

      gamestate = %{gamestate | ready_to_start: true}

      {_state, wrote} =
        step_frame(state, gamestate, pid, path, base_opts(cpu_level: 3, autostart: true))

      assert wrote == "PRESS START\n"
    end

    test "dragging left when the slider level is a little too high", ctx do
      {pid, path} = file_controller(ctx)

      # Two levels out: ease off so we land on the level we asked for.
      gamestate =
        cpu_gs(2,
          controller_status: 1,
          cpu_level: 5,
          is_holding_cpu_slider: true,
          cursor: cursor(-30.9, -15.12)
        )

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(cpu_level: 3))

      assert wrote == set_main(0.2, 0.5)
    end

    test "slams the slider at full tilt when several levels away", ctx do
      {pid, path} = file_controller(ctx)

      holding = fn level ->
        cpu_gs(2,
          controller_status: 1,
          cpu_level: level,
          is_holding_cpu_slider: true,
          cursor: cursor(-30.9, -15.12)
        )
      end

      {_state, wrote} =
        step_frame(MenuHelper.new(), holding.(1), pid, path, base_opts(cpu_level: 9))

      assert wrote == set_main(1.0, 0.5)

      {_state, wrote} =
        step_frame(MenuHelper.new(), holding.(9), pid, path, base_opts(cpu_level: 1))

      assert wrote == set_main(0.0, 0.5)
    end

    test "a human port ignores the slider flag and keeps walking to its character", ctx do
      {pid, path} = file_controller(ctx)

      # is_holding_cpu_slider has been seen reading true on a port we are
      # NOT making a CPU. Acting on it hands control to the CPU state
      # machine, which knows nothing about the character portrait, so the
      # hand strands at the HMN box and the match can never start.
      gamestate =
        cpu_gs(2,
          controller_status: 0,
          cpu_level: 0,
          is_holding_cpu_slider: true,
          character: 0xFF,
          cursor: cursor(-32.2, -2.2)
        )

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      # Fox's portrait is up and to the right: we steer (diagonally,
      # both components off center), not sit there.
      {x, y} = main_dir(wrote)
      assert x > stick_center()
      assert y > stick_center()
    end

    test "lets go when it is holding the slider but the hand has moved away", ctx do
      {pid, path} = file_controller(ctx)

      # Melee parks a port's cursor at the top of its panel when the CSS
      # is interrupted (another port opening name entry, say) while
      # is_holding_cpu_slider can still read true. Dragging on that stale
      # belief walks the cursor away forever, so drop the slider instead.
      gamestate =
        cpu_gs(2,
          controller_status: 1,
          cpu_level: 2,
          is_holding_cpu_slider: true,
          cursor: cursor(-30.9, -2.2)
        )

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(cpu_level: 9))

      assert wrote == @release_all
    end
  end

  describe "direct connect code entry" do
    defp name_entry_gs(attrs) do
      gs(Keyword.merge([menu_state: @slippi_online_css, submenu: 0x05], attrs))
    end

    test "user_json?: false refuses a connect code", ctx do
      {pid, _path} = file_controller(ctx)
      gamestate = name_entry_gs(frame: 1, menu_selection: 45)

      assert_raise ArgumentError, ~r/user\.json/, fn ->
        MenuHelper.step(
          MenuHelper.new(),
          gamestate,
          pid,
          base_opts(connect_code: "FOX#123", user_json?: false)
        )
      end
    end

    test "user_json?: false is fine without a connect code (and for \"\")", ctx do
      {pid, _path} = file_controller(ctx)
      gamestate = name_entry_gs(frame: 1, menu_selection: 45)

      assert %MenuHelper{} = MenuHelper.step(MenuHelper.new(), gamestate, pid, base_opts([]))

      assert %MenuHelper{} =
               MenuHelper.step(
                 MenuHelper.new(),
                 gamestate,
                 pid,
                 base_opts(connect_code: "", user_json?: false)
               )
    end

    test "the guard is off by default, so existing callers are unaffected", ctx do
      {pid, _path} = file_controller(ctx)
      gamestate = name_entry_gs(frame: 1, menu_selection: 45)

      assert %MenuHelper{} =
               MenuHelper.step(MenuHelper.new(), gamestate, pid, base_opts(connect_code: "F#1"))
    end

    test "holds right until inputs are live", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = name_entry_gs(frame: 1, menu_selection: 45)

      {state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(connect_code: "FOX#123"))

      assert wrote == set_main(1.0, 0.5)
      refute state.inputs_live
    end

    test "releases all on even frames once live", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = name_entry_gs(frame: 2, menu_selection: 20)

      {state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(connect_code: "FOX#123"))

      assert wrote == @release_all
      assert state.inputs_live
    end

    test "presses A over the target letter and advances the index", ctx do
      {pid, path} = file_controller(ctx)
      # 'F' -> column 5 in "ABCDEFGHIJ" -> code 45 - 25 = 20
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)

      {state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(connect_code: "FOX#123"))

      assert wrote == "PRESS A\n"
      assert state.name_tag_index == 1
    end

    test "moves off the bottom row (selection 57)", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = name_entry_gs(frame: 1, menu_selection: 57)

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(connect_code: "FOX#123"))

      assert wrote == set_main(0.5, 1.0)
    end

    test "presses START when the whole code has been entered", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | name_tag_index: 7, inputs_live: true}
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)

      {_state, wrote} =
        step_frame(state, gamestate, pid, path, base_opts(connect_code: "FOX#123"))

      assert wrote == "PRESS START\n"
    end

    test "verify-before-confirm: autofill shortcut skips typing, confirm phase presses", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | inputs_live: true}
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)
      opts = base_opts(connect_code: "FOX#123", code_buffer: "FOX#123")

      # Shortcut frame: index jumps to the end, nothing pressed yet.
      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert state.name_tag_index == 7
      refute wrote =~ "PRESS"

      # Confirm phase: STARTs with a Z interleaved every 4th press —
      # the buffer may be GHOST text (AUTO FILL suggestion) that only
      # Z commits; START on a ghost does nothing (live strand
      # 2026-08-23).
      presses =
        for _ <- 1..4 do
          {new_state, wrote} = step_frame(Process.get(:vst, state), gamestate, pid, path, opts)
          Process.put(:vst, new_state)
          wrote
        end

      assert Enum.count(presses, &(&1 =~ "PRESS START")) == 3
      assert Enum.count(presses, &(&1 =~ "PRESS Z")) == 1
    end

    test "verify-before-confirm: matching buffer confirms at the end of typing", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | name_tag_index: 7, inputs_live: true}
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)

      {_state, wrote} =
        step_frame(state, gamestate, pid, path,
          base_opts(connect_code: "FOX#123", code_buffer: "FOX#123")
        )

      assert wrote == "PRESS START\n"
    end

    test "verify-before-confirm: a proper prefix waits (readback lag), then resumes typing", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | name_tag_index: 7, inputs_live: true}
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)
      opts = base_opts(connect_code: "FOX#123", code_buffer: "FOX#12")

      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == @release_all
      assert state.code_waits == 1

      # Wait budget exhausted: resume from the buffer's true length.
      state = %{state | code_waits: 30}
      {state, _} = step_frame(state, gamestate, pid, path, opts)
      assert state.name_tag_index == 6
      assert state.code_waits == 0
    end

    test "verify-before-confirm: divergent buffer clears and retypes, bounded", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | name_tag_index: 7, inputs_live: true}
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)

      {state, wrote} =
        step_frame(state, gamestate, pid, path,
          base_opts(connect_code: "FOX#123", code_buffer: "AOX#123")
        )

      assert wrote == "PRESS B\n"
      assert state.code_clearing

      {state, wrote} =
        step_frame(state, gamestate, pid, path,
          base_opts(connect_code: "FOX#123", code_buffer: "AO")
        )

      assert wrote == "PRESS B\n"

      {state, _} =
        step_frame(state, gamestate, pid, path,
          base_opts(connect_code: "FOX#123", code_buffer: "")
        )

      refute state.code_clearing
      assert state.name_tag_index == 0
      assert state.code_retypes == 1
    end

    test "verify-before-confirm: retypes exhausted refuses to confirm a wrong code", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | name_tag_index: 7, inputs_live: true, code_retypes: 2}
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)
      opts = base_opts(connect_code: "FOX#123", code_buffer: "AOX#123")

      {state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert state.code_verify_failed
      refute wrote =~ "PRESS START"

      {_state, wrote} = step_frame(state, gamestate, pid, path, opts)
      assert wrote == @release_all
    end

    test "without a connect code, gets on with picking a character", ctx do
      {pid, path} = file_controller(ctx)

      # Melee leaves submenu reading @name_entry_submenu after the
      # keyboard closes, so this gamestate is also what the CSS looks
      # like right after the nametag flow. Treating it as name entry
      # stranded the port: no character picked, START never pressed.
      gamestate = %{name_entry_gs(frame: 1) | players: %{1 => player(cursor: cursor(-22, 25))}}

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      # Steering toward Fox, not sitting on its hands.
      assert wrote =~ "RELEASE START\nRELEASE A\n"
      assert main_dir(wrote) != {stick_center(), stick_center()}
    end

    test "leaving name entry resets the entry state", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | name_tag_index: 4, inputs_live: true}
      players = %{1 => player(cursor: cursor(-22, 25))}

      gamestate =
        gs(menu_state: @character_select, submenu: 0xFF, frame: 1, players: players)

      {state, _wrote} = step_frame(state, gamestate, pid, path, base_opts())

      assert state.name_tag_index == 0
      refute state.inputs_live
    end
  end

  describe "main menu" do
    test "versus mode: presses A on the right selection", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = gs(menu_state: @main_menu, submenu: 0, menu_selection: 1, frame: 1)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == "PRESS A\n"
    end

    test "versus mode: scrolls down otherwise", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = gs(menu_state: @main_menu, submenu: 0, menu_selection: 0, frame: 1)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == set_main(0.5, 0.0)
    end

    test "with a connect code, navigates the online play submenu", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = gs(menu_state: @main_menu, submenu: 8, menu_selection: 2, frame: 1)

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(connect_code: "FOX#123"))

      assert wrote == "PRESS A\n"
    end

    test "backs out of unknown submenus with B", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = gs(menu_state: @main_menu, submenu: 4, menu_selection: 0, frame: 1)

      {_state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert wrote == "PRESS B\n"
    end
  end

  describe "postgame scores" do
    test "alternates pressing and releasing START", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = gs(menu_state: @postgame_scores, frame: 1)
      state = MenuHelper.new()

      {state, wrote} = step_frame(state, gamestate, pid, path, base_opts())
      assert wrote == "PRESS START\n"

      # prev now has START held, so the next frame releases it
      {_state, wrote} = step_frame(state, gamestate, pid, path, base_opts())
      assert wrote == "RELEASE START\n"
    end
  end

  describe "in-game nametag: option parsing" do
    test "no :nametag leaves the flow untouched and picks a character", ctx do
      {pid, path} = file_controller(ctx)

      gamestate =
        gs(
          menu_state: @character_select,
          frame: 1,
          players: %{1 => player(character: @fox, cursor: cursor(0, 0), coin_down: true)}
        )

      {state, wrote} = step_frame(MenuHelper.new(), gamestate, pid, path, base_opts())

      assert state.nametag_phase == :waiting
      assert state.nametag_done == false
      # character selection, not the name box (which is far below at y ~ -18)
      refute wrote == ""
      # nothing but the boot-dialog latch (and the watchdog's progress
      # signature, which every menu step records) moved
      assert %{state | stall_sig: nil} == %{MenuHelper.new() | seen_known_menu: true}
      assert state.stall_sig != nil
    end

    test "an already-done flow falls through to character selection", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | nametag_done: true, nametag_phase: :done}

      gamestate =
        gs(
          menu_state: @character_select,
          frame: 1,
          players: %{1 => player(character: @fox, cursor: cursor(0, 0), coin_down: true)}
        )

      {new_state, _wrote} =
        step_frame(state, gamestate, pid, path, base_opts(nametag: "EXPH"))

      assert new_state.nametag_phase == :done
    end

    test "waits for a character on our panel before opening the name box", ctx do
      {pid, path} = file_controller(ctx)

      # 0xFF is an empty CSS panel: there is no name box to press A on.
      gamestate =
        gs(
          menu_state: @character_select,
          frame: 1,
          players: %{1 => player(character: 0xFF, cursor: cursor(0, 0), coin_down: false)}
        )

      {state, _wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(nametag: "EXPH"))

      # still :waiting, and nametag_frames never started counting
      assert state.nametag_phase == :waiting
      assert state.nametag_frames == 0
    end
  end

  describe "in-game nametag: phase transitions" do
    # The measured port-1 targets (see MenuHelper source).
    @name_box {-23.7, -18.62}
    # x is irrelevant for list rows: the open list pins the hand there.
    # Row 2 is NAME ENTRY when no tag is saved, the saved tag once one is.
    @row2_y -8.7

    defp css(cursor, extra \\ []) do
      gs(
        Keyword.merge(
          [
            menu_state: @character_select,
            frame: 1,
            players: %{1 => player(character: @fox, cursor: cursor, coin_down: true)}
          ],
          extra
        )
      )
    end

    test "moves down toward the name box when the cursor is above it", ctx do
      {pid, path} = file_controller(ctx)

      {state, wrote} =
        step_frame(MenuHelper.new(), css(cursor(-23, 0)), pid, path, base_opts(nametag: "EXPH"))

      # far away -> full tilt straight at the name box (mostly down,
      # nudging left onto its column)
      assert wrote =~ steer_main(-23, 0, -23.7, -18.62, tolerance: 0.4)
      assert state.nametag_phase == :name_box
      assert state.nametag_frames == 0
    end

    test "eases off the stick when it is close to the target", ctx do
      {pid, path} = file_controller(ctx)
      {_x, y} = @name_box

      {_state, wrote} =
        step_frame(
          MenuHelper.new(),
          css(cursor(-23.22, y + 2.0)),
          pid,
          path,
          base_opts(nametag: "EXPH")
        )

      {x, _y} = @name_box
      assert wrote =~ steer_main(-23.22, y + 2.0, x, y, tolerance: 0.4)
    end

    test "on the name box, pulses A then advances to the list phase", ctx do
      {pid, path} = file_controller(ctx)
      {x, y} = @name_box
      on_box = css(cursor(x, y))
      state = MenuHelper.new()

      # first frames: A held
      {state, wrote} = step_frame(state, on_box, pid, path, base_opts(nametag: "EXPH"))
      assert wrote == set_main(0.5, 0.5) <> "PRESS A\n"
      assert state.nametag_frames == 1

      state =
        Enum.reduce(1..23, state, fn _i, state ->
          {state, _} = step_frame(state, on_box, pid, path, base_opts(nametag: "EXPH"))
          assert state.nametag_phase == :name_box
          state
        end)

      # frame 25: settle window is over, so we move on to the list
      {state, _wrote} = step_frame(state, on_box, pid, path, base_opts(nametag: "EXPH"))
      assert state.nametag_phase == :list
      assert state.nametag_frames == 0
    end

    test ":select presses A on the list's second row and finishes", ctx do
      {pid, path} = file_controller(ctx)
      # Row 2 holds the saved tag once one exists (NAME ENTRY is always
      # last), so both modes aim at the same y.
      on_row = css(cursor(-25.2, @row2_y))
      state = %{MenuHelper.new() | nametag_phase: :list}

      state =
        Enum.reduce(1..24, state, fn _i, state ->
          {state, _} = step_frame(state, on_row, pid, path, base_opts(nametag: "EXPH"))
          state
        end)

      assert state.nametag_phase == :list

      {state, _} = step_frame(state, on_row, pid, path, base_opts(nametag: "EXPH"))
      assert state.nametag_phase == :done
      assert state.nametag_done == true
    end

    test "the list is steered by y alone, never by x", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | nametag_phase: :list}

      # Wildly wrong x, correct y: the open list pins x, so we must not
      # try to steer it — we press A instead.
      {state, wrote} =
        step_frame(state, css(cursor(5.0, @row2_y)), pid, path, base_opts(nametag: "EXPH"))

      assert wrote == set_main(0.5, 0.5) <> "PRESS A\n"
      assert state.nametag_frames == 1
    end

    test "a row that is too low is approached with an eased upward tilt", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | nametag_phase: :list}

      {_state, wrote} =
        step_frame(
          state,
          css(cursor(-25.2, @row2_y - 2.4)),
          pid,
          path,
          base_opts(nametag: "EXPH", nametag_mode: :create)
        )

      assert wrote =~ set_main(0.5, 0.72)
    end

    test ":create types the tag on the keyboard and finishes when it closes", ctx do
      {pid, path} = file_controller(ctx)
      opts = base_opts(nametag: "EX", nametag_mode: :create)

      # submenu 18 / selection 45 is the name-entry keyboard
      keyboard = fn selection, frame ->
        gs(
          menu_state: @character_select,
          submenu: 18,
          menu_selection: selection,
          frame: frame,
          players: %{1 => player(character: @fox, cursor: cursor(0, 0), coin_down: false)}
        )
      end

      state = %{MenuHelper.new() | nametag_phase: :list}

      # frame 1 on selection 45: inputs are not live yet, so we nudge right
      {state, wrote} = step_frame(state, keyboard.(45, 1), pid, path, opts)
      assert state.nametag_phase == :typing
      assert wrote =~ set_main(1.0, 0.5)

      # 'E' lives at code 45 - 4*5 = 25; land on it and A is pressed
      {state, wrote} = step_frame(state, keyboard.(25, 1), pid, path, opts)
      assert wrote == "PRESS A\n"
      assert state.name_tag_index == 1

      # 'X' lives at 47 - 3*5 = 32
      {state, wrote} = step_frame(state, keyboard.(32, 3), pid, path, opts)
      assert wrote == "PRESS A\n"
      assert state.name_tag_index == 2

      # tag complete -> START confirms
      {state, wrote} = step_frame(state, keyboard.(32, 5), pid, path, opts)
      assert wrote == "PRESS START\n"
      refute state.nametag_done

      # keyboard gone -> the flow is finished
      {state, _wrote} = step_frame(state, css(cursor(0, 0)), pid, path, opts)
      assert state.nametag_phase == :done
      assert state.nametag_done == true
    end

    test "stays latched when the hovered character flickers back to 0xFF", ctx do
      {pid, path} = file_controller(ctx)
      opts = base_opts(nametag: "EXPH")

      # `character` at the CSS is whatever portrait the hand hovers, so it
      # drops back to 0xFF the moment the cursor leaves the grid. Once the
      # flow has started it must keep steering, not hand control back to
      # choose_character (which would fight it at the grid boundary).
      {state, _wrote} = step_frame(MenuHelper.new(), css(cursor(-23, 0)), pid, path, opts)
      assert state.nametag_phase == :name_box

      off_grid =
        css(cursor(-23, -5))
        |> Map.put(:players, %{
          1 => player(character: 0xFF, cursor: cursor(-23, -5), coin_down: false)
        })

      {state, wrote} = step_frame(state, off_grid, pid, path, opts)

      assert state.nametag_phase == :name_box
      # still heading down to the name box at y ~ -18.6
      assert wrote =~ steer_main(-23, -5, -23.7, -18.62, tolerance: 0.4)
    end

    test "a cursor that never arrives keeps the flow in its first phase", ctx do
      {pid, path} = file_controller(ctx)
      opts = base_opts(nametag: "EXPH")
      # The CSS start position, frozen: we must keep steering, never press.
      start = css(cursor(-31.0, -2.5))

      final =
        Enum.reduce(1..30, MenuHelper.new(), fn _i, state ->
          {state, _wrote} = step_frame(state, start, pid, path, opts)
          state
        end)

      assert final.nametag_phase == :name_box
      assert final.nametag_frames == 0
      refute final.nametag_done
    end
  end

  describe "in-game nametag: per-port coordinate math" do
    test "port 2's name box is one panel width to the right of port 1's", ctx do
      {pid, path} = file_controller(ctx)
      # Name-box spacing is 15.4 — the CPU-slider pitch, NOT the 15.82
      # the HMN/CPU box uses. Measured live 2026-08-14: pinned tag-list
      # columns at exactly -25.2 + 15.4*(N-1) for all four ports.
      spacing = 15.4
      port2_box_x = -23.7 + spacing

      # Sitting exactly on PORT 1's box while driving port 2: we must
      # still be moving right, toward port 2's panel.
      gamestate =
        gs(
          menu_state: @character_select,
          frame: 1,
          players: %{
            2 => player(character: @fox, cursor: cursor(-23.7, -18.62), coin_down: true)
          }
        )

      {state, wrote} =
        step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(nametag: "EXPH", port: 2))

      assert wrote =~ set_main(1.0, 0.5)
      assert state.nametag_frames == 0

      # ... and on port 2's box we press A instead
      gamestate2 =
        gs(
          menu_state: @character_select,
          frame: 1,
          players: %{
            2 => player(character: @fox, cursor: cursor(port2_box_x, -18.62), coin_down: true)
          }
        )

      {_state, wrote} =
        step_frame(MenuHelper.new(), gamestate2, pid, path, base_opts(nametag: "EXPH", port: 2))

      assert wrote == set_main(0.5, 0.5) <> "PRESS A\n"
    end

    test "a missing port releases everything and does nothing", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | nametag_phase: :list}

      gamestate =
        gs(menu_state: @character_select, frame: 1, players: %{1 => player(character: @fox)})

      {new_state, wrote} =
        step_frame(state, gamestate, pid, path, base_opts(nametag: "EXPH", port: 3))

      assert wrote == @release_all
      assert %{new_state | stall_sig: nil} == %{state | seen_known_menu: true}
    end
  end

  describe "unknown scenes" do
    @unknown_menu 0xFF

    defp dialog_gs(frame), do: gs(menu_state: @unknown_menu, frame: frame, players: %{})

    defp scene_gs(frame, scene),
      do: gs(menu_state: @unknown_menu, raw_scene: scene, frame: frame, players: %{})

    test "logs each distinct unknown raw scene once (turns mystery into telemetry)", ctx do
      import ExUnit.CaptureLog
      {pid, path} = file_controller(ctx)

      log =
        capture_log(fn ->
          state = MenuHelper.new()
          # Same scene twice, then a different one: two log lines total.
          {state, _} = step_frame(state, scene_gs(1, 0x1234), pid, path, base_opts())
          {state, _} = step_frame(state, scene_gs(3, 0x1234), pid, path, base_opts())
          {state, _} = step_frame(state, scene_gs(5, 0x5678), pid, path, base_opts())
          assert MapSet.equal?(state.logged_scenes, MapSet.new([0x1234, 0x5678]))
        end)

      assert length(String.split(log, "unrecognized menu scene")) == 3
      assert log =~ "0x1234"
      assert log =~ "0x5678"
    end

    test "pulses A at an unknown boot scene to answer the memory card prompt", ctx do
      {pid, path} = file_controller(ctx)
      state = MenuHelper.new()

      {state, wrote} = step_frame(state, dialog_gs(1), pid, path, base_opts())
      assert wrote == "PRESS A\n"

      {state, wrote} = step_frame(state, dialog_gs(2), pid, path, base_opts())
      assert wrote == "RELEASE A\n"

      refute state.seen_known_menu
    end

    test "the boot scene (0x28) gets a grace period, then the A-pulse", ctx do
      {pid, path} = file_controller(ctx)
      state = MenuHelper.new()

      # Grace first: on ExiAI it auto-advances with zero input (measured
      # live), and pressing A at nameless scenes is how runs wander into
      # Online Play.
      {state, wrote} = step_frame(state, scene_gs(1, 0x28), pid, path, base_opts())
      refute wrote =~ "PRESS"
      {state, wrote} = step_frame(state, scene_gs(2, 0x28), pid, path, base_opts())
      refute wrote =~ "PRESS"

      # ...but only a grace period: on the netplay build the same scene
      # holds the "Create Game Data?" prompt, which waits for A — a
      # wait-forever version stranded the boot on the card menu live.
      state =
        Enum.reduce(3..130, state, fn f, state ->
          {state, _} = step_frame(state, scene_gs(f, 0x28), pid, path, base_opts())
          state
        end)

      {state, wrote} = step_frame(state, scene_gs(131, 0x28), pid, path, base_opts())
      {_state, wrote2} = step_frame(state, scene_gs(132, 0x28), pid, path, base_opts())
      assert wrote <> wrote2 =~ "PRESS A"

      # Typed, so it never lands in the unrecognized-scene telemetry.
      # (Asserted on state, not captured logs — capture_log is global
      # and async siblings legitimately log "unrecognized".)
      assert Melee.Events.Menu.scene_name(0x28) == :boot
    end

    test ":ignore leaves the scene alone", ctx do
      {pid, path} = file_controller(ctx)

      {_state, wrote} =
        step_frame(MenuHelper.new(), dialog_gs(1), pid, path, base_opts(unknown_scene: :ignore))

      assert wrote == ""
    end

    test "backs out with B at an unknown scene once a real menu has been seen", ctx do
      {pid, path} = file_controller(ctx)

      # PRESS START is a menu we recognize, so the boot phase is over.
      {state, _wrote} =
        step_frame(
          MenuHelper.new(),
          gs(menu_state: @press_start, frame: 2),
          pid,
          path,
          base_opts()
        )

      assert state.seen_known_menu

      # An unknown scene later in the session gets B, never A: backing
      # out is the only safe move mid-session.
      {_state, wrote} = step_frame(state, dialog_gs(3), pid, path, base_opts())
      assert wrote == "PRESS B\n"
    end

    test "falls back to B when A has not shifted the scene", ctx do
      {pid, path} = file_controller(ctx)

      # The Slippi log-in screen ignores A, so after a spell of trying we
      # back out instead of pressing A at it forever.
      state =
        Enum.reduce(1..300, MenuHelper.new(), fn frame, state ->
          {state, _wrote} = step_frame(state, dialog_gs(frame), pid, path, base_opts())
          state
        end)

      assert state.unknown_frames == 300

      {_state, wrote} = step_frame(state, dialog_gs(301), pid, path, base_opts())
      assert wrote == "PRESS B\n"
    end

    test "an in-game scene also counts as a real menu", ctx do
      {pid, path} = file_controller(ctx)

      {state, _wrote} =
        step_frame(MenuHelper.new(), gs(menu_state: @in_game, frame: 1), pid, path, base_opts())

      assert state.seen_known_menu
    end
  end

  describe "in game" do
    test "writes nothing and returns the state unchanged", ctx do
      {pid, path} = file_controller(ctx)
      state = MenuHelper.new()
      gamestate = gs(menu_state: @in_game, frame: 100)

      new_state = MenuHelper.step(state, gamestate, pid, base_opts())
      # a call serializes any pending casts before we read the file
      _ = Controller.current(pid)

      assert new_state == %{state | seen_known_menu: true}
      assert File.read!(path) == ""
    end
  end

  describe "slippi online CSS direct selection" do
    # Fox's CSS-grid id is 0x0A (from_internal): row 1, col 1 ->
    # portrait target (-22.0, 11.5). RANDOM slot {0,0}: (-29.0, 4.5).
    defp slippi_css_gs(attrs) do
      base = [
        character: 0xFF,
        cursor: cursor(0, 0),
        coin_down: false,
        cpu_level: 0,
        controller_status: 0,
        costume: 0
      ]

      gs(
        menu_state: @slippi_online_css,
        frame: Keyword.get(attrs, :frame, 1),
        players: %{1 => player(Keyword.merge(base, Keyword.delete(attrs, :frame)))}
      )
    end

    test "steers to the character portrait, not the RANDOM slot", ctx do
      {pid, path} = file_controller(ctx)

      {state, wrote} =
        step_frame(MenuHelper.new(), slippi_css_gs([]), pid, path, base_opts())

      # Direct path: toward Fox's portrait at (-22, 11.5) from (0,0)
      assert wrote =~ steer_main(0, 0, -22.0, 11.5)
      assert state.slippi_css_frames == 1
    end

    test "falls back to the reroll target after the direct window", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | slippi_css_frames: 600}

      {state, wrote} = step_frame(state, slippi_css_gs([]), pid, path, base_opts())

      # Fallback: toward the RANDOM slot at (-29, 4.5)
      assert wrote =~ steer_main(0, 0, -29.0, 4.5)
      assert state.slippi_css_frames == 601
    end

    test "locking the character resets the clock and drives costume/START", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | slippi_css_frames: 123}

      # Locked (character == fox AND the coin is down), odd frame,
      # costume matches: the post-lock flow presses START — without
      # swag. Since 2026-08-22 (GOTCHA #101) the character byte alone
      # is NOT a lock signal — the online-CSS snapshot reports the
      # HOVERED/last-selected character — so this branch additionally
      # requires coin_down or the ready banner.
      gamestate = slippi_css_gs(character: @fox, coin_down: true, frame: 3)
      {state, wrote} = step_frame(state, gamestate, pid, path, base_opts())

      assert state.slippi_css_frames == 0
      assert wrote =~ "PRESS START"
    end

    test "hovered-but-unselected character falls through to the A press (GOTCHA #101)", ctx do
      {pid, path} = file_controller(ctx)
      state = %{MenuHelper.new() | slippi_css_frames: 123}

      # character byte reads fox (hover/snapshot) but NO selection
      # signal: must NOT press START; with the cursor on the portrait
      # the select flow presses A instead (the live 08-22 wedge:
      # START-mashing forever, fox never picked).
      gamestate = slippi_css_gs(character: @fox, cursor: cursor(-22.0, 11.5), frame: 3)
      {_state, wrote} = step_frame(state, gamestate, pid, path, base_opts())

      refute wrote =~ "PRESS START"
      assert wrote =~ "PRESS A"
    end
  end

  describe "empty connect code (GOTCHA #88)" do
    import ExUnit.CaptureLog

    test "\"\" still drives the keyboard but logs the hijack once", ctx do
      {pid, path} = file_controller(ctx)
      gamestate = name_entry_gs(frame: 1, menu_selection: 20)

      log =
        capture_log(fn ->
          {_state, _wrote} =
            step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(connect_code: ""))

          # Second frame: the warning must NOT repeat (once per process)
          {_state, _wrote} =
            step_frame(MenuHelper.new(), gamestate, pid, path, base_opts(connect_code: ""))
        end)

      assert log =~ "connect_code is \"\""
      assert length(String.split(log, "connect_code is")) == 2
    end
  end

  describe "menu watchdog" do
    test "counts stalled frames at an unchanging scene", ctx do
      {pid, path} = file_controller(ctx)

      state =
        Enum.reduce(1..4, MenuHelper.new(), fn _i, state ->
          # Same scene, no players, nothing moves: pure stall. frame
          # deliberately constant — wall-clock isn't progress.
          {state, _} =
            step_frame(state, gs(menu_state: @press_start, frame: 9), pid, path, base_opts())

          state
        end)

      assert state.stalled_frames == 3
      refute MenuHelper.stuck?(state)
      assert MenuHelper.stuck?(state, stuck_after_frames: 3)
    end

    test "cursor movement resets the stall counter", ctx do
      {pid, path} = file_controller(ctx)

      stage = fn x ->
        gs(menu_state: @stage_select, players: %{1 => player(cursor: cursor(x, 0))})
      end

      {state, _} = step_frame(MenuHelper.new(), stage.(0), pid, path, base_opts(autostart: true))
      {state, _} = step_frame(state, stage.(0), pid, path, base_opts(autostart: true))
      assert state.stalled_frames == 1

      {state, _} = step_frame(state, stage.(2), pid, path, base_opts(autostart: true))
      assert state.stalled_frames == 0
    end

    test "on_stuck fires exactly once per stall episode", ctx do
      {pid, path} = file_controller(ctx)
      test_pid = self()

      opts =
        base_opts(
          stuck_after_frames: 2,
          on_stuck: fn report -> send(test_pid, {:stuck, report}) end
        )

      state =
        Enum.reduce(1..5, MenuHelper.new(), fn _i, state ->
          {state, _} = step_frame(state, gs(menu_state: @press_start, frame: 9), pid, path, opts)
          state
        end)

      assert state.stuck_reported
      assert_received {:stuck, %{menu_state: @press_start, frames: 2}}
      refute_received {:stuck, _}
    end

    test "going in-game clears the watchdog", ctx do
      {pid, path} = file_controller(ctx)

      {state, _} =
        step_frame(
          MenuHelper.new(),
          gs(menu_state: @press_start, frame: 9),
          pid,
          path,
          base_opts()
        )

      {state, _} =
        step_frame(state, gs(menu_state: @press_start, frame: 9), pid, path, base_opts())

      assert state.stalled_frames == 1

      # menu_state 2 = IN_GAME
      {state, _} = step_frame(state, gs(menu_state: 2, frame: 10), pid, path, base_opts())
      assert state.stalled_frames == 0
      assert state.stall_sig == nil
    end
  end
end
